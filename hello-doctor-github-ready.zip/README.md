# Hello Doctor Dubai — Next.js Web Application

Official web platform for **Hello Doctor Home Health Care LLC** (`https://hellodoctor.ae`), DHA Licensed Healthcare Facility #6978946.

## 🛠 Tech Stack
- **Framework:** Next.js 15 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS + Radix UI + Lucide Icons
- **Animation:** Framer Motion

## 🚀 Getting Started

### Local Development
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### Production Build
```bash
npm run build
npm start
```
