/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  reactStrictMode: true,
  poweredByHeader: false,
  trailingSlash: true,
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "hellodoctor.ae",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
    ],
  },
  async redirects() {
    return [
      // Standardize trailing slashes and normalize legacy URLs
      {
        source: "/doctor-at-home",
        destination: "/doctor-at-home-dubai/",
        permanent: true,
      },
      {
        source: "/iv-drip",
        destination: "/iv-drip-at-home-dubai/",
        permanent: true,
      },
      {
        source: "/iv-therapy-dubai",
        destination: "/iv-drip-at-home-dubai/",
        permanent: true,
      },
      {
        source: "/home-nursing-dubai",
        destination: "/nursing-care-at-home/",
        permanent: true,
      },
      {
        source: "/blood-test-dubai",
        destination: "/blood-test-at-home/",
        permanent: true,
      },
      {
        source: "/physiotherapy-dubai",
        destination: "/physiotherapy-at-home/",
        permanent: true,
      },
    ];
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          {
            key: "X-DNS-Prefetch-Control",
            value: "on",
          },
          {
            key: "Strict-Transport-Security",
            value: "max-age=63072000; includeSubDomains; preload",
          },
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "X-Frame-Options",
            value: "SAMEORIGIN",
          },
          {
            key: "X-XSS-Protection",
            value: "1; mode=block",
          },
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
        ],
      },
    ];
  },
};

export default nextConfig;
