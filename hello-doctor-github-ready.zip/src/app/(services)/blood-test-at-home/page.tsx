import { notFound } from "next/navigation";
import { Metadata } from "next";
import { getServiceBySlug } from "@/data/services";
import { ServiceDetailView } from "@/components/services/ServiceDetailView";
import { constructMetadata } from "@/lib/seo";
import {
  generateMedicalProcedureSchema,
  generateFAQSchema,
  generateBreadcrumbSchema,
} from "@/lib/schema";

const SLUG = "blood-test-at-home";

export async function generateMetadata(): Promise<Metadata> {
  const service = getServiceBySlug(SLUG);
  if (!service) return {};

  return constructMetadata({
    title: service.metaTitle,
    description: service.metaDescription,
    canonicalPath: `/${SLUG}/`,
  });
}

export default function BloodTestPage() {
  const service = getServiceBySlug(SLUG);
  if (!service) notFound();

  const procedureSchema = generateMedicalProcedureSchema(service);
  const faqSchema = generateFAQSchema(service.faqs);
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: service.shortTitle, item: `/${SLUG}/` },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(procedureSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <ServiceDetailView service={service} />
    </>
  );
}
