import { Metadata } from "next";
import Link from "next/link";
import { constructMetadata } from "@/lib/seo";
import { SITE_CONFIG } from "@/lib/utils";
import { TrustSignals } from "@/components/home/TrustSignals";
import { DoctorShowcase } from "@/components/home/DoctorShowcase";
import { ReviewsSection } from "@/components/home/ReviewsSection";
import { ShieldCheck, HeartHandshake, Award, Clock, Users, CheckCircle2 } from "lucide-react";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "About Us | Hello Doctor Home Health Care Dubai",
    description:
      "Learn about Hello Doctor Dubai, a licensed DHA Home Health Care provider delivering 24/7 doctor home visits, IV therapy, nursing & lab diagnostics across Dubai.",
    canonicalPath: "/about-us/",
  });
}

export default function AboutUsPage() {
  return (
    <div className="bg-white">
      <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-20 border-b border-orange-100/60">
        <div className="container mx-auto text-center max-w-3xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-950 text-xs font-bold uppercase tracking-wider mb-3">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            DHA Licensed Facility #{SITE_CONFIG.dhaLicense}
          </span>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight">
            Redefining Healthcare in <span className="brand-gradient-text">Dubai at Your Doorstep</span>
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Hello Doctor was founded with a singular mission: to deliver immediate, compassionate, and hospital-grade medical care in the privacy and comfort of your home, villa, or hotel room.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto max-w-5xl space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div className="space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
                Our Story & Vision
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950">
                Bringing the Hospital to You When You Need It Most
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                When you or your loved one is sick, navigating heavy Dubai traffic, finding parking, and sitting in crowded clinic waiting rooms exposed to secondary infections can be overwhelming.
              </p>
              <p className="text-sm text-slate-600 leading-relaxed">
                Hello Doctor solves this by deploying fully equipped mobile medical units staffed by experienced, DHA-licensed general practitioners and registered nurses. Within 30 to 45 minutes, a doctor arrives at your door with point-of-care diagnostics, medications, and compassionate clinical attention.
              </p>
            </div>

            <div className="bg-orange-50/70 p-8 rounded-3xl border border-orange-200/80 space-y-4">
              <h3 className="text-lg font-bold text-slate-900">Our Clinical Commitments:</h3>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                  <span><strong>100% DHA Licensed:</strong> Every physician and nurse is verified by Dubai Health Authority.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                  <span><strong>30-45 Mins Average Arrival:</strong> Strategic hubs in Downtown, Marina, Palm, JVC & Barsha.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                  <span><strong>Hospital-Grade Hygiene:</strong> Single-use sterile disposables and calibrated diagnostic tools.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                  <span><strong>Transparent Pricing:</strong> Clear rates without surprise call-out charges.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <TrustSignals />
      <DoctorShowcase />
      <ReviewsSection />
    </div>
  );
}
