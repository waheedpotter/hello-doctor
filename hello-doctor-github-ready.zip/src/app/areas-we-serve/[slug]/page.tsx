import { notFound } from "next/navigation";
import { Metadata } from "next";
import Link from "next/link";
import { DUBAI_LOCATIONS, getLocationBySlug } from "@/data/locations";
import { SERVICES } from "@/data/services";
import { constructMetadata } from "@/lib/seo";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { FAQSection } from "@/components/home/FAQSection";
import { ReviewsSection } from "@/components/home/ReviewsSection";
import { generateBreadcrumbSchema } from "@/lib/schema";
import {
  MapPin,
  Clock,
  ShieldCheck,
  Stethoscope,
  Phone,
  MessageSquare,
  ArrowRight,
  Sparkles,
  Hotel,
  CheckCircle2,
  Building2,
  Zap
} from "lucide-react";

export async function generateStaticParams() {
  return DUBAI_LOCATIONS.map((loc) => ({
    slug: loc.slug,
  }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const location = getLocationBySlug(slug);
  if (!location) return {};

  return constructMetadata({
    title: location.seoMetaTitle,
    description: location.seoMetaDescription,
    canonicalPath: `/areas-we-serve/${location.slug}/`,
  });
}

export default async function AreaDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const location = getLocationBySlug(slug);
  if (!location) notFound();

  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Areas We Serve", item: "/areas-we-serve/" },
    { name: location.name, item: `/areas-we-serve/${location.slug}/` },
  ]);

  const localizedFaqs = [
    {
      question: `How fast can a doctor arrive in ${location.name}?`,
      answer: `Our dedicated on-call medical response team is stationed near ${location.name}, ensuring an average arrival time of ${location.averageEtaMinutes} minutes directly to your door.`,
    },
    {
      question: `Do you visit apartments, villas, and hotel rooms in ${location.name}?`,
      answer: `Yes, we provide 24/7 doctor home visits, nurse visits, and IV drip therapies to all residential towers, private villas, and 5-star hotel suites in ${location.name}.`,
    },
    {
      question: `Can the visiting doctor provide DHA sick leaves and medications in ${location.name}?`,
      answer: `Yes, all our physicians are 100% DHA licensed and provide official electronic prescriptions (e-Rx) and DHA approved sick leave certificates on-site.`,
    },
  ];

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />
      <div className="bg-white">
        {/* Area Hero */}
        <section className="relative overflow-hidden bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 pt-8 pb-16 lg:pt-12 lg:pb-20 border-b border-orange-100/60">
          <div className="container mx-auto">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
              <Link href="/" className="hover:text-orange-600">Home</Link>
              <span>/</span>
              <Link href="/areas-we-serve/" className="hover:text-orange-600">Areas We Serve</Link>
              <span>/</span>
              <span className="text-orange-600 font-semibold">{location.name}</span>
            </nav>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              <div className="lg:col-span-8 space-y-5">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-100 text-orange-950 text-xs font-bold border border-orange-200">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  <span>DHA Doctors Stationed Near {location.name}</span>
                  <span className="text-orange-700">• {location.averageEtaMinutes}m Avg. ETA</span>
                </div>

                <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight leading-tight">
                  Doctor at Home in{" "}
                  <span className="brand-gradient-text">{location.name}</span>
                </h1>

                <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
                  {location.description} {location.localHeroText}
                </p>

                {/* Response Time & Coverage Pill */}
                <div className="bg-orange-50/90 rounded-2xl p-4 border border-orange-200/80 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Zone</div>
                    <div className="text-base font-bold text-slate-900">{location.zone}</div>
                  </div>
                  <div className="h-8 w-px bg-orange-200 hidden sm:block" />
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Estimated Arrival</div>
                    <div className="text-base font-bold text-emerald-700 flex items-center gap-1">
                      <Clock className="w-4 h-4 text-emerald-600" />
                      {location.averageEtaMinutes} Minutes
                    </div>
                  </div>
                  <div className="h-8 w-px bg-orange-200 hidden sm:block" />
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Availability</div>
                    <div className="text-base font-bold text-orange-600">24/7 Immediate</div>
                  </div>
                </div>

                {/* CTAs */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <a
                    href={getWhatsAppBookingUrl(`Hello! I need a DHA doctor at my residence/hotel in ${location.name}, Dubai. Please dispatch immediately.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto px-7 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm sm:text-base rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all"
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span>WhatsApp Doctor to {location.name}</span>
                  </a>

                  <a
                    href={getDirectCallUrl()}
                    className="w-full sm:w-auto px-6 py-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 transition-all"
                  >
                    <Phone className="w-4 h-4 text-orange-400" />
                    <span>Call 24/7 Hotline</span>
                  </a>
                </div>
              </div>

              {/* Right Column: Local Highlights */}
              <div className="lg:col-span-4 bg-white rounded-3xl p-6 shadow-xl border border-orange-100 brand-card-glow space-y-4">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
                  <Building2 className="w-4 h-4 text-orange-600" />
                  <span>Coverage in {location.name}</span>
                </div>

                <div>
                  <div className="text-xs font-bold text-slate-700 mb-2">Key Buildings & Towers:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {location.popularCommunities.map((c, i) => (
                      <span key={i} className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>

                {location.nearbyHotels && location.nearbyHotels.length > 0 && (
                  <div className="pt-2 border-t border-slate-100">
                    <div className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1">
                      <Hotel className="w-3.5 h-3.5 text-orange-600" />
                      <span>Nearby Hotel Visits (24/7):</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {location.nearbyHotels.map((h, i) => (
                        <span key={i} className="text-xs bg-orange-50 text-orange-800 px-2.5 py-0.5 rounded-lg border border-orange-200/50">
                          {h}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Services in this Location */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
                Full Clinical Range
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
                Available Medical Services in <span className="brand-gradient-text">{location.name}</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SERVICES.map((srv) => (
                <div
                  key={srv.id}
                  className="p-6 rounded-3xl bg-slate-50 border border-slate-200 hover:border-orange-300 shadow-sm transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-slate-900 text-base">{srv.shortTitle}</h3>
                      <span className="text-xs font-bold text-orange-600">From AED {srv.priceStartingAtAed}</span>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2 mb-4">{srv.tagline}</p>
                  </div>

                  <Link
                    href={`/services/${srv.slug}/`}
                    className="text-xs font-bold text-orange-600 hover:underline flex items-center justify-between pt-3 border-t border-slate-200"
                  >
                    <span>Learn more about {srv.shortTitle}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQs */}
        <FAQSection faqs={localizedFaqs} title={`${location.name} Medical Services - FAQs`} />

        {/* Reviews */}
        <ReviewsSection />
      </div>
    </>
  );
}
