import Link from "next/link";
import { Metadata } from "next";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { SERVICES } from "@/data/services";
import { constructMetadata } from "@/lib/seo";
import { MapPin, Clock, ArrowRight, ShieldCheck, Stethoscope, Sparkles } from "lucide-react";
import { generateBreadcrumbSchema } from "@/lib/schema";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "Areas We Serve in Dubai | 24/7 Doctor at Home & Hotel Visits",
    description:
      "Explore 24/7 Doctor on Call and Home Healthcare coverage across Dubai. Rapid 30-45 min doctor arrival in Downtown, Dubai Marina, Palm Jumeirah, JVC, Business Bay & more.",
    canonicalPath: "/areas-we-serve/",
  });
}

export default function AreasWeServeHubPage() {
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Areas We Serve", item: "/areas-we-serve/" },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />
      <div className="bg-white">
        {/* Header Hero */}
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-18 border-b border-orange-100/60">
          <div className="container mx-auto text-center max-w-3xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-950 text-xs font-bold uppercase tracking-wider mb-3">
              <MapPin className="w-3.5 h-3.5 text-orange-600" />
              Dubai-Wide 24/7 Coverage
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight">
              DHA Licensed Doctor at Home <span className="brand-gradient-text">Across All Dubai Areas</span>
            </h1>
            <p className="mt-4 text-base text-slate-600 leading-relaxed">
              Our mobile medical response teams are strategically stationed across Dubai to ensure an average doctor arrival time of 30 to 45 minutes to your home, villa, apartment, or hotel room.
            </p>
          </div>
        </section>

        {/* Locations Directory Grid */}
        <section className="py-16">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {DUBAI_LOCATIONS.map((loc) => (
                <div
                  key={loc.id}
                  className="bg-white rounded-3xl border border-slate-200/90 hover:border-orange-300 shadow-sm brand-card-glow-hover p-6 flex flex-col justify-between transition-all group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-1 rounded-full">
                        {loc.zone}
                      </span>
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3 text-emerald-600" />
                        {loc.averageEtaMinutes}m Avg. ETA
                      </span>
                    </div>

                    <h2 className="text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors mb-2">
                      {loc.name}
                    </h2>

                    <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">
                      {loc.description}
                    </p>

                    <div className="space-y-1.5 pt-3 border-t border-slate-100">
                      <div className="text-[11px] font-bold text-slate-700">Key Sub-Communities:</div>
                      <div className="flex flex-wrap gap-1">
                        {loc.popularCommunities.slice(0, 4).map((comm, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium"
                          >
                            {comm}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 mt-4 border-t border-slate-100">
                    <Link
                      href={`/areas-we-serve/${loc.slug}/`}
                      className="w-full py-2.5 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm"
                    >
                      <span>Doctor in {loc.name}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
