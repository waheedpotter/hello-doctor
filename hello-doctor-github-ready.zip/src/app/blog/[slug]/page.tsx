import { notFound } from "next/navigation";
import { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { BLOG_POSTS, getPostBySlug } from "@/data/blog";
import { getDoctorBySlug } from "@/data/doctors";
import { constructMetadata } from "@/lib/seo";
import { generateArticleSchema, generateBreadcrumbSchema } from "@/lib/schema";
import { getWhatsAppBookingUrl, getDirectCallUrl } from "@/lib/utils";
import { Calendar, Clock, User, ShieldCheck, ArrowRight, Phone, MessageSquare, Tag } from "lucide-react";

export async function generateStaticParams() {
  return BLOG_POSTS.map((post) => ({
    slug: post.slug,
  }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) return {};

  return constructMetadata({
    title: post.title,
    description: post.metaDescription,
    canonicalPath: `/blog/${post.slug}/`,
    image: post.featuredImage,
  });
}

export default async function BlogPostDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) notFound();

  const author = getDoctorBySlug(post.authorDoctorId);
  const articleSchema = generateArticleSchema(post, author);
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Blog", item: "/blog/" },
    { name: post.title, item: `/blog/${post.slug}/` },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />

      <article className="bg-white py-10 lg:py-16">
        <div className="container mx-auto max-w-4xl px-4">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
            <Link href="/" className="hover:text-orange-600">Home</Link>
            <span>/</span>
            <Link href="/blog/" className="hover:text-orange-600">Blog</Link>
            <span>/</span>
            <span className="text-orange-600 font-semibold truncate max-w-xs">{post.title}</span>
          </nav>

          {/* Article Header */}
          <header className="space-y-4 mb-8">
            <span className="inline-block px-3 py-1 bg-orange-100 text-orange-900 text-xs font-bold rounded-full">
              {post.categoryName}
            </span>

            <h1 className="text-2xl sm:text-3xl md:text-5xl font-extrabold text-slate-950 tracking-tight leading-tight">
              {post.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-2 border-b border-slate-100 pb-4">
              {author && (
                <div className="flex items-center gap-2 font-semibold text-slate-800">
                  <div className="relative w-7 h-7 rounded-full overflow-hidden">
                    <Image src={author.image} alt={author.name} fill className="object-cover" />
                  </div>
                  <Link href={`/doctors/${author.slug}/`} className="hover:text-orange-600">
                    {author.name} (DHA Licensed)
                  </Link>
                </div>
              )}
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {post.publishedDate}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                {post.readingTimeMinutes} min read
              </span>
            </div>
          </header>

          {/* Featured Image */}
          <div className="relative h-72 sm:h-96 w-full rounded-3xl overflow-hidden mb-10 shadow-lg bg-slate-100">
            <Image
              src={post.featuredImage}
              alt={post.title}
              fill
              className="object-cover"
              priority
            />
          </div>

          {/* Article Content */}
          <div className="prose prose-slate prose-orange max-w-none text-slate-700 leading-relaxed space-y-5 text-sm sm:text-base">
            <div className="bg-orange-50/70 p-5 rounded-2xl border border-orange-200/70 text-slate-800 text-sm italic">
              <strong>Summary:</strong> {post.excerpt}
            </div>

            <div
              className="space-y-4"
              dangerouslySetInnerHTML={{
                __html: post.content
                  .replace(/## (.*?)\n/g, '<h2 class="text-xl sm:text-2xl font-bold text-slate-900 mt-6 mb-3">$1</h2>')
                  .replace(/### (.*?)\n/g, '<h3 class="text-lg sm:text-xl font-bold text-slate-900 mt-4 mb-2">$1</h3>')
                  .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                  .replace(/\n\n/g, '</p><p class="leading-relaxed">')
                  .replace(/^- (.*?)$/gm, '<li class="ml-4 list-disc">$1</li>')
              }}
            />
          </div>

          {/* Doctor Author Box */}
          {author && (
            <div className="mt-12 p-6 rounded-3xl bg-slate-50 border border-slate-200/90 flex flex-col sm:flex-row items-center gap-5">
              <div className="relative w-20 h-20 rounded-2xl overflow-hidden shrink-0 shadow-md">
                <Image src={author.image} alt={author.name} fill className="object-cover" />
              </div>
              <div className="space-y-1 text-center sm:text-left flex-1">
                <div className="text-xs font-bold text-orange-600 uppercase tracking-wider">
                  Medically Reviewed By
                </div>
                <h4 className="text-base font-bold text-slate-900">{author.name}</h4>
                <p className="text-xs text-slate-500">{author.designation} • DHA License: {author.dhaLicenseNumber}</p>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">{author.bio}</p>
              </div>
              <Link
                href={`/doctors/${author.slug}/`}
                className="px-4 py-2 bg-white text-orange-600 font-bold text-xs rounded-xl border border-orange-200 hover:bg-orange-50 transition-all shrink-0"
              >
                View Doctor Profile
              </Link>
            </div>
          )}

          {/* Inline CTA Box */}
          <div className="mt-12 p-8 rounded-3xl bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 text-white text-center space-y-4">
            <h3 className="text-xl sm:text-2xl font-bold">
              Need a DHA Licensed Doctor at Your Doorstep in Dubai?
            </h3>
            <p className="text-xs sm:text-sm text-orange-100 max-w-lg mx-auto">
              Our medical team arrives in 30-45 minutes across all Dubai areas 24/7 with full diagnostic equipment.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <a
                href={getWhatsAppBookingUrl(`Hello! I read your article "${post.title}" and would like to book a doctor at home.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-white text-orange-600 font-bold text-xs sm:text-sm rounded-xl shadow-lg hover:bg-orange-50 transition-all"
              >
                WhatsApp Doctor Dispatch
              </a>
              <a
                href={getDirectCallUrl()}
                className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-xl transition-all"
              >
                Call 24/7 Hotline
              </a>
            </div>
          </div>
        </div>
      </article>
    </>
  );
}
