import Link from "next/link";
import Image from "next/image";
import { Metadata } from "next";
import { BLOG_POSTS, BLOG_CATEGORIES } from "@/data/blog";
import { DOCTORS, getDoctorBySlug } from "@/data/doctors";
import { constructMetadata } from "@/lib/seo";
import { generateBreadcrumbSchema } from "@/lib/schema";
import { Clock, Calendar, ArrowRight, User, Tag } from "lucide-react";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "Medical Blog & Dubai Health Guides | Hello Doctor",
    description:
      "Expert healthcare articles, doctor-written wellness guides, IV drip therapy insights, and at-home medical care advice in Dubai, UAE.",
    canonicalPath: "/blog/",
  });
}

export default function BlogIndexPage() {
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Blog & Health Guides", item: "/blog/" },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />
      <div className="bg-white">
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-18 border-b border-orange-100/60">
          <div className="container mx-auto text-center max-w-3xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-950 text-xs font-bold uppercase tracking-wider mb-3">
              Doctor-Reviewed Health Articles
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight">
              Dubai Healthcare & <span className="brand-gradient-text">Wellness Guides</span>
            </h1>
            <p className="mt-4 text-base text-slate-600 leading-relaxed">
              Medical knowledge and insights curated by DHA-licensed physicians and home care specialists.
            </p>
          </div>
        </section>

        {/* Categories Bar */}
        <section className="border-b border-slate-100 py-4 bg-slate-50">
          <div className="container mx-auto flex items-center justify-center gap-3 overflow-x-auto">
            <Link
              href="/blog/"
              className="px-4 py-1.5 rounded-full bg-orange-600 text-white text-xs font-bold whitespace-nowrap"
            >
              All Articles
            </Link>
            {BLOG_CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                href={`/category/${cat.slug}/`}
                className="px-4 py-1.5 rounded-full bg-white text-slate-700 hover:text-orange-600 border border-slate-200 text-xs font-semibold whitespace-nowrap transition-colors"
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </section>

        {/* Blog Post Grid */}
        <section className="py-16">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {BLOG_POSTS.map((post) => {
                const author = getDoctorBySlug(post.authorDoctorId);
                return (
                  <article
                    key={post.id}
                    className="bg-white rounded-3xl border border-slate-200 hover:border-orange-300 shadow-sm brand-card-glow-hover flex flex-col justify-between overflow-hidden transition-all group"
                  >
                    <div>
                      <div className="relative h-56 w-full bg-slate-100">
                        <Image
                          src={post.featuredImage}
                          alt={post.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-orange-600">
                          {post.categoryName}
                        </div>
                      </div>

                      <div className="p-6 space-y-3">
                        <div className="flex items-center gap-3 text-xs text-slate-400">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            {post.publishedDate}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" />
                            {post.readingTimeMinutes} min read
                          </span>
                        </div>

                        <h2 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors leading-snug">
                          <Link href={`/blog/${post.slug}/`}>
                            {post.title}
                          </Link>
                        </h2>

                        <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                          {post.excerpt}
                        </p>

                        {author && (
                          <div className="pt-3 flex items-center gap-2 text-xs text-slate-600 border-t border-slate-100">
                            <div className="relative w-6 h-6 rounded-full overflow-hidden">
                              <Image src={author.image} alt={author.name} fill className="object-cover" />
                            </div>
                            <span>By <strong>{author.name}</strong></span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="p-6 pt-0">
                      <Link
                        href={`/blog/${post.slug}/`}
                        className="text-xs font-bold text-orange-600 hover:underline flex items-center justify-between pt-3 border-t border-slate-100"
                      >
                        <span>Read Full Guide</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
