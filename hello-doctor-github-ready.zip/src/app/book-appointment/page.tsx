import { Metadata } from "next";
import { constructMetadata } from "@/lib/seo";
import { HeroSection } from "@/components/home/HeroSection";
import { TrustSignals } from "@/components/home/TrustSignals";
import { FAQSection } from "@/components/home/FAQSection";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "Book Doctor at Home Appointment | 24/7 Dubai Doctor on Call",
    description:
      "Book an immediate or scheduled DHA doctor visit in Dubai. 30-45 mins arrival to your doorstep with full medical diagnostic equipment and prescriptions.",
    canonicalPath: "/book-appointment/",
  });
}

export default function BookAppointmentPage() {
  return (
    <div className="bg-white">
      <HeroSection />
      <TrustSignals />
      <FAQSection />
    </div>
  );
}
