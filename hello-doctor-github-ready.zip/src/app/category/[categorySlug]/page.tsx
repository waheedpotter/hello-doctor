import { notFound } from "next/navigation";
import { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { BLOG_CATEGORIES, BLOG_POSTS } from "@/data/blog";
import { constructMetadata } from "@/lib/seo";
import { generateBreadcrumbSchema } from "@/lib/schema";
import { Calendar, Clock, ArrowRight } from "lucide-react";

export async function generateStaticParams() {
  return BLOG_CATEGORIES.map((cat) => ({
    categorySlug: cat.slug,
  }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ categorySlug: string }>;
}): Promise<Metadata> {
  const { categorySlug } = await params;
  const category = BLOG_CATEGORIES.find((c) => c.slug === categorySlug);
  if (!category) return {};

  return constructMetadata({
    title: `${category.name} Articles & Guides | Hello Doctor Dubai`,
    description: category.description,
    canonicalPath: `/category/${category.slug}/`,
  });
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ categorySlug: string }>;
}) {
  const { categorySlug } = await params;
  const category = BLOG_CATEGORIES.find((c) => c.slug === categorySlug);
  if (!category) notFound();

  const posts = BLOG_POSTS.filter((p) => p.categorySlug === categorySlug);
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Blog", item: "/blog/" },
    { name: category.name, item: `/category/${category.slug}/` },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />
      <div className="bg-white">
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-18 border-b border-orange-100/60">
          <div className="container mx-auto text-center max-w-3xl">
            <span className="inline-block px-3 py-1 bg-orange-100 text-orange-950 text-xs font-bold rounded-full uppercase tracking-wider mb-2">
              Category Archive
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950">
              {category.name}
            </h1>
            <p className="mt-3 text-base text-slate-600">
              {category.description}
            </p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.map((post) => (
                <article
                  key={post.id}
                  className="bg-white rounded-3xl border border-slate-200 hover:border-orange-300 shadow-sm brand-card-glow-hover flex flex-col justify-between overflow-hidden transition-all group"
                >
                  <div>
                    <div className="relative h-56 w-full bg-slate-100">
                      <Image
                        src={post.featuredImage}
                        alt={post.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>

                    <div className="p-6 space-y-3">
                      <div className="flex items-center gap-3 text-xs text-slate-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {post.publishedDate}
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {post.readingTimeMinutes} min read
                        </span>
                      </div>

                      <h2 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors leading-snug">
                        <Link href={`/blog/${post.slug}/`}>
                          {post.title}
                        </Link>
                      </h2>

                      <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                        {post.excerpt}
                      </p>
                    </div>
                  </div>

                  <div className="p-6 pt-0">
                    <Link
                      href={`/blog/${post.slug}/`}
                      className="text-xs font-bold text-orange-600 hover:underline flex items-center justify-between pt-3 border-t border-slate-100"
                    >
                      <span>Read Full Guide</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
