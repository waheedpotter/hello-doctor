import { Metadata } from "next";
import Link from "next/link";
import { constructMetadata } from "@/lib/seo";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { FastTriageForm } from "@/components/contact/FastTriageForm";
import { ContactFAQAccordion } from "@/components/contact/ContactFAQAccordion";
import { CONTACT_FAQS } from "@/data/contact-faqs";
import { StickyMobileContactBar } from "@/components/contact/StickyMobileContactBar";
import {
  PhoneCall,
  MessageSquare,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  Building,
  Globe2,
  AlertCircle,
  ExternalLink,
  CheckCircle2,
  Car,
  Compass,
  Zap,
  ArrowRight,
  ShieldAlert
} from "lucide-react";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "Contact Hello Doctor Dubai | 24/7 Medical Dispatch & Doctor on Call",
    description:
      "Contact Hello Doctor Home Health Care LLC 24/7. Call +971 55 253 7940 or WhatsApp for immediate doctor home visits, nursing, IV drips & lab tests in Dubai in 30–45 mins.",
    canonicalPath: "/contact-us/",
  });
}

export default function ContactUsPage() {
  // JSON-LD Schemas
  const contactPageSchema = {
    "@context": "https://schema.org",
    "@type": "ContactPage",
    "@id": `${SITE_CONFIG.url}/contact-us/#webpage`,
    url: `${SITE_CONFIG.url}/contact-us/`,
    name: "Contact Hello Doctor Dubai | 24/7 Medical Dispatch Hub",
    description:
      "Central 24/7 medical dispatch and inquiry portal for Hello Doctor Home Health Care LLC across Dubai. Urgent doctor at home, hotel visits, home nursing, IV drip therapy, and lab tests.",
    isPartOf: {
      "@type": "WebSite",
      "@id": `${SITE_CONFIG.url}/#website`,
      name: SITE_CONFIG.name,
      url: SITE_CONFIG.url,
    },
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: `${SITE_CONFIG.url}/`,
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Contact Us",
          item: `${SITE_CONFIG.url}/contact-us/`,
        },
      ],
    },
  };

  const medicalBusinessSchema = {
    "@context": "https://schema.org",
    "@type": ["MedicalBusiness", "HomeHealthCareService", "EmergencyService"],
    "@id": `${SITE_CONFIG.url}/#organization`,
    name: SITE_CONFIG.name,
    legalName: SITE_CONFIG.legalName,
    url: SITE_CONFIG.url,
    telephone: SITE_CONFIG.phone,
    email: SITE_CONFIG.email,
    duns: SITE_CONFIG.dhaLicense,
    priceRange: "AED 199 - AED 1800",
    address: {
      "@type": "PostalAddress",
      streetAddress: SITE_CONFIG.address.streetAddress,
      addressLocality: "Al Barsha 1",
      addressRegion: "Dubai",
      postalCode: "00000",
      addressCountry: "AE",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: 25.1189,
      longitude: 55.2017,
    },
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "00:00",
        closes: "23:59",
      },
    ],
    contactPoint: [
      {
        "@type": "ContactPoint",
        telephone: SITE_CONFIG.phone,
        contactType: "emergency",
        availableLanguage: ["English", "Arabic", "Hindi", "Urdu", "French", "Russian"],
        areaServed: "Dubai",
      },
      {
        "@type": "ContactPoint",
        telephone: `+${SITE_CONFIG.whatsappNumber}`,
        contactType: "customer support",
        availableLanguage: ["English", "Arabic", "Hindi", "Urdu"],
        areaServed: "Dubai",
      },
    ],
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: CONTACT_FAQS.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  const RESPONSE_ZONES = [
    { zone: "Downtown Dubai / DIFC / Business Bay", eta: "30 Mins", color: "text-orange-600 bg-orange-50 border-orange-200" },
    { zone: "Dubai Marina / JLT / Palm Jumeirah / JBR", eta: "30 Mins", color: "text-emerald-700 bg-emerald-50 border-emerald-200" },
    { zone: "Al Barsha / Dubai Hills Estate / JVC", eta: "25–35 Mins", color: "text-amber-700 bg-amber-50 border-amber-200" },
    { zone: "Arabian Ranches / Mirdif / Deira / Creek", eta: "35–45 Mins", color: "text-blue-700 bg-blue-50 border-blue-200" },
  ];

  return (
    <>
      {/* Schema.org Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(contactPageSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(medicalBusinessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div className="bg-white pb-20 md:pb-12">
        {/* Section 1: Hero Section */}
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-18 border-b border-orange-100/60">
          <div className="container mx-auto text-center max-w-4xl px-4">
            {/* Status Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-extrabold uppercase tracking-wider mb-4 shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span>24/7 Rapid Medical Dispatch Live Across All Dubai Areas</span>
            </div>

            {/* H1 Title */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight leading-tight">
              Contact Hello Doctor — <span className="brand-gradient-text">24/7 Medical Dispatch</span> & Doctor on Call in Dubai
            </h1>

            {/* Subheadline */}
            <p className="mt-4 text-sm sm:text-base md:text-lg text-slate-600 leading-relaxed max-w-3xl mx-auto">
              Need immediate medical care at your home, hotel, or office? Our DHA-licensed medical coordination team is active 24/7, 365 days a year. We dispatch mobile doctor and nursing units across Dubai with an average arrival time of 30 to 45 minutes.
            </p>

            {/* Core Verification Signals Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 mt-8 text-left max-w-3xl mx-auto">
              <div className="p-3.5 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl brand-gradient-bg text-white flex items-center justify-center shrink-0 shadow-sm">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-extrabold text-slate-900">30–45 Minutes</div>
                  <div className="text-[11px] text-slate-500">Average Dispatch Time</div>
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-extrabold text-slate-900">DHA #{SITE_CONFIG.dhaLicense}</div>
                  <div className="text-[11px] text-slate-500">Licensed Facility</div>
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <Building className="w-4 h-4 text-orange-400" />
                </div>
                <div>
                  <div className="text-xs font-extrabold text-slate-900">Al Barsha 1</div>
                  <div className="text-[11px] text-slate-500">Headquarters, Dubai</div>
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <Globe2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-extrabold text-slate-900">Multilingual</div>
                  <div className="text-[11px] text-slate-500">EN, AR, HI, UR, RU</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2: Direct Contact Channels Grid (4 Action Cards) */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <span className="text-xs font-bold text-orange-600 uppercase tracking-wider bg-orange-100 px-3 py-1 rounded-full">
                Immediate Multi-Channel Access
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
                Choose Your Preferred Contact Channel
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Card 1: Emergency Call Center */}
              <div className="bg-white rounded-3xl border border-orange-200/90 hover:border-orange-400 shadow-sm hover:shadow-xl transition-all p-6 flex flex-col justify-between group">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-2xl brand-gradient-bg text-white flex items-center justify-center shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
                      <PhoneCall className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-extrabold text-orange-700 bg-orange-100 px-2.5 py-1 rounded-full border border-orange-200">
                      Instant Answer (&lt;15s)
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                      24/7 Phone Dispatch
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      Immediate clinical triage and doctor deployment across Dubai.
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <a
                    href={getDirectCallUrl()}
                    className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-orange-400" />
                    <span>Call {SITE_CONFIG.phoneDisplay}</span>
                  </a>
                </div>
              </div>

              {/* Card 2: WhatsApp Medical Desk */}
              <div className="bg-white rounded-3xl border border-emerald-200/90 hover:border-emerald-400 shadow-sm hover:shadow-xl transition-all p-6 flex flex-col justify-between group">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-full border border-emerald-200">
                      Available 24/7
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                      WhatsApp Doctor Desk
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      Send symptoms, location pins, or voice notes for rapid dispatch.
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <a
                    href={getWhatsAppBookingUrl(
                      "Hello Doctor! I need medical assistance at my home/hotel in Dubai. Please assist immediately."
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Chat on WhatsApp</span>
                  </a>
                </div>
              </div>

              {/* Card 3: Official Email Desk */}
              <div className="bg-white rounded-3xl border border-slate-200 hover:border-orange-300 shadow-sm hover:shadow-xl transition-all p-6 flex flex-col justify-between group">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
                      <Mail className="w-6 h-6 text-orange-400" />
                    </div>
                    <span className="text-[10px] font-extrabold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
                      Replies in &lt;2 hrs
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                      Corporate & Billing Inquiries
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      Insurance receipts, sick note verification, and corporate wellness partnerships.
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <a
                    href={`mailto:${SITE_CONFIG.email}`}
                    className="w-full py-3 bg-orange-50 hover:bg-orange-100 text-orange-700 text-xs font-extrabold rounded-xl flex items-center justify-center gap-2 border border-orange-200/70 transition-all"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{SITE_CONFIG.email}</span>
                  </a>
                </div>
              </div>

              {/* Card 4: Central Clinic Headquarters */}
              <div className="bg-white rounded-3xl border border-slate-200 hover:border-orange-300 shadow-sm hover:shadow-xl transition-all p-6 flex flex-col justify-between group">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-extrabold text-amber-900 bg-amber-100 px-2.5 py-1 rounded-full border border-amber-200">
                      Licensed Facility
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                      Physical Headquarters
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      Espada Office, Rasis Business Centre, ZNAB-90, 6th Floor, Al Barsha 1, Dubai.
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <a
                    href="https://maps.google.com/?q=Rasis+Business+Centre+Al+Barsha+1+Dubai"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-extrabold rounded-xl flex items-center justify-center gap-1.5 transition-all"
                  >
                    <span>View on Google Maps</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Dual-Column Dispatch Form & Facility Details */}
        <section className="py-12 bg-slate-50/60 border-y border-slate-200/80">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
              {/* Column 1: 60-Second Fast-Triage Booking Form (7 Cols) */}
              <div className="lg:col-span-7">
                <FastTriageForm />
              </div>

              {/* Column 2: Facility Credibility & Dubai Coverage Map (5 Cols) */}
              <div className="lg:col-span-5 space-y-6">
                {/* Facility Credibility Card */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-sm space-y-4">
                  <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                    <Building className="w-5 h-5 text-orange-600" />
                    <div>
                      <h3 className="text-sm font-extrabold text-slate-900">
                        {SITE_CONFIG.legalName}
                      </h3>
                      <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>DHA Facility License No: {SITE_CONFIG.dhaLicense}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs text-slate-700">
                    <div className="flex items-start gap-2.5">
                      <MapPin className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                      <div>
                        <strong>Address:</strong> {SITE_CONFIG.address.streetAddress}, Dubai, United Arab Emirates.
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div>
                        <strong>Working Hours:</strong> Open 24 Hours, 7 Days a Week, 365 Days a Year.
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <Globe2 className="w-4 h-4 text-amber-500 shrink-0" />
                      <div>
                        <strong>Service Area:</strong> All residential villas, apartments, hotels, and corporate offices across Dubai.
                      </div>
                    </div>
                  </div>
                </div>

                {/* Response Time Radius Map */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-sm space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <Car className="w-5 h-5 text-orange-600" />
                      <h3 className="text-sm font-extrabold text-slate-900">
                        Dubai Estimated Response Time
                      </h3>
                    </div>
                    <span className="text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">
                      Mobile Fleet Active
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {RESPONSE_ZONES.map((zone, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3 text-xs"
                      >
                        <span className="font-semibold text-slate-800">{zone.zone}</span>
                        <span className={`px-2.5 py-1 rounded-xl font-extrabold text-[11px] border shrink-0 ${zone.color}`}>
                          {zone.eta}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 text-center">
                    <Link
                      href="/areas-we-serve/"
                      className="text-xs font-bold text-orange-600 hover:underline inline-flex items-center gap-1"
                    >
                      <span>Explore all 20+ covered Dubai neighborhoods & ETA map</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>

                {/* Emergency 998 Disclaimer Box */}
                <div className="bg-red-50/90 rounded-3xl border border-red-200 p-5 flex items-start gap-3.5">
                  <ShieldAlert className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-red-950 uppercase tracking-wider">
                      Critical Emergency Notice
                    </div>
                    <p className="text-xs text-red-900 leading-relaxed">
                      For critical life-threatening emergencies (severe acute chest pain, sudden stroke symptoms, uncontrollable bleeding, or major trauma), please dial <strong>998 immediately for Dubai Ambulance</strong>.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 4: Contact & Booking FAQ Accordion */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-xs font-bold text-orange-600 uppercase tracking-wider bg-orange-100 px-3 py-1 rounded-full">
                Help & Dispatch Information
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
                Frequently Asked Contact & Dispatch Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-2">
                Everything you need to know about booking, doctor arrival times, and insurance documentation.
              </p>
            </div>

            <ContactFAQAccordion />
          </div>
        </section>

        {/* Floating Mobile Sticky Contact Bar */}
        <StickyMobileContactBar />
      </div>
    </>
  );
}
