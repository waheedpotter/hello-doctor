import { notFound } from "next/navigation";
import { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { DOCTORS, getDoctorBySlug } from "@/data/doctors";
import { constructMetadata } from "@/lib/seo";
import { generatePhysicianSchema, generateBreadcrumbSchema } from "@/lib/schema";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import {
  ShieldCheck,
  Clock,
  MapPin,
  GraduationCap,
  Languages,
  CheckCircle2,
  Phone,
  MessageSquare,
  Stethoscope,
  ArrowRight,
  Award
} from "lucide-react";

export async function generateStaticParams() {
  return DOCTORS.map((doc) => ({
    slug: doc.slug,
  }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const doctor = getDoctorBySlug(slug);
  if (!doctor) return {};

  return constructMetadata({
    title: `${doctor.name} - ${doctor.roleTitle || doctor.designation} (${doctor.specialty})`,
    description: `Book an in-home consultation with ${doctor.name}, DHA licensed ${doctor.roleTitle || doctor.specialty} in Dubai. ${doctor.experienceYears}+ years experience. Fast doorstep arrival.`,
    canonicalPath: `/doctors/${doctor.slug}/`,
    image: doctor.image,
  });
}

export default async function DoctorProfilePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const doctor = getDoctorBySlug(slug);
  if (!doctor) notFound();

  const physicianSchema = generatePhysicianSchema(doctor);
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Doctors & Clinical Team", item: "/doctors/" },
    { name: doctor.name, item: `/doctors/${doctor.slug}/` },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(physicianSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />

      <div className="bg-white">
        {/* Profile Hero */}
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-10 lg:py-16 border-b border-orange-100/60">
          <div className="container mx-auto">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
              <Link href="/" className="hover:text-orange-600">Home</Link>
              <span>/</span>
              <Link href="/doctors/" className="hover:text-orange-600">Doctors</Link>
              <span>/</span>
              <span className="text-orange-600 font-semibold">{doctor.name}</span>
            </nav>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Doctor Photo & Quick Stats */}
              <div className="lg:col-span-4 space-y-4">
                <div className="relative h-96 w-full rounded-3xl overflow-hidden shadow-xl border border-orange-100 bg-slate-100">
                  <Image
                    src={doctor.image}
                    alt={doctor.name}
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-slate-900 flex items-center gap-1.5 shadow-md">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>DHA License: {doctor.dhaLicenseNumber}</span>
                  </div>
                  {doctor.roleTitle === "Medical Director" && (
                    <div className="absolute top-4 right-4 bg-amber-500 text-white px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-md">
                      <Award className="w-3.5 h-3.5" />
                      <span>Director</span>
                    </div>
                  )}
                </div>

                <div className="bg-orange-50/80 p-5 rounded-2xl border border-orange-200/80 space-y-3 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Availability:</span>
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-emerald-600" />
                      24/7 Home & Hotel Visits
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Experience:</span>
                    <span className="font-bold text-slate-800">{doctor.experienceYears}+ Years</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Languages:</span>
                    <span className="font-bold text-slate-800">{doctor.languages.join(", ")}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Consultation Fee:</span>
                    <span className="font-extrabold text-orange-600">From AED {doctor.consultationFeeAed}</span>
                  </div>
                </div>
              </div>

              {/* Doctor Bio, Qualifications & Booking */}
              <div className="lg:col-span-8 space-y-6">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-950 text-xs font-bold mb-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                    <span>{doctor.roleTitle ? `${doctor.roleTitle} • ${doctor.designation}` : doctor.designation}</span>
                  </div>
                  <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950">
                    {doctor.name}
                  </h1>
                  <p className="text-base text-orange-600 font-semibold mt-1">
                    Specialty: {doctor.specialty}
                  </p>
                </div>

                {/* Bio */}
                <div className="space-y-3">
                  <h2 className="text-lg font-bold text-slate-900">About {doctor.name}</h2>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {doctor.bio}
                  </p>
                </div>

                {/* Qualifications & Education */}
                <div className="space-y-3 pt-2">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <GraduationCap className="w-5 h-5 text-orange-600" />
                    <span>Education & Board Certifications</span>
                  </h3>
                  <div className="space-y-2">
                    {doctor.education.map((edu, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-xs font-medium text-slate-700 flex items-center gap-2"
                      >
                        <span className="w-2 h-2 rounded-full bg-orange-500" />
                        <span>{edu}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Available Areas */}
                <div className="space-y-2 pt-2">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-orange-600" />
                    <span>Areas Served for Home Visits</span>
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {doctor.availableAreas.map((area, idx) => (
                      <span
                        key={idx}
                        className="text-xs bg-orange-50 text-orange-900 font-semibold px-3 py-1.5 rounded-xl border border-orange-200/60"
                      >
                        {area}
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTAs */}
                <div className="flex flex-col sm:flex-row items-center gap-3.5 pt-4 border-t border-slate-200">
                  <a
                    href={getWhatsAppBookingUrl(`Hello! I would like to book an in-home medical consultation with ${doctor.name} in Dubai.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto px-7 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all"
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span>Book {doctor.name} on WhatsApp</span>
                  </a>

                  <a
                    href={getDirectCallUrl()}
                    className="w-full sm:w-auto px-6 py-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 transition-all"
                  >
                    <Phone className="w-4 h-4 text-orange-400" />
                    <span>Call 24/7 Hotline</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
