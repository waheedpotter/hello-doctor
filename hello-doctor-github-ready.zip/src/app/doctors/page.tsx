import Link from "next/link";
import Image from "next/image";
import { Metadata } from "next";
import { DOCTORS } from "@/data/doctors";
import { constructMetadata } from "@/lib/seo";
import { generateBreadcrumbSchema } from "@/lib/schema";
import { ShieldCheck, Clock, MapPin, ArrowRight, Stethoscope, Award } from "lucide-react";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "DHA Licensed Doctors & Medical Team in Dubai | Hello Doctor",
    description:
      "Meet our DHA-licensed medical leadership and team: Medical Director Dr. Sukhwinder Kaur, General Practitioners Dr. Imran Qureshi and Dr. Israel Oyinchi Isaac, and DHA Registered Nurse Baso Bai.",
    canonicalPath: "/doctors/",
  });
}

export default function DoctorsDirectoryPage() {
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Doctors & Clinical Team", item: "/doctors/" },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />
      <div className="bg-white">
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-18 border-b border-orange-100/60">
          <div className="container mx-auto text-center max-w-3xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-950 text-xs font-bold uppercase tracking-wider mb-3">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              100% DHA Licensed Medical Leadership & Staff
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight">
              Our DHA Licensed <span className="brand-gradient-text">Doctors & Medical Team</span>
            </h1>
            <p className="mt-4 text-base text-slate-600 leading-relaxed">
              Led by Medical Director Dr. Sukhwinder Kaur, our team of board-certified general practitioners and registered nurses delivers 24/7 hospital-standard care directly to your residence, hotel, or villa in Dubai.
            </p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {DOCTORS.map((doc) => (
                <div
                  key={doc.id}
                  className="bg-white rounded-3xl border border-slate-200 hover:border-orange-300 shadow-sm brand-card-glow-hover flex flex-col justify-between overflow-hidden transition-all duration-300 group"
                >
                  <div>
                    <div className="relative h-72 w-full bg-slate-100">
                      <Image
                        src={doc.image}
                        alt={`${doc.name} - ${doc.designation}`}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-slate-900 flex items-center gap-1 shadow-sm">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{doc.dhaLicenseNumber}</span>
                      </div>
                      {doc.roleTitle === "Medical Director" && (
                        <div className="absolute top-3 right-3 bg-amber-500 text-white px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 shadow-sm">
                          <Award className="w-3 h-3" />
                          <span>Director</span>
                        </div>
                      )}
                    </div>

                    <div className="p-6 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                          doc.roleTitle === "Medical Director"
                            ? "bg-amber-100 text-amber-900 border border-amber-300"
                            : doc.roleTitle === "DHA Registered Nurse"
                            ? "bg-emerald-100 text-emerald-900 border border-emerald-300"
                            : "bg-orange-100 text-orange-900 border border-orange-200"
                        }`}>
                          {doc.roleTitle || doc.specialty}
                        </span>
                        <span className="text-[11px] font-semibold text-orange-600">
                          {doc.experienceYears}+ Years Exp.
                        </span>
                      </div>

                      <h2 className="text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                        {doc.name}
                      </h2>

                      <p className="text-xs font-semibold text-slate-600">
                        {doc.specialty}
                      </p>

                      <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">
                        {doc.bio}
                      </p>

                      <div className="pt-2 text-xs text-slate-600 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-orange-500" />
                          <span>24/7 Home & Hotel Visits</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-orange-500" />
                          <span className="truncate">Languages: {doc.languages.join(", ")}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 pt-0">
                    <Link
                      href={`/doctors/${doc.slug}/`}
                      className="w-full py-3 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm"
                    >
                      <Stethoscope className="w-3.5 h-3.5" />
                      <span>View Profile & Book</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
