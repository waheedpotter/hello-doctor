import type { Metadata } from "next";
import "@/styles/globals.css";
import { BookingProvider } from "@/components/booking/BookingContext";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { FloatingMobileBar } from "@/components/layout/FloatingMobileBar";
import { FloatingEmergencyTicker } from "@/components/layout/FloatingEmergencyTicker";
import { BookingModal } from "@/components/booking/BookingModal";
import { generateMedicalBusinessSchema } from "@/lib/schema";
import { SITE_CONFIG } from "@/lib/utils";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_CONFIG.url),
  title: {
    default: "Hello Doctor Dubai | 24/7 Doctor at Home, IV Drip & Home Care",
    template: "%s | Hello Doctor Dubai",
  },
  description:
    "DHA Licensed 24/7 Doctor at Home in Dubai. Our emergency GP doctors and nurses arrive at your doorstep, hotel, or villa in 30-45 minutes. Prescriptions, IV drips & tests on-site.",
  keywords: [
    "doctor at home dubai",
    "doctor on call dubai",
    "iv drip at home dubai",
    "home nursing dubai",
    "blood test at home dubai",
    "hotel doctor dubai",
    "physiotherapy at home dubai",
    "dha doctor at home",
    "hello doctor dubai",
  ],
  authors: [{ name: SITE_CONFIG.legalName, url: SITE_CONFIG.url }],
  creator: SITE_CONFIG.legalName,
  publisher: SITE_CONFIG.legalName,
  alternates: {
    canonical: SITE_CONFIG.url,
  },
  openGraph: {
    type: "website",
    locale: "en_AE",
    url: SITE_CONFIG.url,
    siteName: SITE_CONFIG.name,
    title: "Hello Doctor Dubai | 24/7 Doctor at Home, IV Drip & Home Care",
    description:
      "DHA Licensed 24/7 Doctor at Home in Dubai. Fast 30-45 minute arrival to your doorstep with full medical equipment & prescriptions.",
    images: [
      {
        url: `${SITE_CONFIG.url}/images/logo.png`,
        width: 1200,
        height: 630,
        alt: "Hello Doctor Dubai Home Healthcare",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Hello Doctor Dubai | 24/7 Doctor at Home",
    description:
      "DHA Licensed 24/7 Doctor at Home in Dubai. Fast 30-45 minute arrival to your doorstep.",
    images: [`${SITE_CONFIG.url}/images/logo.png`],
  },
  icons: {
    icon: "/favicon.ico",
    apple: "/images/logo.png",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const jsonLd = generateMedicalBusinessSchema();

  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className="min-h-screen flex flex-col font-sans antialiased text-slate-900 bg-white selection:bg-orange-500 selection:text-white">
        <BookingProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <FloatingMobileBar />
          <FloatingEmergencyTicker />
          <BookingModal />
        </BookingProvider>
      </body>
    </html>
  );
}
