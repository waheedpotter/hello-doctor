import { HeroSection } from "@/components/home/HeroSection";
import { TrustSignals } from "@/components/home/TrustSignals";
import { ServiceGrid } from "@/components/home/ServiceGrid";
import { HowItWorks } from "@/components/home/HowItWorks";
import { DoctorShowcase } from "@/components/home/DoctorShowcase";
import { DubaiCoverageMap } from "@/components/home/DubaiCoverageMap";
import { ReviewsSection } from "@/components/home/ReviewsSection";
import { FAQSection } from "@/components/home/FAQSection";
import { CTASection } from "@/components/home/CTASection";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <TrustSignals />
      <ServiceGrid />
      <HowItWorks />
      <DoctorShowcase />
      <DubaiCoverageMap />
      <ReviewsSection />
      <FAQSection />
      <CTASection />
    </>
  );
}
