import Link from "next/link";
import Image from "next/image";
import { Metadata } from "next";
import { SERVICES } from "@/data/services";
import { constructMetadata } from "@/lib/seo";
import { generateBreadcrumbSchema, generateMedicalBusinessSchema } from "@/lib/schema";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { ServicesDirectoryClient } from "@/components/services/ServicesDirectoryClient";
import {
  ShieldCheck,
  Clock,
  MapPin,
  ArrowRight,
  Stethoscope,
  Droplet,
  HeartPulse,
  FlaskConical,
  Activity,
  Hotel,
  Sparkles,
  Zap,
  Phone,
  MessageSquare,
  CheckCircle2
} from "lucide-react";

export async function generateMetadata(): Promise<Metadata> {
  return constructMetadata({
    title: "24/7 DHA Licensed Medical Services at Home in Dubai | Hello Doctor",
    description:
      "Explore Hello Doctor's DHA-licensed in-home medical services in Dubai. Doctor on call, IV drip therapy, home nursing, blood tests, physiotherapy, elderly care, and peptide treatments delivered in 30-45 mins.",
    canonicalPath: "/services/",
  });
}

export default function ServicesDirectoryPage() {
  const breadcrumbs = generateBreadcrumbSchema([
    { name: "Home", item: "/" },
    { name: "Medical Services", item: "/services/" },
  ]);
  const businessSchema = generateMedicalBusinessSchema();

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(businessSchema) }}
      />

      <div className="bg-white">
        {/* Page Hero */}
        <section className="bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 py-12 lg:py-18 border-b border-orange-100/60">
          <div className="container mx-auto text-center max-w-3xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-950 text-xs font-bold uppercase tracking-wider mb-3">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              100% DHA Licensed Home Healthcare Services in Dubai
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight">
              Our In-Home <span className="brand-gradient-text">Medical Services</span>
            </h1>
            <p className="mt-4 text-base text-slate-600 leading-relaxed">
              Hospital-standard healthcare delivered straight to your residence, villa, hotel room, or workplace across Dubai within 30-45 minutes. From acute physician visits to rejuvenating IV drips and certified bedside nursing.
            </p>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 max-w-2xl mx-auto text-left">
              <div className="p-3 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-2.5">
                <Clock className="w-5 h-5 text-orange-600 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-slate-900">30-45 Mins</div>
                  <div className="text-[10px] text-slate-500">Fast Doorstep ETA</div>
                </div>
              </div>

              <div className="p-3 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-slate-900">DHA Licensed</div>
                  <div className="text-[10px] text-slate-500">Doctors & Nurses</div>
                </div>
              </div>

              <div className="p-3 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-2.5">
                <Zap className="w-5 h-5 text-amber-500 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-slate-900">24/7 Coverage</div>
                  <div className="text-[10px] text-slate-500">All Dubai Zones</div>
                </div>
              </div>

              <div className="p-3 bg-white rounded-2xl border border-orange-100 shadow-sm flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Insurance Docs</div>
                  <div className="text-[10px] text-slate-500">Itemized Invoices</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Interactive Services Directory Component */}
        <ServicesDirectoryClient services={SERVICES} />
      </div>
    </>
  );
}
