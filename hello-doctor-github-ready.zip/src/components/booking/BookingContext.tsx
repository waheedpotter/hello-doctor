"use client";

import React, { createContext, useContext, useState, ReactNode } from "react";

interface BookingModalOptions {
  serviceSlug?: string;
  serviceName?: string;
  areaSlug?: string;
}

interface BookingContextType {
  isOpen: boolean;
  openBooking: (options?: BookingModalOptions) => void;
  closeBooking: () => void;
  selectedService: string;
  setSelectedService: (service: string) => void;
  selectedArea: string;
  setSelectedArea: (area: string) => void;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export function BookingProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedService, setSelectedService] = useState("doctor-at-home-dubai");
  const [selectedArea, setSelectedArea] = useState("downtown-dubai");

  const openBooking = (options?: BookingModalOptions) => {
    if (options?.serviceSlug) setSelectedService(options.serviceSlug);
    if (options?.areaSlug) setSelectedArea(options.areaSlug);
    setIsOpen(true);
  };

  const closeBooking = () => {
    setIsOpen(false);
  };

  return (
    <BookingContext.Provider
      value={{
        isOpen,
        openBooking,
        closeBooking,
        selectedService,
        setSelectedService,
        selectedArea,
        setSelectedArea,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error("useBooking must be used within a BookingProvider");
  }
  return context;
}
