"use client";

import React, { useState } from "react";
import { useBooking } from "./BookingContext";
import { SERVICES } from "@/data/services";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { SITE_CONFIG, getWhatsAppBookingUrl, getDirectCallUrl } from "@/lib/utils";
import {
  X,
  Clock,
  MapPin,
  Stethoscope,
  Phone,
  MessageSquare,
  CheckCircle2,
  ShieldCheck,
  Zap,
  ArrowRight,
  ArrowLeft,
  Calendar,
  AlertCircle
} from "lucide-react";

export function BookingModal() {
  const { isOpen, closeBooking, selectedService, setSelectedService, selectedArea, setSelectedArea } = useBooking();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [urgency, setUrgency] = useState<"immediate" | "scheduled">("immediate");
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("10:00 AM - 12:00 PM");
  const [patientName, setPatientName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [addressDetails, setAddressDetails] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const currentServiceObj = SERVICES.find((s) => s.slug === selectedService) || SERVICES[0];
  const currentAreaObj = DUBAI_LOCATIONS.find((l) => l.slug === selectedArea) || DUBAI_LOCATIONS[0];

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep((prev) => (prev + 1) as 1 | 2 | 3 | 4);
    } else {
      // Step 3 submission
      setIsSubmitting(true);
      setTimeout(() => {
        setIsSubmitting(false);
        setStep(4);
      }, 600);
    }
  };

  const handleWhatsAppDispatch = () => {
    const message = `*URGENT MEDICAL BOOKING - HELLO DOCTOR DUBAI*
━━━━━━━━━━━━━━━━━━━━
🩺 *Service:* ${currentServiceObj.title.split("|")[0].trim()}
📍 *Area:* ${currentAreaObj.name} (${addressDetails || "Address given on call"})
⏱️ *Timing:* ${urgency === "immediate" ? "🚨 IMMEDIATE DISPATCH (30-45 Mins)" : `📅 Scheduled for ${scheduledDate} at ${scheduledTime}`}
👤 *Patient Name:* ${patientName || "Not provided"}
📞 *Phone:* ${phoneNumber || "Same as WhatsApp"}
📝 *Symptoms:* ${symptoms || "General consultation needed"}
━━━━━━━━━━━━━━━━━━━━
Please dispatch the nearest DHA-licensed medical team immediately.`;

    window.open(getWhatsAppBookingUrl(message), "_blank");
  };

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-orange-100 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-orange-600 via-amber-500 to-orange-500 p-5 text-white flex items-center justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl -mr-16 -mt-16 pointer-events-none" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold text-white tracking-wide">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                24/7 DHA Licensed On-Call
              </span>
              <span className="text-xs bg-orange-700/60 px-2 py-0.5 rounded text-white/90 font-medium">
                ETA: 30-45 Mins
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white">
              {step === 4 ? "Booking Confirmed" : "Book Doctor / Service at Home"}
            </h2>
          </div>

          <button
            onClick={closeBooking}
            className="relative z-10 w-9 h-9 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-step progress indicator */}
        {step !== 4 && (
          <div className="bg-orange-50/70 px-6 py-3 border-b border-orange-100 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step >= 1 ? "bg-orange-600 text-white shadow-sm" : "bg-slate-200 text-slate-600"
                }`}
              >
                1
              </span>
              <span className={step === 1 ? "text-orange-600 font-bold" : "text-slate-500"}>
                Service
              </span>
              <span className="text-slate-300">→</span>

              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step >= 2 ? "bg-orange-600 text-white shadow-sm" : "bg-slate-200 text-slate-600"
                }`}
              >
                2
              </span>
              <span className={step === 2 ? "text-orange-600 font-bold" : "text-slate-500"}>
                Location & Time
              </span>
              <span className="text-slate-300">→</span>

              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step >= 3 ? "bg-orange-600 text-white shadow-sm" : "bg-slate-200 text-slate-600"
                }`}
              >
                3
              </span>
              <span className={step === 3 ? "text-orange-600 font-bold" : "text-slate-500"}>
                Patient Details
              </span>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 text-xs text-orange-800 font-semibold bg-orange-100/70 px-2.5 py-1 rounded-full">
              <Zap className="w-3.5 h-3.5 text-orange-600 fill-orange-500" />
              Immediate Dispatch Ready
            </div>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 text-slate-800">
          {/* STEP 1: Select Service */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">
                  Step 1: Choose Required Healthcare Service
                </h3>
                <p className="text-xs text-slate-500">
                  Select the medical treatment you need at your home, hotel, or office in Dubai.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {SERVICES.map((srv) => {
                  const isSelected = selectedService === srv.slug;
                  return (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() => setSelectedService(srv.slug)}
                      className={`p-3.5 rounded-2xl border text-left transition-all relative flex flex-col justify-between ${
                        isSelected
                          ? "border-orange-500 bg-orange-50/80 shadow-md ring-2 ring-orange-500/20"
                          : "border-slate-200 hover:border-orange-300 hover:bg-orange-50/30"
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="font-bold text-sm text-slate-900">
                            {srv.shortTitle}
                          </span>
                          {srv.category === "urgent-care" && (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-orange-600 text-white rounded-full">
                              Fast 30m
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {srv.tagline}
                        </p>
                      </div>

                      <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100">
                        <span className="text-xs font-semibold text-orange-600">
                          From AED {srv.priceStartingAtAed}
                        </span>
                        <div
                          className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                            isSelected
                              ? "border-orange-600 bg-orange-600 text-white"
                              : "border-slate-300"
                          }`}
                        >
                          {isSelected && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Quick WhatsApp or Call Shortcuts */}
              <div className="bg-amber-50 rounded-2xl p-3.5 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-3 mt-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-orange-500/15 flex items-center justify-center text-orange-600">
                    <Zap className="w-4 h-4 fill-orange-500" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Need Immediate Doctor?</div>
                    <div className="text-[11px] text-slate-600">Skip the form & WhatsApp our triage desk directly.</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleWhatsAppDispatch}
                  className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Instant WhatsApp
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Location & Timing */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">
                  Step 2: Location & Arrival Urgency
                </h3>
                <p className="text-xs text-slate-500">
                  Tell us where to dispatch the doctor and how soon you need medical assistance.
                </p>
              </div>

              {/* Timing Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  When do you need the medical team?
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setUrgency("immediate")}
                    className={`p-3.5 rounded-2xl border text-left transition-all ${
                      urgency === "immediate"
                        ? "border-orange-500 bg-orange-50/80 shadow-sm ring-2 ring-orange-500/20"
                        : "border-slate-200 hover:border-orange-200"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="font-bold text-sm text-slate-900">Immediate</span>
                    </div>
                    <p className="text-xs text-orange-700 font-semibold">
                      Arrival in 30 - 45 Minutes
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUrgency("scheduled")}
                    className={`p-3.5 rounded-2xl border text-left transition-all ${
                      urgency === "scheduled"
                        ? "border-orange-500 bg-orange-50/80 shadow-sm ring-2 ring-orange-500/20"
                        : "border-slate-200 hover:border-orange-200"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Calendar className="w-4 h-4 text-slate-600" />
                      <span className="font-bold text-sm text-slate-900">Schedule Later</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Pick specific date & time
                    </p>
                  </button>
                </div>
              </div>

              {urgency === "scheduled" && (
                <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200 animate-in fade-in">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Preferred Date
                    </label>
                    <input
                      type="date"
                      value={scheduledDate}
                      onChange={(e) => setScheduledDate(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Time Slot
                    </label>
                    <select
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500 bg-white"
                    >
                      <option>08:00 AM - 10:00 AM</option>
                      <option>10:00 AM - 12:00 PM</option>
                      <option>12:00 PM - 02:00 PM</option>
                      <option>02:00 PM - 04:00 PM</option>
                      <option>04:00 PM - 06:00 PM</option>
                      <option>06:00 PM - 08:00 PM</option>
                      <option>08:00 PM - 11:00 PM</option>
                      <option>Late Night (11:00 PM - 08:00 AM)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Dubai Area Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Dubai Area / Community
                </label>
                <select
                  value={selectedArea}
                  onChange={(e) => setSelectedArea(e.target.value)}
                  className="w-full text-sm p-3 rounded-xl border border-slate-300 bg-white focus:outline-none focus:border-orange-500 font-medium text-slate-800"
                >
                  {DUBAI_LOCATIONS.map((loc) => (
                    <option key={loc.id} value={loc.slug}>
                      {loc.name} (Avg. ETA: {loc.averageEtaMinutes} mins)
                    </option>
                  ))}
                </select>
              </div>

              {/* Exact Building / Villa */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Building / Villa / Hotel & Room Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. Burj Views Tower B, Apt 1402 or Atlantis Hotel Room 410"
                  value={addressDetails}
                  onChange={(e) => setAddressDetails(e.target.value)}
                  className="w-full text-sm p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>
          )}

          {/* STEP 3: Patient Information & Symptoms */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">
                  Step 3: Patient Contact & Health Symptoms
                </h3>
                <p className="text-xs text-slate-500">
                  Our doctor will review these symptoms prior to arrival to bring appropriate medications.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Patient Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter patient name"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full text-sm p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Phone / WhatsApp Number *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+971 50 000 0000"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full text-sm p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Brief Medical Symptoms / Condition
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. High fever for 2 days, vomiting, severe headache, need IV drip & doctor examination..."
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  className="w-full text-sm p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500"
                />
              </div>

              {/* Order Summary Box */}
              <div className="bg-orange-50 rounded-2xl p-4 border border-orange-100">
                <div className="text-xs font-bold text-slate-900 mb-2 flex items-center justify-between">
                  <span>Booking Summary</span>
                  <span className="text-orange-600">Starting from AED {currentServiceObj.priceStartingAtAed}</span>
                </div>
                <div className="text-xs space-y-1 text-slate-600">
                  <div className="flex justify-between">
                    <span>Service:</span>
                    <span className="font-semibold text-slate-800">{currentServiceObj.shortTitle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Destination:</span>
                    <span className="font-semibold text-slate-800">{currentAreaObj.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Response Time:</span>
                    <span className="font-semibold text-emerald-700">
                      {urgency === "immediate" ? "30-45 Mins Fast Doorstep Arrival" : `${scheduledDate || "Scheduled"} (${scheduledTime})`}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>100% DHA Licensed Doctors & Registered Nurses. Direct invoice for insurance reimbursement.</span>
              </div>
            </div>
          )}

          {/* STEP 4: Success & Confirmation */}
          {step === 4 && (
            <div className="text-center py-6 space-y-4 animate-in zoom-in-95">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-slate-900">
                  Booking Request Received!
                </h3>
                <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
                  Our 24/7 medical triage coordinator is contacting you at{" "}
                  <strong className="text-slate-900">{phoneNumber || "your number"}</strong> to confirm doctor dispatch to {currentAreaObj.name}.
                </p>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 text-left max-w-md mx-auto text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-orange-950">
                  <Clock className="w-4 h-4 text-orange-600" />
                  Estimated Doctor Doorstep Arrival: 30 - 45 Minutes
                </div>
                <p className="text-slate-600">
                  Please keep your phone line accessible. Our doctor carries full diagnostic kits, medication, and payment terminals (Card & Cash accepted).
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <button
                  type="button"
                  onClick={handleWhatsAppDispatch}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <MessageSquare className="w-4 h-4" />
                  Open in WhatsApp for Live Tracking
                </button>
                <a
                  href={getDirectCallUrl()}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition-all"
                >
                  <Phone className="w-4 h-4 text-orange-400" />
                  Call 24/7 Dispatch Desk
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        {step !== 4 && (
          <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex items-center justify-between gap-3">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep((prev) => (prev - 1) as 1 | 2 | 3 | 4)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back
              </button>
            ) : (
              <div className="text-xs text-slate-400 font-medium">Step 1 of 3</div>
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleWhatsAppDispatch}
                className="hidden sm:inline-flex px-3.5 py-2.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 text-xs font-bold items-center gap-1.5 transition-colors"
                title="Instant dispatch on WhatsApp"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                WhatsApp Direct
              </button>

              <button
                type="button"
                onClick={handleNext}
                disabled={isSubmitting || (step === 3 && (!patientName || !phoneNumber))}
                className="px-6 py-2.5 rounded-xl brand-gradient-bg hover:opacity-95 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-orange-500/20 disabled:opacity-50 transition-all cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Processing...</span>
                ) : step === 3 ? (
                  <>
                    <span>Confirm & Dispatch Doctor</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </>
                ) : (
                  <>
                    <span>Continue to Step {step + 1}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
