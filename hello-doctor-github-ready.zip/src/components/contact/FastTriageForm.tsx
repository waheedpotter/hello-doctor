"use client";

import React, { useState } from "react";
import { getWhatsAppBookingUrl, getDirectCallUrl } from "@/lib/utils";
import {
  Stethoscope,
  MapPin,
  User,
  Phone,
  Clock,
  FileText,
  Send,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Sparkles
} from "lucide-react";

const SERVICES_OPTIONS = [
  "Doctor on Call Dubai (24/7 Rapid GP Dispatch)",
  "Doctor at Home Dubai (Comprehensive Consultation)",
  "Doctor at Hotel Dubai (In-Room Visit & Fit-to-Fly)",
  "IV Drip Therapy at Home Dubai",
  "Lab Test / Blood Work at Home Dubai",
  "Physiotherapy at Home Dubai",
  "Home Nursing Dubai (12h/24h or Per-Visit)",
  "Baby Care at Home Dubai (Newborn & Pediatric Support)",
  "Elderly Care at Home Dubai (Senior Bedside Nursing)",
  "Earwax Removal at Home Dubai (Painless Microsuction)",
  "Peptide Home Treatments Dubai",
];

const POPULAR_AREAS = [
  "Downtown Dubai",
  "Dubai Marina",
  "Palm Jumeirah",
  "Business Bay",
  "Al Barsha",
  "JVC",
  "Dubai Hills Estate",
  "Arabian Ranches",
  "JBR",
  "DIFC",
];

export function FastTriageForm() {
  const [formData, setFormData] = useState({
    service: SERVICES_OPTIONS[0],
    location: "",
    patientName: "",
    phone: "",
    urgency: "Immediate (<45 mins)",
    symptoms: "",
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);

      // Build WhatsApp message
      const text = `*New 24/7 Medical Dispatch Request*\n\n• *Service:* ${formData.service}\n• *Location:* ${formData.location || "Dubai"}\n• *Patient Name:* ${formData.patientName}\n• *Phone:* ${formData.phone}\n• *Urgency Level:* ${formData.urgency}\n• *Symptoms/Notes:* ${formData.symptoms || "None provided"}\n\nPlease dispatch medical team immediately.`;
      
      // Open WhatsApp in new tab for immediate triage coordination
      const waUrl = getWhatsAppBookingUrl(text);
      window.open(waUrl, "_blank");
    }, 600);
  };

  return (
    <div className="bg-white rounded-3xl border border-orange-200/80 p-6 sm:p-8 shadow-xl shadow-orange-500/5 relative overflow-hidden">
      {/* Top Banner */}
      <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-100">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-orange-600 bg-orange-100/80 px-2.5 py-1 rounded-full">
            60-Second Fast Triage
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-2">
            Request Rapid Medical Dispatch
          </h2>
        </div>
        <div className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span>Doctors on Duty</span>
        </div>
      </div>

      {submitted ? (
        <div className="py-8 text-center space-y-4 animate-in fade-in zoom-in-95 duration-300">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-2xl font-extrabold text-slate-900">
            Dispatch Request Received!
          </h3>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Our 24/7 medical triage coordinator has been notified. WhatsApp chat has been initiated to confirm your exact pin location and doctor ETA.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href={getWhatsAppBookingUrl(
                `Hello! I just submitted a dispatch request for ${formData.service} in ${formData.location || "Dubai"}. Please confirm arrival.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Open WhatsApp Medical Desk</span>
            </a>
            <a
              href={getDirectCallUrl()}
              className="w-full sm:w-auto px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <Phone className="w-4 h-4 text-orange-400" />
              <span>Call Hotline Directly</span>
            </a>
          </div>

          <button
            type="button"
            onClick={() => {
              setSubmitted(false);
              setFormData({
                service: SERVICES_OPTIONS[0],
                location: "",
                patientName: "",
                phone: "",
                urgency: "Immediate (<45 mins)",
                symptoms: "",
              });
            }}
            className="text-xs text-orange-600 font-semibold hover:underline pt-2 inline-block cursor-pointer"
          >
            Submit another inquiry →
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Field 1: Service Needed */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Select Required Medical Service <span className="text-orange-600">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.service}
                onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                required
                className="w-full pl-3.5 pr-8 py-3 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 bg-slate-50/50 text-slate-900 font-medium transition-all"
              >
                {SERVICES_OPTIONS.map((srv, idx) => (
                  <option key={idx} value={srv}>
                    {srv}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Field 2: Location / Community in Dubai */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Your Dubai Location / Hotel / Area <span className="text-orange-600">*</span>
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="e.g. Downtown Dubai, Address Sky View, Villa 12"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                required
                className="w-full pl-10 pr-4 py-3 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 bg-slate-50/50 text-slate-900 transition-all"
              />
            </div>
            {/* Quick Location Pills */}
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className="text-[10px] text-slate-400 font-medium mr-1">Quick Select:</span>
              {POPULAR_AREAS.slice(0, 5).map((area, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setFormData({ ...formData, location: area })}
                  className="text-[10px] bg-slate-100 hover:bg-orange-50 hover:text-orange-600 text-slate-600 px-2 py-0.5 rounded-md transition-colors cursor-pointer"
                >
                  {area}
                </button>
              ))}
            </div>
          </div>

          {/* Field 3: Patient Name & Phone Number */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1.5">
                Patient / Contact Name <span className="text-orange-600">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Full Name"
                  value={formData.patientName}
                  onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                  required
                  className="w-full pl-10 pr-4 py-3 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 bg-slate-50/50 text-slate-900 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1.5">
                Phone Number (WhatsApp Active) <span className="text-orange-600">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  placeholder="+971 50 123 4567"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                  className="w-full pl-10 pr-4 py-3 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 bg-slate-50/50 text-slate-900 transition-all"
                />
              </div>
            </div>
          </div>

          {/* Field 4: Urgency Level */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Urgency Level
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {[
                { label: "Immediate (<45 mins)", color: "text-red-700 bg-red-50 border-red-200", dot: "bg-red-500" },
                { label: "Today (Scheduled Time)", color: "text-amber-800 bg-amber-50 border-amber-200", dot: "bg-amber-500" },
                { label: "Routine Booking", color: "text-emerald-800 bg-emerald-50 border-emerald-200", dot: "bg-emerald-500" },
              ].map((item, idx) => (
                <label
                  key={idx}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer transition-all ${
                    formData.urgency === item.label
                      ? `${item.color} font-bold ring-2 ring-orange-500/20`
                      : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  <input
                    type="radio"
                    name="urgency"
                    value={item.label}
                    checked={formData.urgency === item.label}
                    onChange={(e) => setFormData({ ...formData, urgency: e.target.value })}
                    className="sr-only"
                  />
                  <span className={`w-2 h-2 rounded-full ${item.dot}`} />
                  <span className="text-xs">{item.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Field 5: Symptoms / Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Chief Symptoms / Notes (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. High fever since morning, food poisoning, earwax buildup, IV hydration required..."
              value={formData.symptoms}
              onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 bg-slate-50/50 text-slate-900 transition-all resize-none"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 brand-gradient-bg hover:opacity-95 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-98 cursor-pointer"
          >
            {loading ? (
              <span>Connecting to Dispatch Desk...</span>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Request Medical Dispatch Now</span>
              </>
            )}
          </button>

          <p className="text-[11px] text-center text-slate-500">
            🔒 DHA Patient Confidentiality Protected • Itemized receipts provided for insurance reimbursement.
          </p>
        </form>
      )}
    </div>
  );
}
