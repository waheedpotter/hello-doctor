"use client";

import React from "react";
import { getDirectCallUrl, getWhatsAppBookingUrl, SITE_CONFIG } from "@/lib/utils";
import { Phone, MessageSquare, Clock } from "lucide-react";

export function StickyMobileContactBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 shadow-2xl">
      <div className="flex items-center gap-2">
        {/* Call Button */}
        <a
          href={getDirectCallUrl()}
          className="flex-1 py-3 px-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md active:scale-98 transition-all"
        >
          <Phone className="w-4 h-4 text-orange-400" />
          <span>Call Dispatch</span>
        </a>

        {/* WhatsApp Button */}
        <a
          href={getWhatsAppBookingUrl(
            "Hello Doctor! I need urgent medical dispatch at my residence/hotel in Dubai. Please assist immediately."
          )}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-3 px-3 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-orange-500/25 active:scale-98 transition-all"
        >
          <MessageSquare className="w-4 h-4 fill-emerald-400 text-emerald-400" />
          <span>WhatsApp Triage</span>
        </a>
      </div>
    </div>
  );
}
