"use client";

import React from "react";
import { useBooking } from "../booking/BookingContext";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { Stethoscope, MessageSquare, Phone, Clock, ShieldCheck } from "lucide-react";

export function CTASection() {
  const { openBooking } = useBooking();

  return (
    <section className="py-16 md:py-20 bg-slate-950 text-white relative overflow-hidden">
      {/* Warm orange radial gradient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-orange-600/20 via-amber-500/20 to-orange-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto relative z-10 max-w-4xl text-center space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 text-orange-300 text-xs font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>Available 24 Hours / 7 Days Across Dubai</span>
        </div>

        <h2 className="text-2xl sm:text-3xl md:text-5xl font-black tracking-tight leading-tight">
          Feeling Sick? Have a Doctor at Your Doorstep in{" "}
          <span className="brand-gradient-text">30 to 45 Minutes</span>
        </h2>

        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
          No hospital queues. No driving through Dubai traffic. Get immediate examination, prescriptions, acute medications, and IV drips in the privacy of your home or hotel.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
          <button
            type="button"
            onClick={() => openBooking()}
            className="w-full sm:w-auto px-8 py-4 brand-gradient-bg hover:opacity-95 text-white font-bold text-sm sm:text-base rounded-2xl shadow-xl shadow-orange-500/30 flex items-center justify-center gap-2 transition-all transform hover:-translate-y-0.5 cursor-pointer"
          >
            <Stethoscope className="w-5 h-5" />
            <span>Book Doctor at Home Now</span>
          </button>

          <a
            href={getWhatsAppBookingUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-7 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm sm:text-base rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            <MessageSquare className="w-5 h-5" />
            <span>WhatsApp Triage</span>
          </a>

          <a
            href={getDirectCallUrl()}
            className="w-full sm:w-auto px-6 py-4 bg-white/10 hover:bg-white/20 text-white font-bold text-sm sm:text-base rounded-2xl border border-white/20 flex items-center justify-center gap-2 transition-all"
          >
            <Phone className="w-5 h-5 text-orange-400" />
            <span>{SITE_CONFIG.phoneDisplay}</span>
          </a>
        </div>

        <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            DHA Licensed Facility
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-orange-400" />
            Average Response Time: 30-45 Mins
          </span>
          <span>Pay with Card / Apple Pay / Cash</span>
        </div>
      </div>
    </section>
  );
}
