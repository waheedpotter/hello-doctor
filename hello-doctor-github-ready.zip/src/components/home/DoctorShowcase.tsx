"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { DOCTORS } from "@/data/doctors";
import { useBooking } from "../booking/BookingContext";
import { ShieldCheck, Clock, MapPin, ArrowRight, Stethoscope, Award, HeartPulse } from "lucide-react";

export function DoctorShowcase() {
  const { openBooking } = useBooking();

  return (
    <section className="py-16 md:py-24 bg-white relative">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
              DHA Licensed Medical Leadership & Clinical Team
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-950 mt-3 tracking-tight">
              Meet Our Licensed <span className="brand-gradient-text">Doctors & Clinical Team</span>
            </h2>
            <p className="mt-2 text-sm sm:text-base text-slate-600 max-w-xl">
              Led by Medical Director Dr. Sukhwinder Kaur, our team of DHA-licensed general practitioners and registered nurses delivers 24/7 hospital-standard care directly to your door.
            </p>
          </div>

          <div className="mt-4 md:mt-0">
            <Link
              href="/doctors/"
              className="inline-flex items-center gap-1.5 text-sm font-bold text-orange-600 hover:text-orange-700 transition-colors"
            >
              <span>View All Medical Staff</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {DOCTORS.map((doc) => (
            <div
              key={doc.id}
              className="bg-white rounded-3xl border border-slate-200 hover:border-orange-300 shadow-sm brand-card-glow-hover flex flex-col justify-between overflow-hidden transition-all duration-300 group"
            >
              <div>
                {/* Doctor Image with DHA Badge */}
                <div className="relative h-64 w-full overflow-hidden bg-slate-100">
                  <Image
                    src={doc.image}
                    alt={`${doc.name} - ${doc.designation}`}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-slate-900 flex items-center gap-1 shadow-sm">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{doc.dhaLicenseNumber}</span>
                  </div>
                  {doc.isAvailableToday && (
                    <div className="absolute top-3 right-3 bg-emerald-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 shadow-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      <span>On-Duty</span>
                    </div>
                  )}
                </div>

                {/* Doctor Info */}
                <div className="p-5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                      doc.roleTitle === "Medical Director"
                        ? "bg-amber-100 text-amber-900 border border-amber-300"
                        : doc.roleTitle === "DHA Registered Nurse"
                        ? "bg-emerald-100 text-emerald-900 border border-emerald-300"
                        : "bg-orange-100 text-orange-900 border border-orange-200"
                    }`}>
                      {doc.roleTitle || doc.specialty}
                    </span>
                    <span className="text-[11px] font-semibold text-orange-600">
                      {doc.experienceYears}+ Years Exp.
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                    {doc.name}
                  </h3>

                  <p className="text-xs font-semibold text-slate-600">
                    {doc.specialty}
                  </p>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {doc.bio}
                  </p>

                  <div className="pt-2 text-[11px] text-slate-600 space-y-1">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-orange-500" />
                      <span>24/7 Home & Hotel Visits</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-orange-500" />
                      <span className="truncate">Covers {doc.availableAreas.slice(0, 2).join(", ")} +</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card CTA */}
              <div className="p-5 pt-0">
                <Link
                  href={`/doctors/${doc.slug}/`}
                  className="w-full py-2.5 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Stethoscope className="w-3.5 h-3.5" />
                  <span>View Profile & Book</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
