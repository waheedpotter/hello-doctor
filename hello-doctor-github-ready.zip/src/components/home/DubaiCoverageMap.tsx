"use client";

import React, { useState } from "react";
import Link from "next/link";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { useBooking } from "../booking/BookingContext";
import { MapPin, Clock, ArrowRight, ShieldCheck, Zap } from "lucide-react";

export function DubaiCoverageMap() {
  const { openBooking } = useBooking();
  const [selectedLoc, setSelectedLoc] = useState(DUBAI_LOCATIONS[0]);

  return (
    <section className="py-16 md:py-24 bg-orange-50/40 border-y border-orange-100/80 relative">
      <div className="container mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
            All Dubai Communities Covered
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-950 mt-3 tracking-tight">
            Fast Doorstep Medical Coverage <span className="brand-gradient-text">Across Dubai</span>
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600">
            Our medical response vehicles are stationed throughout Dubai to ensure an average doctor arrival time of 30 to 45 minutes to your doorstep.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Location Buttons Selector */}
          <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-3">
            {DUBAI_LOCATIONS.map((loc) => {
              const isSelected = selectedLoc.id === loc.id;
              return (
                <button
                  key={loc.id}
                  type="button"
                  onClick={() => setSelectedLoc(loc)}
                  className={`p-3.5 rounded-2xl border text-left transition-all relative flex flex-col justify-between ${
                    isSelected
                      ? "border-orange-500 bg-white shadow-md ring-2 ring-orange-500/20"
                      : "border-slate-200/90 bg-white/80 hover:bg-white hover:border-orange-200"
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-1">
                      <MapPin className={`w-3.5 h-3.5 ${isSelected ? "text-orange-600" : "text-slate-400"}`} />
                      <span className="truncate">{loc.name}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-medium">
                      {loc.zone}
                    </span>
                  </div>

                  <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3 text-emerald-600" />
                      {loc.averageEtaMinutes}m ETA
                    </span>
                    {isSelected && (
                      <span className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right: Selected Area Focus Card */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-7 shadow-xl border border-orange-100 brand-card-glow">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-1 rounded-full">
                {selectedLoc.zone}
              </span>
              <div className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>ETA: {selectedLoc.averageEtaMinutes} Minutes</span>
              </div>
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
              Doctor at Home in {selectedLoc.name}
            </h3>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
              {selectedLoc.description}
            </p>

            {/* Sub-communities */}
            <div className="mb-5 space-y-2">
              <div className="text-xs font-bold text-slate-800">
                Key Coverage Areas & Communities:
              </div>
              <div className="flex flex-wrap gap-1.5">
                {selectedLoc.popularCommunities.map((comm, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg font-medium"
                  >
                    {comm}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2.5 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => openBooking({ areaSlug: selectedLoc.slug })}
                className="w-full py-3.5 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Zap className="w-4 h-4" />
                <span>Book Doctor to {selectedLoc.name}</span>
              </button>

              <Link
                href={`/areas-we-serve/${selectedLoc.slug}/`}
                className="block text-center text-xs font-bold text-orange-600 hover:underline py-1"
              >
                View Full {selectedLoc.name} Area Guide & Info →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
