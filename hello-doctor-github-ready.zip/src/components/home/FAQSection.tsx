"use client";

import React, { useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

const GLOBAL_FAQS: FAQItem[] = [
  {
    question: "How fast can a doctor arrive at my home or hotel in Dubai?",
    answer: "Our response fleet is distributed across Downtown Dubai, Dubai Marina, JVC, Palm Jumeirah, and Al Barsha. On average, our DHA-licensed doctor arrives at your doorstep within 30 to 45 minutes of booking confirmation.",
  },
  {
    question: "Are your doctors and nurses licensed by the Dubai Health Authority (DHA)?",
    answer: "Yes, 100% of our physicians, registered nurses, and phlebotomists hold active, verified licenses from the Dubai Health Authority (DHA) with years of clinical and emergency hospital experience.",
  },
  {
    question: "Can the visiting doctor provide a DHA medical sick leave certificate?",
    answer: "Yes, our licensed doctors issue official DHA-approved electronic sick leave certificates and e-prescriptions that are instantly delivered to your registered phone and email.",
  },
  {
    question: "Can I claim insurance reimbursement for doctor at home visits in Dubai?",
    answer: "Yes. While we operate on a direct-pay model upon arrival (accepting Cards, Apple Pay, and Cash), we provide a full DHA medical report, itemized invoice, and insurance claim form required for reimbursement by all major UAE and international insurance providers.",
  },
  {
    question: "What medical conditions can be treated at home?",
    answer: "Our doctors treat high fever, seasonal flu, food poisoning, dehydration, acute migraine, asthma flare-ups, ear/throat infections, hypertension, minor wounds, back pain, and provide IV vitamin drip therapies and laboratory blood sample collection.",
  },
  {
    question: "Do you provide hotel doctor visits for tourists in Dubai?",
    answer: "Yes! We provide 24/7 hotel room doctor visits to all hotels, resorts, and vacation rentals in Dubai. We coordinate seamlessly with hotel concierges and provide fit-to-fly certificates if needed.",
  },
];

export function FAQSection({ faqs = GLOBAL_FAQS, title = "Frequently Asked Questions" }: { faqs?: FAQItem[]; title?: string }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-16 md:py-24 bg-slate-50 relative">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
            Got Questions?
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-950 mt-3 tracking-tight">
            {title}
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600">
            Everything you need to know about our 24/7 doctor on call and home healthcare services in Dubai.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-sm transition-all"
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-slate-900 hover:text-orange-600 transition-colors"
                >
                  <span className="flex items-center gap-2.5">
                    <HelpCircle className="w-4 h-4 text-orange-500 shrink-0" />
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? "rotate-180 text-orange-600" : ""
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3 animate-in fade-in">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
