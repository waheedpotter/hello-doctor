"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useBooking } from "../booking/BookingContext";
import { SERVICES } from "@/data/services";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import {
  Clock,
  ShieldCheck,
  Star,
  CheckCircle2,
  Phone,
  MessageSquare,
  Stethoscope,
  Sparkles,
  ArrowRight,
  Zap,
  Award,
  Users
} from "lucide-react";

export function HeroSection() {
  const { openBooking, setSelectedService, setSelectedArea } = useBooking();
  const [quickService, setQuickService] = useState("doctor-at-home-dubai");
  const [quickArea, setQuickArea] = useState("downtown-dubai");

  const handleQuickBook = (e: React.FormEvent) => {
    e.preventDefault();
    setSelectedService(quickService);
    setSelectedArea(quickArea);
    openBooking({ serviceSlug: quickService, areaSlug: quickArea });
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-orange-100/60">
      {/* Background Image with High-Elegance Gradient Overlay */}
      <div className="absolute inset-0 -z-10 select-none overflow-hidden">
        <Image
          src="/images/hero-doctors-dubai.jpg"
          alt="Hello Doctor Dubai 24/7 DHA Licensed On-Call Medical Team"
          fill
          priority
          quality={90}
          className="object-cover object-[70%_20%] lg:object-right-top filter brightness-[1.02]"
          sizes="100vw"
        />
        {/* Multi-layered directional overlays ensuring 100% typography contrast while showcasing the Dubai skyline and doctor team */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/98 via-white/90 to-white/40 lg:from-white/95 lg:via-white/70 lg:to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-white/70 via-transparent to-white/90 lg:to-white/60" />
        <div className="absolute top-10 left-1/4 w-[600px] h-[400px] bg-orange-400/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Value Proposition & Urgency */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Live On-Call Urgent Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-100/90 border border-orange-300/80 text-orange-950 text-xs font-bold shadow-sm backdrop-blur-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span>DHA LICENSED DOCTORS ON-DUTY 24/7 IN DUBAI</span>
              <span className="hidden sm:inline text-orange-700 font-semibold">• 30-45 Mins Arrival</span>
            </div>

            {/* Main H1 Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-950 leading-[1.15]">
              Doctor at Your Doorstep in{" "}
              <span className="brand-gradient-text">Dubai Within 30-45 Mins</span>
            </h1>

            {/* Sub-headline */}
            <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Skip hospital traffic and crowded emergency waiting rooms. Our DHA-licensed physicians and registered nurses provide comprehensive medical checkups, emergency medications, IV drips, and diagnostic tests directly at your <strong>home, hotel, or villa 24/7</strong>.
            </p>

            {/* Trust Bullet Highlights */}
            <div className="grid grid-cols-2 sm:grid-cols-2 gap-3 pt-1 text-left max-w-lg mx-auto lg:mx-0">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>100% DHA Licensed Doctors</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>On-Site Medications & Tests</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>DHA Sick Leave & E-Prescriptions</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Insurance Reimbursement Support</span>
              </div>
            </div>

            {/* Primary Action Buttons - Perfectly Aligned in One Line */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center lg:justify-start gap-2.5 sm:gap-3 pt-2">
              <button
                type="button"
                onClick={() => openBooking()}
                className="w-full sm:w-auto h-12 sm:h-13 px-5 sm:px-6 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
              >
                <Stethoscope className="w-4 h-4 shrink-0" />
                <span className="whitespace-nowrap">Book Doctor at Home Now</span>
                <ArrowRight className="w-3.5 h-3.5 shrink-0" />
              </button>

              <a
                href={getWhatsAppBookingUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto h-12 sm:h-13 px-4 sm:px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl flex items-center justify-center gap-2 shadow-md transition-all whitespace-nowrap shrink-0"
              >
                <MessageSquare className="w-4 h-4 shrink-0" />
                <span className="whitespace-nowrap">WhatsApp 24/7 Triage</span>
              </a>

              <a
                href={getDirectCallUrl()}
                className="w-full sm:w-auto h-12 sm:h-13 px-4 sm:px-5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-2xl flex items-center justify-center gap-2 transition-all whitespace-nowrap shrink-0"
              >
                <Phone className="w-4 h-4 text-orange-400 shrink-0" />
                <span className="whitespace-nowrap">{SITE_CONFIG.phoneDisplay}</span>
              </a>
            </div>

            {/* Micro Social Proof Bar */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 pt-3 text-xs text-slate-500 border-t border-slate-200/80">
              <div className="flex items-center gap-1.5">
                <div className="flex text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <span className="font-bold text-slate-800">5.0 / 5.0</span>
                <span>(Google Business Profile)</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium text-slate-700">
                <Users className="w-4 h-4 text-orange-600" />
                <span>15,000+ Patients Treated in Dubai</span>
              </div>
            </div>

          </div>

          {/* Right Column: High-Converting Embedded Booking Widget Card */}
          <div className="lg:col-span-5">
            <div className="relative bg-white rounded-3xl p-6 sm:p-7 shadow-2xl border border-orange-100/80 brand-card-glow">
              {/* Top Card Badge */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-orange-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl brand-gradient-bg flex items-center justify-center text-white font-bold shadow-sm">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-extrabold uppercase tracking-wider text-orange-600">
                      Instant Dispatch
                    </div>
                    <div className="text-sm font-bold text-slate-900">
                      Express Home Care Booking
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-1 rounded-full">
                    30m Avg. ETA
                  </span>
                </div>
              </div>

              <form onSubmit={handleQuickBook} className="space-y-4">
                {/* Service Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    1. Select Healthcare Service
                  </label>
                  <select
                    value={quickService}
                    onChange={(e) => setQuickService(e.target.value)}
                    className="w-full text-sm font-semibold p-3.5 rounded-2xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 text-slate-900 transition-all"
                  >
                    {SERVICES.map((s) => (
                      <option key={s.id} value={s.slug}>
                        {s.shortTitle} — from AED {s.priceStartingAtAed}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Dubai Area Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    2. Select Your Dubai Location
                  </label>
                  <select
                    value={quickArea}
                    onChange={(e) => setQuickArea(e.target.value)}
                    className="w-full text-sm font-semibold p-3.5 rounded-2xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 text-slate-900 transition-all"
                  >
                    {DUBAI_LOCATIONS.map((l) => (
                      <option key={l.id} value={l.slug}>
                        {l.name} ({l.averageEtaMinutes} Mins ETA)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Urgency Highlight */}
                <div className="bg-orange-50/80 rounded-2xl p-3.5 border border-orange-200/80 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-orange-600" />
                    <span className="font-semibold text-slate-800">Doctor Arrival Guarantee:</span>
                  </div>
                  <span className="font-bold text-orange-700">Within 30-45 Mins</span>
                </div>

                {/* Submit Booking Button */}
                <button
                  type="submit"
                  className="w-full py-4 brand-gradient-bg hover:opacity-95 text-white font-bold text-sm rounded-2xl shadow-lg shadow-orange-500/30 flex items-center justify-center gap-2 transition-all transform active:scale-98 cursor-pointer"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>Continue Booking with Doctor</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {/* Direct WhatsApp Option */}
                <div className="text-center pt-1">
                  <span className="text-xs text-slate-500">
                    Prefer direct chat?{" "}
                    <a
                      href={getWhatsAppBookingUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-700 font-bold hover:underline"
                    >
                      Book instantly via WhatsApp →
                    </a>
                  </span>
                </div>
              </form>

              {/* Bottom Guarantee */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  DHA Licensed Facility
                </span>
                <span>Pay by Card / Cash / Apple Pay</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
