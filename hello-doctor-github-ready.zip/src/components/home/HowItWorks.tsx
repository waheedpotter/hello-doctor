"use client";

import React from "react";
import { PhoneCall, Car, Stethoscope, HeartHandshake, ArrowRight } from "lucide-react";
import { useBooking } from "../booking/BookingContext";

export function HowItWorks() {
  const { openBooking } = useBooking();

  const steps = [
    {
      step: "01",
      icon: <PhoneCall className="w-6 h-6 text-white" />,
      title: "Call, WhatsApp or Book Online",
      description: "Contact our 24/7 medical triage desk with your location and symptoms. A dedicated coordinator confirms your service immediately.",
    },
    {
      step: "02",
      icon: <Car className="w-6 h-6 text-white" />,
      title: "Doctor Dispatched in 30-45 Mins",
      description: "A DHA-licensed general practitioner or nurse arrives at your home, hotel, or office with full clinical diagnostic and medical equipment.",
    },
    {
      step: "03",
      icon: <Stethoscope className="w-6 h-6 text-white" />,
      title: "Comprehensive Care & Prescription",
      description: "Get evaluated, receive on-the-spot medications, IV therapy, lab samples taken, and instant electronic DHA sick leave & prescriptions.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-slate-50 relative overflow-hidden">
      <div className="container mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
            Simple 3-Step Process
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-950 mt-3 tracking-tight">
            How Doctor at Home <span className="brand-gradient-text">Works in Dubai</span>
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600">
            Getting professional healthcare delivered to your door has never been faster or easier.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-7 border border-slate-200/80 shadow-sm hover:shadow-xl transition-all relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-14 h-14 rounded-2xl brand-gradient-bg flex items-center justify-center shadow-lg shadow-orange-500/25">
                    {item.icon}
                  </div>
                  <span className="text-3xl font-black text-orange-100">
                    {item.step}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-6 mt-4 border-t border-slate-100 flex items-center justify-between text-xs text-orange-600 font-bold">
                <span>Step {item.step} of 03</span>
                <span>24/7 Available</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button
            type="button"
            onClick={() => openBooking()}
            className="inline-flex items-center gap-2 px-8 py-4 brand-gradient-bg hover:opacity-95 text-white font-bold text-sm rounded-2xl shadow-xl shadow-orange-500/25 transition-all transform hover:-translate-y-0.5 cursor-pointer"
          >
            <span>Request Doctor at Home Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
