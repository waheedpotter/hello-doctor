"use client";

import React from "react";
import Link from "next/link";
import { useBooking } from "../booking/BookingContext";
import { SERVICES } from "@/data/services";
import {
  Stethoscope,
  Droplet,
  HeartPulse,
  FlaskConical,
  Activity,
  ShieldCheck,
  Hotel,
  Clock,
  ArrowRight,
  Sparkles,
  Check
} from "lucide-react";

export function ServiceGrid() {
  const { openBooking } = useBooking();

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case "Stethoscope":
        return <Stethoscope className="w-6 h-6" />;
      case "Droplet":
        return <Droplet className="w-6 h-6" />;
      case "HeartPulse":
        return <HeartPulse className="w-6 h-6" />;
      case "FlaskConical":
        return <FlaskConical className="w-6 h-6" />;
      case "Activity":
        return <Activity className="w-6 h-6" />;
      case "ShieldCheck":
        return <ShieldCheck className="w-6 h-6" />;
      case "Hotel":
        return <Hotel className="w-6 h-6" />;
      case "Sparkles":
        return <Sparkles className="w-6 h-6" />;
      default:
        return <Stethoscope className="w-6 h-6" />;
    }
  };

  return (
    <section className="py-16 md:py-24 bg-white relative">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-900 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-orange-600" />
            24/7 DHA Licensed Home Healthcare in Dubai
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-950 tracking-tight">
            Our Specialized <span className="brand-gradient-text">Medical Services at Home</span>
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600">
            From urgent on-call doctor visits to rejuvenating IV vitamin infusions and hospital-grade home nursing, our DHA-licensed medical staff arrives with full equipment at your doorstep within 30-45 minutes.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-3xl border border-slate-200/90 hover:border-orange-300 shadow-sm brand-card-glow-hover flex flex-col justify-between overflow-hidden transition-all duration-300 group"
            >
              {/* Card Header & Content */}
              <div className="p-6 sm:p-7 space-y-4">
                {/* Icon & Category Badge */}
                <div className="flex items-center justify-between">
                  <div className="w-13 h-13 rounded-2xl brand-gradient-bg text-white flex items-center justify-center shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
                    {getServiceIcon(service.iconName)}
                  </div>
                  <span className="text-xs font-bold text-orange-600 bg-orange-50 px-3 py-1 rounded-full border border-orange-200/60">
                    From AED {service.priceStartingAtAed}
                  </span>
                </div>

                {/* Title & Tagline */}
                <div>
                  <h3 className="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                    {service.shortTitle}
                  </h3>
                  <p className="text-xs font-medium text-orange-700/90 mt-1">
                    {service.tagline}
                  </p>
                  <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                    {service.overview}
                  </p>
                </div>

                {/* Key Benefits */}
                <div className="space-y-1.5 pt-2 border-t border-slate-100">
                  {service.whyChooseUs.slice(0, 3).map((point, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">{point}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card Footer: Action Buttons */}
              <div className="bg-orange-50/50 p-4 sm:p-5 border-t border-orange-100/70 flex items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                  <Clock className="w-3.5 h-3.5 text-orange-600" />
                  <span>30-45m ETA</span>
                </div>

                <div className="flex items-center gap-2">
                  <Link
                    href={`/services/${service.slug}/`}
                    className="text-xs font-bold text-slate-600 hover:text-orange-600 transition-colors px-2 py-1"
                  >
                    Details
                  </Link>

                  <button
                    type="button"
                    onClick={() => openBooking({ serviceSlug: service.slug })}
                    className="px-4 py-2 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>Book Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Services CTA Button */}
        <div className="mt-12 text-center">
          <Link
            href="/services/"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-orange-50 hover:bg-orange-100 text-orange-700 font-bold text-sm border border-orange-200 shadow-sm transition-all hover:scale-102"
          >
            <span>Explore Full Medical Services Directory & Pricing</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
