"use client";

import React from "react";
import { ShieldCheck, Award, HeartPulse, Clock, FileCheck2, CreditCard } from "lucide-react";
import { SITE_CONFIG } from "@/lib/utils";

export function TrustSignals() {
  const trustCards = [
    {
      icon: <ShieldCheck className="w-6 h-6 text-orange-600" />,
      title: "100% DHA Licensed",
      description: `Registered Healthcare Facility under DHA License #${SITE_CONFIG.dhaLicense}. All physicians are board-certified.`,
    },
    {
      icon: <Clock className="w-6 h-6 text-orange-600" />,
      title: "30-45 Mins Arrival",
      description: "Strategically stationed medical units across Downtown, Marina, Palm, and JVC for rapid dispatch.",
    },
    {
      icon: <HeartPulse className="w-6 h-6 text-orange-600" />,
      title: "Hospital-Grade Equipment",
      description: "Portable 12-lead ECG, pulse oximeters, blood analyzers, nebulizers, and sterile surgical kits.",
    },
    {
      icon: <FileCheck2 className="w-6 h-6 text-orange-600" />,
      title: "Insurance Reimbursement",
      description: "We provide comprehensive DHA medical reports and itemized invoices for UAE & international insurance claims.",
    },
  ];

  return (
    <section className="py-14 bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 text-white relative overflow-hidden">
      {/* Decorative background glow circles */}
      <div className="absolute top-0 right-1/4 w-80 h-80 bg-white/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-64 h-64 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />

      <div className="container mx-auto relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold uppercase tracking-wider mb-2">
            <Award className="w-3.5 h-3.5" />
            Dubai&apos;s Trusted Healthcare Standard
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Why Over 15,000+ Patients in Dubai Rely on Hello Doctor
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trustCards.map((card, idx) => (
            <div
              key={idx}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="w-12 h-12 rounded-xl bg-white text-orange-600 flex items-center justify-center mb-4 shadow-md">
                {card.icon}
              </div>
              <div>
                <h3 className="text-base font-bold text-white mb-1.5">
                  {card.title}
                </h3>
                <p className="text-xs text-orange-50/90 leading-relaxed">
                  {card.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
