"use client";

import React, { useState } from "react";
import { useBooking } from "../booking/BookingContext";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { Phone, MessageSquare, Stethoscope, Clock, X, Zap } from "lucide-react";

export function FloatingEmergencyTicker() {
  const { openBooking } = useBooking();
  const [minimized, setMinimized] = useState(false);

  if (minimized) {
    return (
      <button
        onClick={() => setMinimized(false)}
        className="hidden md:flex fixed bottom-6 right-6 z-40 brand-gradient-bg text-white p-3.5 rounded-full shadow-2xl items-center gap-2 font-bold text-xs animate-bounce hover:animate-none cursor-pointer border-2 border-white"
        aria-label="Open emergency booking widget"
      >
        <Zap className="w-4 h-4 fill-white" />
        <span>Doctor On-Call (30m)</span>
      </button>
    );
  }

  return (
    <div className="hidden md:flex fixed bottom-6 right-6 z-40 bg-white/95 backdrop-blur-md border border-orange-200/90 rounded-2xl shadow-2xl px-4 py-3 items-center gap-3 animate-in slide-in-from-bottom-5 duration-300 brand-card-glow w-auto max-w-xl">
      {/* Icon */}
      <div className="w-9 h-9 rounded-xl brand-gradient-bg flex items-center justify-center text-white shrink-0 shadow-md">
        <Stethoscope className="w-4 h-4" />
      </div>

      {/* Two-Line Text Content */}
      <div className="flex flex-col justify-center min-w-0 pr-1">
        {/* Line 1: Headline */}
        <div className="flex items-center gap-1.5 text-xs sm:text-[13px] font-extrabold text-slate-950 leading-tight whitespace-nowrap">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping shrink-0" />
          <span>Need Urgent Medical Care?</span>
        </div>

        {/* Line 2: Subtitle */}
        <div className="text-[10.5px] sm:text-[11px] font-semibold text-orange-600 mt-0.5 leading-tight whitespace-nowrap flex items-center gap-1.5">
          <span>Doctor at Doorstep in 30–45 Mins</span>
          <span className="text-slate-300">•</span>
          <span className="text-slate-500 font-medium">DHA Licensed</span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1.5 shrink-0 pl-1">
        <button
          type="button"
          onClick={() => openBooking()}
          className="px-3 py-1.5 brand-gradient-bg hover:opacity-95 text-white text-xs font-bold rounded-xl shadow-sm transition-all cursor-pointer whitespace-nowrap"
        >
          Book Now
        </button>
        <a
          href={getWhatsAppBookingUrl("Need urgent doctor visit in Dubai.")}
          target="_blank"
          rel="noopener noreferrer"
          className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl border border-emerald-200 transition-colors flex items-center justify-center shrink-0"
          title="Chat on WhatsApp"
        >
          <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
        </a>
        <button
          type="button"
          onClick={() => setMinimized(true)}
          className="w-5 h-5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer shrink-0"
          aria-label="Minimize emergency bar"
        >
          <X className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
