"use client";

import React from "react";
import { useBooking } from "../booking/BookingContext";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { MessageSquare, Phone, Stethoscope, Clock } from "lucide-react";

export function FloatingMobileBar() {
  const { openBooking } = useBooking();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-t border-orange-200 shadow-2xl p-2.5 px-3 pb-4 animate-in slide-in-from-bottom duration-300">
      {/* Top micro arrival indicator */}
      <div className="flex items-center justify-between px-1 mb-1.5 text-[10px] font-bold text-slate-700">
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>DHA Doctors On Duty in Dubai</span>
        </div>
        <div className="flex items-center gap-1 text-orange-600">
          <Clock className="w-3 h-3" />
          <span>Doorstep ETA: 30-45 Mins</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {/* WhatsApp Button */}
        <a
          href={getWhatsAppBookingUrl()}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center py-2 px-1 bg-emerald-600 active:bg-emerald-700 text-white rounded-xl font-bold shadow-sm transition-all"
        >
          <MessageSquare className="w-4 h-4 mb-0.5 fill-white/20" />
          <span className="text-[11px] leading-tight">WhatsApp</span>
        </a>

        {/* Call 24/7 Button */}
        <a
          href={getDirectCallUrl()}
          className="flex flex-col items-center justify-center py-2 px-1 bg-slate-900 active:bg-slate-800 text-white rounded-xl font-bold shadow-sm transition-all"
        >
          <Phone className="w-4 h-4 mb-0.5 text-orange-400" />
          <span className="text-[11px] leading-tight">Call 24/7</span>
        </a>

        {/* Book Doctor Button */}
        <button
          type="button"
          onClick={() => openBooking()}
          className="flex flex-col items-center justify-center py-2 px-1 brand-gradient-bg active:opacity-90 text-white rounded-xl font-bold shadow-md shadow-orange-500/30 transition-all cursor-pointer"
        >
          <Stethoscope className="w-4 h-4 mb-0.5" />
          <span className="text-[11px] leading-tight">Book Doctor</span>
        </button>
      </div>
    </div>
  );
}
