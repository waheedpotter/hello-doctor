"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { SERVICES } from "@/data/services";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import {
  Phone,
  MessageSquare,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  Award,
  HeartHandshake,
  CheckCircle,
  CreditCard
} from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-900 pt-16 pb-28 md:pb-16 relative overflow-hidden">
      {/* Background ambient orange glow */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto relative z-10">
        {/* Top Emergency CTA Strip */}
        <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 rounded-3xl p-6 md:p-8 mb-12 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 text-white">
          <div className="space-y-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 text-xs font-bold uppercase tracking-wider text-orange-100">
              <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping" />
              24/7 Rapid Emergency Response in Dubai
            </div>
            <h3 className="text-xl md:text-2xl font-bold">
              Need a DHA Licensed Doctor at Your Doorstep Right Now?
            </h3>
            <p className="text-sm text-orange-100 max-w-xl">
              Our medical teams reach your home, hotel, or villa anywhere in Dubai within 30-45 minutes with full diagnostic equipment.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            <a
              href={getWhatsAppBookingUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              WhatsApp 24/7
            </a>
            <a
              href={getDirectCallUrl()}
              className="w-full sm:w-auto px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 shadow-lg border border-white/20 transition-all"
            >
              <Phone className="w-4 h-4 text-orange-400" />
              {SITE_CONFIG.phoneDisplay}
            </a>
          </div>
        </div>

        {/* 4-Column Footer Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          {/* Column 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="relative w-64 sm:w-72 h-16 sm:h-20 bg-white p-2.5 sm:p-3 rounded-2xl shadow-lg border border-slate-800">
              <Image
                src="/images/logo.png"
                alt="Hello Doctor Home Health Care LLC"
                fill
                className="object-contain p-1"
              />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white tracking-wide">
                Hello Doctor Home Health Care LLC
              </h3>
              <p className="text-xs text-orange-400 font-semibold mt-0.5">
                DHA Licensed Home Healthcare Facility #{SITE_CONFIG.dhaLicense}
              </p>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed pr-4">
              <strong className="text-slate-200">Hello Doctor Home Health Care LLC</strong> is Dubai&apos;s premier DHA-licensed home healthcare and doctor-on-call service. We deliver hospital-standard physician consultations, IV drip vitamin infusions, certified home nursing, and lab diagnostic tests directly to homes, hotels, and offices 24/7 across Dubai.
            </p>
            <div className="space-y-2 pt-1 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Hello Doctor Home Health Care LLC (DHA #{SITE_CONFIG.dhaLicense})</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-orange-400 shrink-0" />
                <span>{SITE_CONFIG.address.streetAddress}, Dubai, UAE</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{SITE_CONFIG.workingHours}</span>
              </div>
            </div>
          </div>

          {/* Column 2: Medical Services */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-orange-500/30 pb-2">
              Medical Services
            </h4>
            <ul className="space-y-2.5 text-xs">
              {SERVICES.map((srv) => (
                <li key={srv.id}>
                  <Link
                    href={`/services/${srv.slug}/`}
                    className="hover:text-orange-400 transition-colors flex items-center justify-between"
                  >
                    <span>{srv.shortTitle}</span>
                    <span className="text-[10px] text-orange-400/80">AED {srv.priceStartingAtAed}+</span>
                  </Link>
                </li>
              ))}
              <li className="pt-1.5 border-t border-slate-800">
                <Link
                  href="/services/"
                  className="text-orange-400 font-bold hover:underline text-[11px] flex items-center gap-1"
                >
                  <span>All Medical Services Directory</span>
                  <span>→</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Dubai Areas */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-orange-500/30 pb-2">
              Areas We Serve
            </h4>
            <ul className="space-y-2.5 text-xs">
              {DUBAI_LOCATIONS.slice(0, 7).map((loc) => (
                <li key={loc.id}>
                  <Link
                    href={`/areas-we-serve/${loc.slug}/`}
                    className="hover:text-orange-400 transition-colors flex items-center justify-between"
                  >
                    <span>{loc.name}</span>
                    <span className="text-[10px] text-emerald-400">{loc.averageEtaMinutes}m ETA</span>
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/areas-we-serve/"
                  className="text-orange-400 font-semibold hover:underline block pt-1"
                >
                  All Dubai Areas →
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Quick Links & Trust */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-orange-500/30 pb-2">
              Company & SEO Hub
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/doctors/" className="hover:text-orange-400 transition-colors">
                  DHA Licensed Doctors
                </Link>
              </li>
              <li>
                <Link href="/blog/" className="hover:text-orange-400 transition-colors">
                  Medical Articles & Guides
                </Link>
              </li>
              <li>
                <Link href="/about-us/" className="hover:text-orange-400 transition-colors">
                  About Hello Doctor
                </Link>
              </li>
              <li>
                <Link href="/contact-us/" className="hover:text-orange-400 transition-colors">
                  Contact & Support
                </Link>
              </li>
              <li>
                <Link href="/book-appointment/" className="hover:text-orange-400 transition-colors">
                  Book Home Appointment
                </Link>
              </li>
            </ul>

            <div className="mt-6 pt-4 border-t border-slate-800">
              <div className="text-[11px] font-bold text-slate-400 mb-2">Accepted Payments:</div>
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800">Visa / MC</span>
                <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800">Apple Pay</span>
                <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800">Cash</span>
              </div>
            </div>
          </div>
        </div>

        {/* DHA Disclaimer & Copyright */}
        <div className="pt-8 border-t border-slate-900 text-xs text-slate-500 space-y-4">
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80 leading-relaxed text-[11px]">
            <strong className="text-slate-300">Medical Disclaimer:</strong> Hello Doctor is a licensed home healthcare facility authorized by the Dubai Health Authority (DHA). Our doctors provide on-demand outpatient, urgent, and primary healthcare at residential, commercial, and hotel premises. For critical, life-threatening emergencies (e.g. cardiac arrest, severe major trauma, stroke), please dial <strong>998 (Dubai Ambulance)</strong> immediately.
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-[11px]">
            <div>
              © {new Date().getFullYear()} {SITE_CONFIG.legalName}. All rights reserved. Registered under DHA License #{SITE_CONFIG.dhaLicense}.
            </div>
            <div className="flex items-center gap-6">
              <Link href="/sitemap.xml" className="hover:text-orange-400">
                HTML Sitemap
              </Link>
              <Link href="/contact-us/" className="hover:text-orange-400">
                Privacy Policy
              </Link>
              <Link href="/contact-us/" className="hover:text-orange-400">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
