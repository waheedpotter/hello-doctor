"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useBooking } from "../booking/BookingContext";
import { SERVICES } from "@/data/services";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import {
  Phone,
  MessageSquare,
  Clock,
  ShieldCheck,
  ChevronDown,
  Menu,
  X,
  Stethoscope,
  MapPin,
  Calendar,
  Sparkles,
  Search,
  ArrowRight
} from "lucide-react";

export function Header() {
  const pathname = usePathname();
  const { openBooking } = useBooking();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);
  const [locationsDropdownOpen, setLocationsDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close menus on route change
  useEffect(() => {
    setMobileMenuOpen(false);
    setServicesDropdownOpen(false);
    setLocationsDropdownOpen(false);
  }, [pathname]);

  return (
    <header className="w-full sticky top-0 z-50 transition-all duration-300">
      {/* Top Announcement & Emergency Bar */}
      <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 text-white text-xs py-1.5 px-4 sm:px-6 hidden md:block">
        <div className="max-w-[1400px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>DHA Licensed Doctors On Duty Across Dubai Right Now</span>
            </div>
            <div className="flex items-center gap-1 text-orange-100 font-normal">
              <Clock className="w-3.5 h-3.5" />
              <span>Doorstep Arrival: <strong>30 - 45 Minutes</strong></span>
            </div>
          </div>

          <div className="flex items-center gap-3.5 lg:gap-4.5">
            <div className="flex items-center gap-1 text-orange-100">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>DHA #{SITE_CONFIG.dhaLicense}</span>
            </div>

            <span className="text-orange-300/50">|</span>

            {/* Top Bar Right: About Us & Contact Us */}
            <Link
              href="/about-us/"
              className="text-white hover:text-orange-100 font-semibold transition-colors"
            >
              About Us
            </Link>
            <Link
              href="/contact-us/"
              className="text-white hover:text-orange-100 font-semibold transition-colors"
            >
              Contact Us
            </Link>

            <span className="text-orange-300/50">|</span>

            <a
              href={getDirectCallUrl()}
              className="hover:underline font-bold flex items-center gap-1 text-white bg-white/15 hover:bg-white/25 px-2.5 py-0.5 rounded-full transition-all"
            >
              <Phone className="w-3 h-3 text-white" />
              <span>{SITE_CONFIG.phoneDisplay}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav
        className={`w-full transition-all duration-300 ${
          isScrolled
            ? "bg-white/95 backdrop-blur-md shadow-md py-2.5 border-b border-orange-100"
            : "bg-white py-3 md:py-4 border-b border-slate-100"
        }`}
      >
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 flex items-center justify-between gap-3 md:gap-6 flex-nowrap">
          {/* Left Side: Enriched Large Logo + Navigation Menu */}
          <div className="flex items-center gap-4 sm:gap-6 lg:gap-8 shrink-0">
            {/* Brand Logo - Enlarged for Premium Prominence */}
            <Link href="/" className="flex items-center shrink-0 group">
              <div className="relative w-[180px] sm:w-[215px] md:w-[245px] h-12 sm:h-14 md:h-16">
                <Image
                  src="/images/logo.png"
                  alt="Hello Doctor Dubai - Doctor at Home & Home Health Care"
                  fill
                  priority
                  className="object-contain object-left transition-transform duration-300 group-hover:scale-102"
                />
              </div>
            </Link>

            {/* Desktop Navigation Links - Clean, Spacious & Shifted Right */}
            <div className="hidden lg:flex items-center gap-5 xl:gap-7 ml-4 lg:ml-8 xl:ml-12 whitespace-nowrap shrink-0">
              {/* Medical Services Dropdown */}
              <div
                className="relative group"
                onMouseEnter={() => setServicesDropdownOpen(true)}
                onMouseLeave={() => setServicesDropdownOpen(false)}
              >
                <Link
                  href="/services/"
                  className="flex items-center gap-1 text-sm font-bold text-slate-800 hover:text-orange-600 py-2 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>Medical Services</span>
                  <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-orange-600 transition-transform group-hover:rotate-180" />
                </Link>

                {servicesDropdownOpen && (
                  <div className="absolute top-full left-0 w-[640px] max-h-[85vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-orange-100 p-4 grid grid-cols-2 gap-2 animate-in fade-in slide-in-from-top-2 duration-200 z-50">
                    {SERVICES.map((srv) => (
                      <Link
                        key={srv.id}
                        href={`/services/${srv.slug}/`}
                        className="p-2.5 rounded-xl hover:bg-orange-50/80 border border-transparent hover:border-orange-200 transition-all flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-orange-600">
                              {srv.shortTitle}
                            </span>
                            <span className="text-[10px] font-bold text-orange-600 bg-orange-100 px-1.5 py-0.5 rounded-full">
                              AED {srv.priceStartingAtAed}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 line-clamp-1">
                            {srv.tagline}
                          </p>
                        </div>
                      </Link>
                    ))}
                    <div className="col-span-2 pt-2.5 mt-1 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 px-2">
                      <Link
                        href="/services/"
                        className="flex items-center gap-1 text-orange-600 hover:underline font-bold"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-orange-500" />
                        <span>All Medical Services Directory</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                      <button
                        type="button"
                        onClick={() => openBooking()}
                        className="text-orange-600 hover:underline font-bold cursor-pointer"
                      >
                        Instant Booking →
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Locations Dropdown */}
              <div
                className="relative group"
                onMouseEnter={() => setLocationsDropdownOpen(true)}
                onMouseLeave={() => setLocationsDropdownOpen(false)}
              >
                <Link
                  href="/areas-we-serve/"
                  className="flex items-center gap-1 text-sm font-bold text-slate-800 hover:text-orange-600 py-2 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>Areas We Serve</span>
                  <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-orange-600 transition-transform group-hover:rotate-180" />
                </Link>

                {locationsDropdownOpen && (
                  <div className="absolute top-full left-0 w-[420px] bg-white rounded-2xl shadow-2xl border border-orange-100 p-4 grid grid-cols-2 gap-1.5 animate-in fade-in slide-in-from-top-2 duration-200 z-50">
                    {DUBAI_LOCATIONS.slice(0, 8).map((loc) => (
                      <Link
                        key={loc.id}
                        href={`/areas-we-serve/${loc.slug}/`}
                        className="p-2 rounded-lg hover:bg-orange-50 text-xs font-medium text-slate-700 hover:text-orange-600 flex items-center justify-between"
                      >
                        <span>{loc.name}</span>
                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                          {loc.averageEtaMinutes}m
                        </span>
                      </Link>
                    ))}
                    <div className="col-span-2 pt-2 mt-1 border-t border-slate-100 text-center">
                      <Link
                        href="/areas-we-serve/"
                        className="text-xs text-orange-600 font-bold hover:underline"
                      >
                        View All Dubai Areas & Coverage Map →
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              <Link
                href="/doctors/"
                className="text-sm font-bold text-slate-800 hover:text-orange-600 transition-colors whitespace-nowrap"
              >
                Our Doctors
              </Link>

              <Link
                href="/blog/"
                className="text-sm font-bold text-slate-800 hover:text-orange-600 transition-colors whitespace-nowrap"
              >
                Health Guides
              </Link>
            </div>
          </div>

          {/* Right Side: Action CTAs - Guaranteed Full Visibility */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0 whitespace-nowrap">
            {/* WhatsApp Quick Connect */}
            <a
              href={getWhatsAppBookingUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 font-bold text-xs transition-all shadow-sm shrink-0"
              title="Chat with Doctor on WhatsApp"
            >
              <MessageSquare className="w-4 h-4 text-emerald-600 fill-emerald-500 shrink-0" />
              <span>WhatsApp</span>
            </a>

            {/* Direct 24/7 Call */}
            <a
              href={getDirectCallUrl()}
              className="hidden xl:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-xs transition-all shadow-sm shrink-0"
            >
              <Phone className="w-3.5 h-3.5 text-orange-600 shrink-0" />
              <span>Call 24/7</span>
            </a>

            {/* Primary Orange Book Button - Always Fully Visible */}
            <button
              type="button"
              onClick={() => openBooking()}
              className="brand-gradient-bg hover:opacity-95 text-white font-bold text-xs sm:text-sm px-3.5 sm:px-5 py-2.5 rounded-xl shadow-md shadow-orange-500/25 flex items-center gap-1.5 transition-all transform active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Stethoscope className="w-4 h-4 shrink-0" />
              <span>Book Doctor Now</span>
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-100 text-slate-700 hover:bg-orange-50 hover:text-orange-600 flex items-center justify-center transition-colors shrink-0"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Slide-Down Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-slate-100 px-4 py-6 space-y-4 shadow-xl animate-in slide-in-from-top-4 duration-300 max-h-[80vh] overflow-y-auto">
            <div className="space-y-1">
              <div className="flex items-center justify-between px-3 py-1">
                <span className="font-bold text-xs text-slate-400 uppercase tracking-wider">
                  Medical Services
                </span>
                <Link
                  href="/services/"
                  className="text-xs font-bold text-orange-600 hover:underline"
                >
                  View All Directory →
                </Link>
              </div>
              <div className="grid grid-cols-1 gap-1">
                {SERVICES.map((srv) => (
                  <Link
                    key={srv.id}
                    href={`/services/${srv.slug}/`}
                    className="flex items-center justify-between p-2.5 rounded-xl text-sm font-medium text-slate-900 hover:bg-orange-50 hover:text-orange-600 transition-colors"
                  >
                    <span>{srv.shortTitle}</span>
                    <span className="text-[10px] font-bold text-orange-600 bg-orange-100 px-2 py-0.5 rounded-full">
                      AED {srv.priceStartingAtAed}+
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 space-y-1">
              <div className="font-bold text-xs text-slate-400 uppercase tracking-wider px-3 py-1">
                Company & Coverage
              </div>
              <Link
                href="/doctors/"
                className="block p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-orange-50 hover:text-orange-600"
              >
                Our DHA Doctors
              </Link>
              <Link
                href="/areas-we-serve/"
                className="block p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-orange-50 hover:text-orange-600"
              >
                Areas We Serve in Dubai
              </Link>
              <Link
                href="/blog/"
                className="block p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-orange-50 hover:text-orange-600"
              >
                Health Guides & Blog
              </Link>
              <Link
                href="/about-us/"
                className="block p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-orange-50 hover:text-orange-600"
              >
                About Hello Doctor
              </Link>
              <Link
                href="/contact-us/"
                className="block p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-orange-50 hover:text-orange-600"
              >
                Contact Us
              </Link>
            </div>

            {/* Mobile CTAs */}
            <div className="pt-4 border-t border-slate-100 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => openBooking()}
                className="w-full py-3.5 brand-gradient-bg text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-md shadow-orange-500/30 cursor-pointer"
              >
                <Stethoscope className="w-4 h-4" />
                <span>Book Doctor Consultation</span>
              </button>
              <a
                href={getWhatsAppBookingUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>
              <a
                href={getDirectCallUrl()}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-orange-400" />
                <span>Call 24/7 Hotline: {SITE_CONFIG.phoneDisplay}</span>
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
