"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { MedicalService } from "@/types/service";
import { useBooking } from "../booking/BookingContext";
import { DUBAI_LOCATIONS } from "@/data/locations";
import { DOCTORS } from "@/data/doctors";
import { SITE_CONFIG, getDirectCallUrl, getWhatsAppBookingUrl } from "@/lib/utils";
import { FAQSection } from "../home/FAQSection";
import { ReviewsSection } from "../home/ReviewsSection";
import {
  Clock,
  ShieldCheck,
  CheckCircle2,
  Phone,
  MessageSquare,
  Stethoscope,
  ArrowRight,
  Sparkles,
  MapPin,
  HelpCircle,
  Award,
  Zap,
  Check,
  Star
} from "lucide-react";

export function ServiceDetailView({ service }: { service: MedicalService }) {
  const { openBooking } = useBooking();

  return (
    <div className="bg-white">
      {/* Hero Section for Service */}
      <section className="relative overflow-hidden bg-gradient-to-b from-orange-50/70 via-white to-orange-50/20 pt-8 pb-16 lg:pt-12 lg:pb-20 border-b border-orange-100/60">
        <div className="container mx-auto">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
            <Link href="/" className="hover:text-orange-600">Home</Link>
            <span>/</span>
            <Link href="/services/" className="hover:text-orange-600">Medical Services</Link>
            <span>/</span>
            <span className="text-orange-600 font-semibold">{service.shortTitle}</span>
          </nav>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-5">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-100 text-orange-950 text-xs font-bold border border-orange-200">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <span>{service.heroBadge}</span>
              </div>

              {/* H1 Headline */}
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-950 tracking-tight leading-tight">
                {service.h1}
              </h1>

              {/* Tagline */}
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
                {service.overview}
              </p>

              {/* Price & ETA Highlight Box */}
              <div className="bg-orange-50/90 rounded-2xl p-4 border border-orange-200/80 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-slate-500 font-medium">Starting Price</div>
                  <div className="text-2xl font-black text-orange-600">
                    AED {service.priceStartingAtAed}
                  </div>
                </div>

                <div className="h-8 w-px bg-orange-200 hidden sm:block" />

                <div>
                  <div className="text-xs text-slate-500 font-medium">Average Response Time</div>
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-1">
                    <Clock className="w-4 h-4 text-orange-600" />
                    30 - 45 Minutes Across Dubai
                  </div>
                </div>

                <div className="h-8 w-px bg-orange-200 hidden sm:block" />

                <div>
                  <div className="text-xs text-slate-500 font-medium">Accreditation</div>
                  <div className="text-sm font-bold text-emerald-700 flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    100% DHA Licensed
                  </div>
                </div>
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => openBooking({ serviceSlug: service.slug })}
                  className="w-full sm:w-auto px-7 py-4 brand-gradient-bg hover:opacity-95 text-white font-bold text-sm sm:text-base rounded-2xl shadow-xl shadow-orange-500/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Stethoscope className="w-5 h-5" />
                  <span>Book {service.shortTitle} Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={getWhatsAppBookingUrl(`Hello! I would like to book ${service.shortTitle} in Dubai. Please assist me.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-6 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp 24/7</span>
                </a>

                <a
                  href={getDirectCallUrl()}
                  className="w-full sm:w-auto px-5 py-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 transition-all"
                >
                  <Phone className="w-4 h-4 text-orange-400" />
                  <span>Call Now</span>
                </a>
              </div>
            </div>

            {/* Right Column: Featured Image & Quick Trust Box */}
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-orange-100 brand-card-glow">
                <div className="relative h-80 sm:h-96 w-full">
                  <Image
                    src={service.featuredImage}
                    alt={service.title}
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  
                  <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-orange-300">
                      <Zap className="w-4 h-4 fill-orange-400" />
                      <span>On-Demand Healthcare at Your Doorstep</span>
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold">
                      DHA Licensed Clinicians in Dubai
                    </h3>
                    <p className="text-xs text-slate-200">
                      Card payment, Apple Pay & Cash accepted upon arrival. Itemized medical invoices for insurance.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us & Key Benefits */}
      <section className="py-16 bg-white">
        <div className="container mx-auto">
          <div className="max-w-3xl mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
              Why Patients Choose Us
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
              Why Book <span className="brand-gradient-text">{service.shortTitle}</span> With Hello Doctor?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {service.whyChooseUs.map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-orange-200 transition-all flex items-start gap-3.5"
              >
                <div className="w-8 h-8 rounded-xl brand-gradient-bg text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    {item.split(":")[0]}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.includes(":") ? item.split(":")[1] : item}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Symptoms & Conditions Treated */}
      {service.symptomsTreated && service.symptomsTreated.length > 0 && (
        <section className="py-16 bg-orange-50/40 border-y border-orange-100">
          <div className="container mx-auto">
            <div className="max-w-3xl mb-8">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
                Clinical Scope
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
                Conditions & Symptoms Treated
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                Our medical teams are equipped to evaluate and treat a broad spectrum of acute conditions at home.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {service.symptomsTreated.map((symptom, idx) => (
                <div
                  key={idx}
                  className="bg-white p-3.5 rounded-xl border border-orange-100/80 shadow-sm flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-slate-800"
                >
                  <span className="w-2 h-2 rounded-full bg-orange-600" />
                  <span>{symptom}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Pricing Packages Table */}
      {service.priceOptions && service.priceOptions.length > 0 && (
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
                Transparent Pricing
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
                {service.shortTitle} <span className="brand-gradient-text">Packages & Rates</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                No hidden call-out fees. Includes full examination and electronic DHA prescriptions.
              </p>
            </div>

            <div className={`grid gap-6 ${
              service.priceOptions.length > 4
                ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                : "grid-cols-1 md:grid-cols-3"
            }`}>
              {service.priceOptions.map((opt, idx) => (
                <div
                  key={idx}
                  className={`rounded-3xl p-7 border transition-all flex flex-col justify-between relative ${
                    opt.popular
                      ? "border-orange-500 bg-orange-50/50 shadow-xl ring-2 ring-orange-500/20"
                      : "border-slate-200 bg-white hover:border-orange-200"
                  }`}
                >
                  {opt.badge && (
                    <div className="absolute top-4 right-4 bg-orange-600 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full">
                      {opt.badge}
                    </div>
                  )}

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">
                      {opt.name}
                    </h3>
                    <div className="text-3xl font-black text-orange-600 mb-3">
                      AED {opt.priceAed}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed mb-6">
                      {opt.description}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => openBooking({ serviceSlug: service.slug })}
                    className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      opt.popular
                        ? "brand-gradient-bg text-white shadow-md"
                        : "bg-slate-900 text-white hover:bg-slate-800"
                    }`}
                  >
                    <span>Select & Book Package</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Step by Step Procedure */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
              What to Expect
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-2">
              The {service.shortTitle} <span className="brand-gradient-text">Procedure Step-by-Step</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {service.procedureSteps.map((step) => (
              <div
                key={step.stepNumber}
                className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl brand-gradient-bg text-white flex items-center justify-center font-bold text-sm mb-4 shadow-sm">
                    {step.stepNumber}
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1.5">
                    {step.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {step.duration && (
                  <div className="pt-4 mt-3 border-t border-slate-100 text-[11px] font-semibold text-orange-600 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Est. Time: {step.duration}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <FAQSection
        faqs={service.faqs}
        title={`${service.shortTitle} in Dubai - FAQs`}
      />

      {/* Reviews */}
      <ReviewsSection />

      {/* Bottom Emergency Banner */}
      <section className="py-14 bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 text-white text-center">
        <div className="container mx-auto max-w-3xl space-y-4">
          <h3 className="text-2xl sm:text-3xl font-extrabold">
            Ready to Receive {service.shortTitle} at Your Doorstep?
          </h3>
          <p className="text-sm text-orange-100">
            DHA-licensed clinicians dispatched in 30-45 minutes across all Dubai areas.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => openBooking({ serviceSlug: service.slug })}
              className="w-full sm:w-auto px-8 py-3.5 bg-white text-orange-600 font-extrabold text-sm rounded-xl shadow-lg hover:bg-orange-50 transition-all cursor-pointer"
            >
              Book Instant Appointment
            </button>
            <a
              href={getWhatsAppBookingUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
