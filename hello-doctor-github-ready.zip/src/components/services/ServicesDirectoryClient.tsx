"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { MedicalService } from "@/types/service";
import { useBooking } from "../booking/BookingContext";
import { getWhatsAppBookingUrl, getDirectCallUrl } from "@/lib/utils";
import { FAQSection } from "../home/FAQSection";
import {
  Stethoscope,
  Droplet,
  HeartPulse,
  FlaskConical,
  Activity,
  ShieldCheck,
  Hotel,
  Clock,
  ArrowRight,
  Sparkles,
  Check,
  Search,
  MessageSquare,
  Phone
} from "lucide-react";

const CATEGORIES = [
  { id: "all", label: "All Medical Services" },
  { id: "urgent-care", label: "Doctor on Call, Home & Hotel" },
  { id: "wellness", label: "IV Drips & Peptides" },
  { id: "diagnostics", label: "Lab & Blood Tests" },
  { id: "therapy", label: "Physiotherapy" },
  { id: "nursing", label: "Home Nursing" },
  { id: "family-care", label: "Baby & Elderly Care" },
];

export function ServicesDirectoryClient({ services }: { services: MedicalService[] }) {
  const { openBooking } = useBooking();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredServices = services.filter((srv) => {
    const matchesCategory =
      selectedCategory === "all" || srv.category === selectedCategory;
    const matchesSearch =
      srv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      srv.shortTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      srv.overview.toLowerCase().includes(searchQuery.toLowerCase()) ||
      srv.symptomsTreated.some((sym) =>
        sym.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesCategory && matchesSearch;
  });

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case "Stethoscope":
        return <Stethoscope className="w-6 h-6" />;
      case "Droplet":
        return <Droplet className="w-6 h-6" />;
      case "HeartPulse":
        return <HeartPulse className="w-6 h-6" />;
      case "FlaskConical":
        return <FlaskConical className="w-6 h-6" />;
      case "Activity":
        return <Activity className="w-6 h-6" />;
      case "ShieldCheck":
        return <ShieldCheck className="w-6 h-6" />;
      case "Hotel":
        return <Hotel className="w-6 h-6" />;
      case "Sparkles":
        return <Sparkles className="w-6 h-6" />;
      default:
        return <Stethoscope className="w-6 h-6" />;
    }
  };

  const servicesFaqs = [
    {
      question: "How do I book a Doctor on Call, Nurse, or Home Lab Test in Dubai?",
      answer: "You can book in under 2 minutes by clicking 'Book Now', calling our 24/7 hotline at +971 55 253 7940, or sending a message on WhatsApp with your location and symptoms.",
    },
    {
      question: "How fast will the medical team arrive at my residence or hotel?",
      answer: "Our doctors and nurses are stationed across central Dubai hubs (Downtown, Dubai Marina, JBR, Palm Jumeirah, Business Bay, JVC, and Al Barsha). Average arrival time is 30 to 45 minutes.",
    },
    {
      question: "Can I claim insurance reimbursement for in-home medical services in Dubai?",
      answer: "Yes. While we operate on a direct pay model upon arrival (Cards, Apple Pay, Cash), we provide itemized DHA medical invoices and diagnostic reports for reimbursement with all UAE and international insurance providers.",
    },
    {
      question: "Are your doctors and nurses licensed by the Dubai Health Authority (DHA)?",
      answer: "Yes, 100% of our clinical doctors, registered nurses, physiotherapists, and phlebotomists hold active DHA licenses under Facility License #6978946.",
    },
  ];

  return (
    <div className="py-12 lg:py-16">
      <div className="container mx-auto">
        {/* Search & Filter Toolbar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10 pb-6 border-b border-slate-200/80">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? "brand-gradient-bg text-white shadow-md shadow-orange-500/20"
                    : "bg-slate-100 text-slate-700 hover:bg-orange-50 hover:text-orange-600 border border-transparent"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72 shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search services or symptoms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 transition-all bg-white"
            />
          </div>
        </div>

        {/* Services Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-3xl border border-slate-200/90 hover:border-orange-300 shadow-sm brand-card-glow-hover flex flex-col justify-between overflow-hidden transition-all duration-300 group"
            >
              <div>
                {/* Image Header */}
                <div className="relative h-48 w-full bg-slate-100 overflow-hidden">
                  <Image
                    src={service.featuredImage}
                    alt={service.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />

                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-slate-900 flex items-center gap-1 shadow-sm">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>DHA Licensed</span>
                  </div>

                  <div className="absolute top-3 right-3 bg-orange-600 text-white px-2.5 py-1 rounded-full text-[11px] font-extrabold shadow-sm">
                    From AED {service.priceStartingAtAed}
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
                    <div className="w-10 h-10 rounded-xl brand-gradient-bg text-white flex items-center justify-center shadow-md">
                      {getServiceIcon(service.iconName)}
                    </div>
                    <div className="flex items-center gap-1 text-xs font-bold text-orange-200 bg-black/40 px-2.5 py-1 rounded-lg backdrop-blur-sm">
                      <Clock className="w-3 h-3" />
                      <span>{service.responseTimeMinutes}m Arrival</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                      {service.shortTitle}
                    </h2>
                  </div>

                  <p className="text-xs font-medium text-orange-700/90">
                    {service.tagline}
                  </p>

                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {service.overview}
                  </p>

                  {/* Highlights */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-100">
                    {service.whyChooseUs.slice(0, 3).map((point, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer CTAs */}
              <div className="p-6 pt-0 space-y-2">
                <Link
                  href={`/services/${service.slug}/`}
                  className="w-full py-3 bg-orange-50 hover:bg-orange-100 text-orange-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors border border-orange-200/60"
                >
                  <span>View Treatments, Pricing & Details</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>

                <button
                  type="button"
                  onClick={() => openBooking({ serviceSlug: service.slug })}
                  className="w-full py-3 brand-gradient-bg hover:opacity-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                >
                  <Stethoscope className="w-3.5 h-3.5" />
                  <span>Book In-Home Consultation</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredServices.length === 0 && (
          <div className="text-center py-16 bg-slate-50 rounded-3xl border border-slate-200">
            <h3 className="text-lg font-bold text-slate-800">No medical services found</h3>
            <p className="text-xs text-slate-500 mt-1">Try adjusting your search keywords or category filters.</p>
            <button
              type="button"
              onClick={() => {
                setSelectedCategory("all");
                setSearchQuery("");
              }}
              className="mt-4 px-4 py-2 brand-gradient-bg text-white text-xs font-bold rounded-xl"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* FAQs */}
        <div className="mt-20">
          <FAQSection
            faqs={servicesFaqs}
            title="Frequently Asked Questions About Hello Doctor Services"
          />
        </div>

        {/* Emergency Help Dispatch Banner */}
        <div className="mt-16 bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 rounded-3xl p-8 text-white text-center shadow-xl">
          <h3 className="text-2xl sm:text-3xl font-extrabold">Need Immediate Medical Care in Dubai?</h3>
          <p className="mt-2 text-sm text-orange-100 max-w-xl mx-auto">
            Our clinical team is on standby 24/7 to dispatch a DHA-licensed doctor or nurse to your location within 30-45 minutes.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 mt-6">
            <a
              href={getWhatsAppBookingUrl("Hello! I need an in-home medical service in Dubai immediately. Please assist me.")}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-7 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp 24/7 Dispatch</span>
            </a>
            <a
              href={getDirectCallUrl()}
              className="w-full sm:w-auto px-7 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg"
            >
              <Phone className="w-4 h-4 text-orange-400" />
              <span>Call Hotline Now</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
