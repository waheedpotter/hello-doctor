import { BlogPost, BlogCategory } from "@/types/blog";

export const BLOG_CATEGORIES: BlogCategory[] = [
  {
    id: "home-healthcare",
    slug: "home-healthcare",
    name: "Home Healthcare",
    description: "Guidance on doctor on call, at-home nursing, and emergency care in Dubai.",
  },
  {
    id: "iv-therapy",
    slug: "iv-therapy",
    name: "IV Therapy & Wellness",
    description: "Everything you need to know about vitamin drips, hydration, and immunity boosters.",
  },
  {
    id: "family-health",
    slug: "family-health",
    name: "Family & Senior Health",
    description: "Expert medical advice for pediatric fever, elderly care, and chronic conditions.",
  },
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: "when-to-call-doctor-at-home-dubai",
    slug: "when-to-call-doctor-at-home-dubai",
    title: "When to Call a Doctor at Home in Dubai: Symptoms, Process & What to Expect",
    metaDescription: "Learn when calling a doctor to your home or hotel in Dubai is the best medical choice. Understand arrival times, DHA licensing, medications & costs.",
    excerpt: "Experiencing high fever, severe migraine, or food poisoning? Discover how 24/7 doctor home visits work in Dubai, why they save hours of hospital waiting, and what treatments can be done at home.",
    content: `
## Why Home Healthcare is Transforming Medical Visits in Dubai

Navigating busy Dubai traffic and waiting in crowded emergency rooms or hospital outpatient clinics when feeling acutely ill can be exhausting. Hello Doctor's 24/7 **Doctor at Home Dubai** service provides a modern alternative: hospital-grade medical evaluations in the comfort of your living room or hotel suite.

### Common Symptoms Best Treated at Home

1. **High Fevers, Chills & Acute Viral Infections**: Our DHA-licensed doctors carry rapid diagnostic testing tools, antipyretic injectables, and prescriptions to break fevers swiftly.
2. **Severe Food Poisoning, Nausea & Dehydration**: Rapid anti-emetic medications and concurrent IV saline/electrolyte therapy restore hydration within an hour.
3. **Migraines & Tension Headaches**: Pain management administered in a dark, quiet home environment without sensory hospital overload.
4. **Asthma & Bronchitis Flare-ups**: Portable nebulizers and bronchodilators administered on-site.
5. **Elderly Patient Consultations**: Avoiding the physical stress of moving elderly relatives with limited mobility.

### How Fast Does the Doctor Arrive?

Our medical response units are distributed across major Dubai zones (Downtown, Marina, JVC, Palm Jumeirah, and Al Barsha). The average arrival time is **30 to 45 minutes** from the moment our medical coordinator confirms your booking.

### What is Included in a Home Visit?

- Full clinical history & physical examination.
- Complete vitals check (Blood Pressure, Heart Rate, Pulse Oximetry, ECG if indicated, Blood Glucose).
- On-site administration of acute oral and injectable medications.
- DHA electronic prescriptions (e-Rx) sent directly to your phone for pharmacy delivery.
- Official DHA medical sick leave certificates.
- Itemized insurance reimbursement reports.

To request a doctor immediately, call **+971 55 253 7940** or chat with us on WhatsApp 24/7.
    `,
    authorDoctorId: "dr-imran-qureshi",
    publishedDate: "2024-05-10",
    updatedDate: "2024-11-15",
    readingTimeMinutes: 5,
    categorySlug: "home-healthcare",
    categoryName: "Home Healthcare",
    tags: ["Doctor at Home", "Dubai Healthcare", "Emergency GP", "DHA Doctor"],
    featuredImage: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "benefits-of-iv-drip-therapy-dubai",
    slug: "benefits-of-iv-drip-therapy-dubai",
    title: "The Ultimate Guide to IV Drip Therapy at Home in Dubai: Science & Benefits",
    metaDescription: "Discover how vitamin IV drip therapy works at home in Dubai. Learn about NAD+, Glutathione, Myers Cocktail, immunity and rapid hangover hydration.",
    excerpt: "Intravenous (IV) vitamin therapy delivers 100% bioavailability for immediate wellness, energy, and detoxification. Learn how our DHA nurses administer drips at your home.",
    content: `
## Why Oral Supplements Aren't Always Enough

When you take vitamin pills or wellness supplements orally, your digestive system and liver breakdown can degrade active compounds, resulting in only 20% to 30% biological absorption. 

**Intravenous (IV) Infusion Therapy** bypasses the gastrointestinal tract entirely, delivering 100% bioavailable micronutrients, minerals, and antioxidants straight into your bloodstream for instant cellular uptake.

### Popular IV Drip Cocktails in Dubai

- **The Myers Cocktail (Immunity & Vitality)**: High-dose Vitamin C, B-Complex (B1, B2, B3, B5, B6, B12), Magnesium, and Calcium to reboot your energy reserves.
- **Glutathione Glow & Detox**: Known as the body's master antioxidant, Glutathione helps neutralize free radicals, reduce oxidative stress, and brighten skin tone.
- **Hangover & Jet Lag Relief**: Electrolyte balanced saline, anti-nausea medication, Vitamin B12, and liver protection agents.
- **NAD+ Anti-Aging Infusions**: Cellular coenzyme that supports DNA repair, mitochondrial health, and mental sharpness.

### Is IV Drip Therapy Safe at Home?

Yes. At Hello Doctor, all IV therapy sessions are conducted under strict clinical supervision:
1. Pre-drip medical screening and vital signs measurement.
2. 100% sterile, single-use European pharmaceutical ingredients.
3. Continuous monitoring by DHA-licensed registered nurses throughout the 45-minute drip.

Experience premium at-home wellness today by booking your private IV drip session.
    `,
    authorDoctorId: "nurse-baso-bai",
    publishedDate: "2024-06-20",
    updatedDate: "2024-12-01",
    readingTimeMinutes: 6,
    categorySlug: "iv-therapy",
    categoryName: "IV Therapy & Wellness",
    tags: ["IV Drip Dubai", "Glutathione", "Vitamin Therapy", "Immunity Boost"],
    featuredImage: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "clinical-governance-home-healthcare-dubai",
    slug: "clinical-governance-home-healthcare-dubai",
    title: "Clinical Standards & Patient Safety in Dubai Home Healthcare",
    metaDescription: "How Hello Doctor maintains rigorous DHA clinical governance and emergency response standards across Dubai residences and hotels.",
    excerpt: "Medical Director Dr. Sukhwinder Kaur explains the strict clinical protocols, sterile procedures, and equipment standards that ensure hospital-grade care at home.",
    content: `
## Patient Safety as the Core Foundation

Under the supervision of Medical Director Dr. Sukhwinder Kaur, Hello Doctor adheres to the highest international clinical standards and Dubai Health Authority (DHA) regulations for home and hotel medical visits.

### How We Ensure Hospital-Grade Safety at Home

- **Strict Medication Controls**: All injectables and pharmaceuticals are stored in temperature-controlled medical containers and verified before administration.
- **Point-of-Care Diagnostics**: Our doctors carry calibrated digital ECGs, pulse oximeters, blood glucose monitors, and rapid biomarker testing kits.
- **Sterile Infection Prevention**: All disposable equipment is single-use, and all clinical protocols mirror acute outpatient hospital setups.
- **Electronic DHA Prescriptions**: Prescriptions are sent immediately to licensed UAE pharmacies for rapid courier delivery to your doorstep.
    `,
    authorDoctorId: "dr-sukhwinder-kaur",
    publishedDate: "2024-07-15",
    updatedDate: "2024-12-10",
    readingTimeMinutes: 4,
    categorySlug: "home-healthcare",
    categoryName: "Home Healthcare",
    tags: ["Medical Director", "DHA Standards", "Clinical Safety", "Doctor at Home"],
    featuredImage: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1200&auto=format&fit=crop",
  },
];

export function getPostBySlug(slug: string): BlogPost | undefined {
  return BLOG_POSTS.find((p) => p.slug === slug);
}
