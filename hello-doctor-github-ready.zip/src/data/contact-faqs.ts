export interface FAQItem {
  question: string;
  answer: string;
}

export const CONTACT_FAQS: FAQItem[] = [
  {
    question: "How fast does a doctor arrive after I contact you?",
    answer:
      "Our doctors are stationed strategically across central Dubai hubs (Downtown, Dubai Marina, Palm Jumeirah, Business Bay, JVC, and Al Barsha). On average, our DHA-licensed physician or nurse arrives at your residence or hotel within 30 to 45 minutes of booking.",
  },
  {
    question: "Can I book a doctor visit directly through WhatsApp?",
    answer:
      "Yes! Over 70% of our emergency dispatches are coordinated directly via WhatsApp. Simply message us with your location pin and chief symptoms, and our 24/7 medical desk will immediately confirm the nearest on-duty doctor and estimated arrival time.",
  },
  {
    question: "What details should I provide when contacting the dispatch team?",
    answer:
      "To ensure the fastest triage and dispatch, please provide: (1) Patient's name and approximate age, (2) Exact location, villa/apartment or hotel room number, (3) Key symptoms or required service (e.g. high fever, IV drip, earwax removal, lab test), and (4) Any known drug allergies.",
  },
  {
    question: "Do you provide official receipts for travel and private health insurance?",
    answer:
      "Yes, 100%. Following every consultation or treatment, we issue an official DHA medical report, itemized electronic invoice, and reimbursement claim form accepted by all major UAE and international insurance providers (such as Bupa, Allianz, AXA, Cigna, MetLife, and NextCare).",
  },
  {
    question: "Can your medical team visit hotel rooms and offices directly?",
    answer:
      "Yes. Our doctors and nurses frequently visit hotel guests across all Dubai resorts and hotels, coordinating with hotel concierges discreetly. We also visit corporate offices and residences with full portable diagnostic equipment.",
  },
];
