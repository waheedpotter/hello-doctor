import { MedicalService } from "@/types/service";

export const SERVICES: MedicalService[] = [
  // 1. Doctor on call Dubai
  {
    id: "doctor-on-call",
    slug: "doctor-on-call-dubai",
    title: "Doctor on call Dubai | 24/7 DHA Licensed GP Doctors in 30 Mins",
    h1: "24/7 Doctor on Call Dubai - Fast DHA Licensed Medical Care at Your Doorstep",
    shortTitle: "Doctor on call Dubai",
    category: "urgent-care",
    metaTitle: "Doctor on call Dubai | 24/7 On-Demand GP Doctor in 30-45 Mins",
    metaDescription: "Call a DHA licensed doctor on demand in Dubai 24/7. Immediate medical response dispatched to your location within 30-45 minutes. Complete physical checkup, treatment & digital prescription.",
    tagline: "Instant 24/7 Medical Dispatch & Doctor on Call Across All Dubai",
    heroBadge: "30-45 Mins Rapid Dispatch Across Dubai 24/7",
    priceStartingAtAed: 299,
    responseTimeMinutes: 30,
    availability: "24/7 Everyday & Public Holidays",
    dhaLicensed: true,
    iconName: "Stethoscope",
    featuredImage: "/images/doctor-on-call-dubai.webp",
    overview: "Hello Doctor's 24/7 Doctor on Call service delivers urgent, hospital-grade medical care straight to your doorstep anywhere in Dubai. When acute illness strikes day or night, skip crowded emergency waiting rooms and traffic. Our DHA-licensed General Practitioners and acute care doctors arrive in 30-45 minutes equipped with point-of-care diagnostics, vital monitoring gear, emergency medications, and the ability to issue official DHA digital prescriptions and sick leave certificates immediately.",
    whyChooseUs: [
      "Rapid Doorstep Dispatch: Arrives in 30-45 minutes across all Dubai areas",
      "100% DHA Licensed Doctors with emergency medicine and GP expertise",
      "On-Site Vitals, Diagnostic Tests (ECG, Blood Sugar, SpO2, Rapid Strep/Flu)",
      "Instant Electronic DHA Prescriptions & Official Sick Leave Certificates",
      "Direct dispensing of initial acute oral & injectable medications on-site",
      "Complete Insurance Claim Documents with itemized diagnostic invoices",
    ],
    symptomsTreated: [
      "High Sudden Fever, Flu, Severe Chills & COVID-19",
      "Acute Food Poisoning, Persistent Vomiting, Diarrhea & Dehydration",
      "Severe Migraines, Tension Headaches & Sinus Pain",
      "Respiratory Distress, Acute Bronchitis, Asthma & Coughing",
      "Intense Stomach Cramps, Acid Reflux & Gastroenteritis",
      "Allergic Reactions, Hives, Skin Rashes & Insect Bites",
      "Ear Infections, Swimmer's Ear & Severe Sore Throats",
      "Hypertension Spikes & Blood Pressure Management",
      "Musculoskeletal Sprains, Acute Back Pain & Joint Flare-ups",
      "Non-Emergency Pediatric & Family Health Conditions",
    ],
    priceOptions: [
      {
        name: "Standard GP Doctor on Call Visit",
        priceAed: 299,
        description: "Full clinical examination, vital check, symptom diagnosis, digital prescription & medical certificate.",
        popular: true,
      },
      {
        name: "Priority Night-Shift Doctor on Call (10 PM - 7 AM)",
        priceAed: 399,
        description: "Emergency overnight doctor dispatch for acute night fevers, pain crises, and urgent family illnesses.",
        badge: "24/7 Night Care",
      },
      {
        name: "Family Bundle Visit (Up to 3 Members)",
        priceAed: 599,
        description: "Comprehensive in-home consultation covering physical evaluations and prescriptions for up to 3 family members.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "24/7 Hotline or WhatsApp Triage",
        description: "Contact our 24/7 medical desk. Share your location and key symptoms for immediate clinical dispatch.",
        duration: "1-2 mins",
      },
      {
        stepNumber: 2,
        title: "Doctor Arrival & Examination",
        description: "The DHA physician arrives in 30-45 mins with mobile diagnostic equipment and evaluates your condition thoroughly.",
        duration: "30-45 mins travel",
      },
      {
        stepNumber: 3,
        title: "Immediate Treatment & E-Prescription",
        description: "Receive medications, injections if needed, and DHA-approved electronic prescriptions sent directly to your phone.",
        duration: "30-40 mins consultation",
      },
      {
        stepNumber: 4,
        title: "Follow-Up & Insurance Support",
        description: "Our clinical team follows up within 24 hours and provides full insurance reimbursement documentation.",
        duration: "Ongoing care",
      },
    ],
    includedEquipment: [
      "Digital Vital Signs Monitor (Blood Pressure, SpO2, Temperature)",
      "Portable 12-Lead ECG Machine",
      "Point-of-Care Blood Glucose & Ketone Analyzers",
      "Diagnostic Otoscope, Ophthalmoscope & Stethoscope",
      "Sterile Injection & First-Aid Wound Care Kit",
      "Emergency Oxygen & Nebulization Equipment",
    ],
    faqs: [
      {
        question: "How fast can a Doctor on Call reach my location in Dubai?",
        answer: "Our doctors are stationed strategically across central Dubai hubs (Downtown, Dubai Marina, Palm Jumeirah, JVC, Business Bay, and Al Barsha). On average, our doctor arrives within 30 to 45 minutes of your booking.",
      },
      {
        question: "Are your on-call doctors licensed by the Dubai Health Authority (DHA)?",
        answer: "Yes, 100% of our physicians hold active DHA medical licenses with extensive background in emergency and family medicine.",
      },
      {
        question: "Can the on-call doctor issue a DHA sick leave certificate?",
        answer: "Yes, our doctors generate certified DHA electronic sick leave certificates and digital prescriptions delivered instantly via SMS and email.",
      },
    ],
  },

  // 2. Doctor at Home Dubai
  {
    id: "doctor-at-home",
    slug: "doctor-at-home-dubai",
    title: "Doctor at Home Dubai | 24/7 In-Home GP & Specialist Consultations",
    h1: "DHA Licensed Doctor at Your Home, Villa, or Apartment in Dubai",
    shortTitle: "Doctor at Home Dubai",
    category: "urgent-care",
    metaTitle: "Doctor at Home Dubai | 24/7 In-Home GP Doctor Visits in 30 Mins",
    metaDescription: "Book a DHA licensed Doctor at Home in Dubai 24/7. Our doctors reach your home, villa, or apartment within 30-45 minutes. Complete physical checkup, prescription & medication on-site.",
    tagline: "Quality Medical Care in the Comfort, Privacy, and Safety of Your Home",
    heroBadge: "30-45 Mins Fast Doorstep Arrival Across Dubai",
    priceStartingAtAed: 299,
    responseTimeMinutes: 35,
    availability: "24/7 Everyday & Public Holidays",
    dhaLicensed: true,
    iconName: "Stethoscope",
    featuredImage: "/images/doctor-at-home-dubai.webp",
    overview: "Our 24/7 Doctor at Home service brings DHA-licensed general practitioners and emergency-trained physicians directly to your residence in Dubai. Avoid traffic, parking hassles, long hospital waiting rooms, and exposure to contagious clinic environments. Our doctors carry advanced diagnostic tools, vital monitoring gear, point-of-care test kits, and essential medications to treat you immediately in your living room or bedroom.",
    whyChooseUs: [
      "Rapid Response: Doctor arrives in 30-45 minutes anywhere in Dubai",
      "100% DHA Licensed General Practitioners and Specialists",
      "Full On-Site Medical Diagnosis & Electronic DHA Prescriptions",
      "Immediate Dispensing of Essential Acute Medications",
      "Direct Coordination for Lab Tests, IV Therapy, or Hospital Transfer if needed",
      "Insurance Reimbursement Support with Itemized Medical Reports",
    ],
    symptomsTreated: [
      "High Fever, Chills, Flu, Cold & COVID-19",
      "Severe Migraines & Acute Headaches",
      "Food Poisoning, Vomiting, Diarrhea & Dehydration",
      "Acute Asthma, Bronchitis & Respiratory Distress",
      "Stomach Pain, Acidity & Gastritis",
      "Allergic Reactions, Skin Rashes & Hives",
      "Back Pain, Joint Sprains & Musculoskeletal Aches",
      "Ear Infections, Sore Throat & Tonsillitis",
      "Hypertension Spikes & Blood Pressure Monitoring",
      "Pediatric Illnesses & Non-Emergency Pediatric Fevers",
    ],
    priceOptions: [
      {
        name: "Standard GP Home Consultation",
        priceAed: 299,
        description: "Full clinical examination, vital signs, symptom diagnosis, digital prescription & medical certificate.",
        popular: true,
      },
      {
        name: "Urgent Night / After-Hours Visit",
        priceAed: 399,
        description: "Priority night-shift dispatch (10 PM - 7 AM) for acute nocturnal illnesses and fever spikes.",
        badge: "24/7 Priority",
      },
      {
        name: "Family Bundle (Up to 3 Members)",
        priceAed: 599,
        description: "Comprehensive home visit covering checkups and prescriptions for up to 3 family members in the same residence.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Instant Booking & Triage",
        description: "Call or WhatsApp our 24/7 medical desk. Share your address and chief symptoms for immediate doctor dispatch.",
        duration: "2-3 mins",
      },
      {
        stepNumber: 2,
        title: "Doctor Arrival & Comprehensive Exam",
        description: "The DHA physician arrives at your home with diagnostic gear, checks vitals (BP, SpO2, ECG, Sugar), and performs physical evaluation.",
        duration: "30-45 mins travel",
      },
      {
        stepNumber: 3,
        title: "Immediate Treatment & Prescription",
        description: "Receive instant medication, injections if clinically indicated, digital DHA e-prescriptions, and sick leaves directly on your phone.",
        duration: "30-40 mins consultation",
      },
      {
        stepNumber: 4,
        title: "Post-Visit Follow-Up",
        description: "Our medical team follows up within 24 hours to track your recovery and provides full insurance reimbursement documentation.",
        duration: "Ongoing care",
      },
    ],
    includedEquipment: [
      "Digital Vital Signs Monitor (BP, Pulse Oximeter, Thermometer)",
      "Portable 12-Lead ECG Machine",
      "Rapid Blood Glucose & Ketone Meters",
      "Emergency Nebulizer & Oxygen Saturation Kit",
      "Diagnostic Otoscope & Ophthalmoscope",
      "Sterile Wound Care & First-Aid Dressing Kits",
    ],
    faqs: [
      {
        question: "How fast can a doctor arrive at my home in Dubai?",
        answer: "On average, our DHA doctor arrives at your doorstep within 30 to 45 minutes of booking anywhere in Dubai.",
      },
      {
        question: "Can I claim insurance reimbursement for doctor home visits?",
        answer: "Yes. We provide complete DHA medical reports, itemized invoices, and claim forms for insurance reimbursement with UAE and global insurers.",
      },
    ],
  },

  // 3. Doctor at Hotel Dubai
  {
    id: "doctor-at-hotel",
    slug: "doctor-at-hotel-dubai",
    title: "Doctor at Hotel Dubai | 24/7 Urgent In-Room Doctor Consultations",
    h1: "24/7 Doctor at Hotel Dubai - Urgent In-Room Medical Care in 30-45 Mins",
    shortTitle: "Doctor at Hotel Dubai",
    category: "urgent-care",
    metaTitle: "Doctor at Hotel Dubai | 24/7 In-Room Doctor Visits in 30 Mins",
    metaDescription: "Urgent 24/7 doctor at hotel in Dubai. Fast in-room visits to all Dubai hotels, resorts & Airbnb suites in 30-45 mins. On-site diagnosis, medication, fit-to-fly & travel insurance receipts.",
    tagline: "Don't Let Sickness Ruin Your Dubai Holiday or Business Trip - Doctor to Your Hotel Room",
    heroBadge: "Fast 30-45 Mins Arrival to Any Dubai Hotel Room or Resort",
    priceStartingAtAed: 349,
    responseTimeMinutes: 30,
    availability: "24/7 Immediate In-Room Dispatch",
    dhaLicensed: true,
    iconName: "Hotel",
    featuredImage: "/images/doctor-at-hotel-dubai.webp",
    overview: "Falling ill while on vacation or a business trip in Dubai can be stressful. Hello Doctor provides discreet, rapid 24/7 in-room doctor visits across all 5-star hotels, beach resorts, and luxury suites in Dubai. Our multilingual DHA-licensed physicians treat food poisoning, heat exhaustion, dehydration, flight fatigue, sudden fevers, migraines, and ear pain directly in your room, dispensing medications on-site and providing official Fit-to-Fly certificates and travel insurance claim forms.",
    whyChooseUs: [
      "Rapid 30-45 Minute Dispatch to all Dubai Hotels, Resorts & Airbnb Suites",
      "Multilingual Doctors fluent in English, Arabic, Russian, French, Hindi, and Urdu",
      "On-Site Medication Dispensing & Electronic Fit-to-Fly Clearance Certificates",
      "Direct Billing Documentation & Invoices for International Travel Insurance",
      "Discreet and comfortable hotel room consultations coordinated with concierge",
    ],
    symptomsTreated: [
      "Traveler's Diarrhea, Food Poisoning, Vomiting & Acute Nausea",
      "Heat Exhaustion, Sunstroke & Severe Dehydration",
      "Sudden Fever Spikes, Throat Pain & Swimmer's Ear Infections",
      "Severe Flight Jet Lag, Insomnia & Migraines",
      "Emergency Prescription Refills for Lost Travel Medications",
      "Minor Scrapes, Sprains & Water Sports Injuries",
      "Official Fit-to-Fly Medical Clearance & Travel Documentation",
    ],
    priceOptions: [
      {
        name: "Standard Hotel Room Doctor Visit",
        priceAed: 349,
        description: "Direct hotel room consultation, physical exam, vitals check, prescription & fit-to-fly certificate.",
        popular: true,
      },
      {
        name: "Hotel Urgent IV Hydration + Doctor Combo",
        priceAed: 649,
        description: "Doctor consultation plus urgent IV hydration drip for rapid recovery from severe food poisoning or dehydration.",
        badge: "Fastest Recovery",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Call or WhatsApp from Your Hotel Room",
        description: "Share your hotel name, room number, and symptoms. Our medical desk coordinates arrival seamlessly.",
        duration: "2 mins",
      },
      {
        stepNumber: 2,
        title: "Doctor Arrives at Your Hotel Room",
        description: "Physician arrives within 30-45 minutes with full diagnostic kit and medical supplies.",
        duration: "30-45 mins",
      },
      {
        stepNumber: 3,
        title: "In-Room Treatment & Travel Documentation",
        description: "Immediate treatment administered, medications supplied, and insurance invoice provided.",
        duration: "30 mins",
      },
    ],
    includedEquipment: [
      "Traveler's Urgent Diagnostic Kit",
      "Immediate Relief Injectables & Oral Medication",
      "Blood Pressure, ECG & Glucose Monitors",
    ],
    faqs: [
      {
        question: "Can the doctor come straight to my hotel room in Dubai?",
        answer: "Yes, our licensed doctors visit your hotel room directly. We coordinate entry with the hotel concierge or reception discreetly.",
      },
      {
        question: "Will my international travel insurance cover the hotel doctor visit?",
        answer: "Yes, we provide itemized international medical claim forms and receipts accepted by Allianz, AXA, Bupa, Cigna, and all major global travel insurers.",
      },
    ],
  },

  // 4. IV Drip Therapy at Home Dubai
  {
    id: "iv-drip-therapy",
    slug: "iv-drip-therapy-dubai",
    title: "IV Drip Therapy at Home Dubai | Vitamin & Hydration Infusions",
    h1: "Premium Vitamin IV Drip Infusions at Home in Dubai",
    shortTitle: "IV Drip Therapy at Home Dubai",
    category: "wellness",
    metaTitle: "IV Drip Therapy at Home Dubai | Vitamin IV Infusions & Hydration",
    metaDescription: "Experience rejuvenating IV Drip Therapy at home in Dubai. Immune boost, NAD+, hangover relief, glutathione skin glow, and energy drips administered by DHA registered nurses.",
    tagline: "100% Bioavailable Vitamin & Micronutrient Infusions at Your Doorstep",
    heroBadge: "Administered by DHA Certified Nurses in 30-45 Mins",
    priceStartingAtAed: 349,
    responseTimeMinutes: 30,
    availability: "24/7 Service Across All Dubai",
    dhaLicensed: true,
    iconName: "Droplet",
    featuredImage: "/images/iv-drip-therapy-dubai.webp",
    overview: "Revitalize your body with bespoke intravenous (IV) vitamin therapy in the comfort of your living room, hotel suite, or office in Dubai. Our pharmaceutical-grade IV cocktails deliver essential vitamins, minerals, antioxidants, and electrolytes directly into your bloodstream with 100% absorption, bypassing the digestive tract for rapid wellness, energy, hydration, and immunity restoration.",
    whyChooseUs: [
      "Custom Formulated IV Cocktails for Every Health Need",
      "Administered exclusively by experienced DHA Registered Nurses",
      "Medical assessment & vital check prior to every drip",
      "Premium European & US imported pharmaceutical-grade vitamins",
      "Available 24/7 across all residential and hotel areas in Dubai",
      "Comfortable, painless intravenous cannulation protocols",
    ],
    symptomsTreated: [
      "Dehydration, Fatigue & Low Energy Levels",
      "Severe Hangover & Food Poisoning Recovery",
      "Weak Immune System & Frequent Colds",
      "Jet Lag, Brain Fog & Sleep Disturbances",
      "Dull Skin, Hyperpigmentation & Collagen Depletion",
      "Athletic Exhaustion & Post-Workout Muscle Soreness",
      "Post-Illness & Post-Viral Exhaustion",
    ],
    priceOptions: [
      {
        name: "Immunity Boost & Vitamin C Drip",
        priceAed: 349,
        description: "High-dose Vitamin C, Zinc, B-Complex, and powerful antioxidants to strengthen defenses.",
        popular: true,
      },
      {
        name: "Hangover Recovery & Rapid Hydration",
        priceAed: 399,
        description: "Electrolytes, anti-nausea, liver detoxifying glutathione, and B-vitamins for instant revival.",
        badge: "Top Seller",
      },
      {
        name: "Glutathione Radiance & Glow Drip",
        priceAed: 449,
        description: "Master antioxidant Glutathione combined with Ascorbic Acid for cellular rejuvenation and glowing skin.",
      },
      {
        name: "NAD+ Anti-Aging & Cellular Repair (100mg)",
        priceAed: 799,
        description: "Cutting-edge Nicotinamide Adenine Dinucleotide to restore cellular vitality, mental clarity & longevity.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Medical Consultation & Vitals",
        description: "Our DHA nurse checks your blood pressure, heart rate, oxygen levels, and medical history to confirm suitability.",
        duration: "5-10 mins",
      },
      {
        stepNumber: 2,
        title: "Gentle Cannulation",
        description: "Using ultra-fine sterile needles, a gentle IV catheter is placed painlessly into your vein.",
        duration: "2 mins",
      },
      {
        stepNumber: 3,
        title: "Relax & Infuse",
        description: "Sit back on your sofa or bed while the 500ml or 1000ml infusion flows smoothly into your system.",
        duration: "35-50 mins",
      },
      {
        stepNumber: 4,
        title: "Post-Drip Monitoring",
        description: "Nurse removes catheter, applies sterile dressing, rechecks vitals, and ensures you feel energized.",
        duration: "5 mins",
      },
    ],
    includedEquipment: [
      "Sterile IV Infusion Sets & IV Stands",
      "Pharmaceutical Grade Micronutrient Ampoules",
      "Lactated Ringer's / Normal Saline 500-1000ml",
      "Sterile Cannulas (22G/24G painless micro-tips)",
      "Digital Blood Pressure & Oxygen Monitors",
    ],
    faqs: [
      {
        question: "How long does an IV Drip session take at home?",
        answer: "A standard IV drip session takes approximately 40 to 60 minutes from nurse arrival, vital signs screening, and infusion completion.",
      },
      {
        question: "Is IV Drip therapy safe?",
        answer: "Yes, all our IV drips use pharmaceutical-grade ingredients and are administered strictly by DHA-licensed nurses following rigorous clinical safety guidelines.",
      },
    ],
  },

  // 5. Lab Test at Home Dubai
  {
    id: "lab-test-at-home",
    slug: "lab-test-at-home-dubai",
    title: "Lab Test at Home Dubai | Blood Tests & Sample Collection in 30 Mins",
    h1: "Convenient Lab Test at Home Dubai - Fast DHA Accredited Reports",
    shortTitle: "Lab Test at Home Dubai",
    category: "diagnostics",
    metaTitle: "Lab Test at Home Dubai | Blood Sample Collection & Fast Reports",
    metaDescription: "Order lab and blood tests at home in Dubai. DHA accredited lab testing, painless phlebotomy sample collection at your door. Fast digital reports in 12-24 hours.",
    tagline: "Accredited Lab Diagnostic Profiles & Blood Tests Delivered to Your Email",
    heroBadge: "DHA Accredited Laboratory Reports Within 12-24 Hours",
    priceStartingAtAed: 199,
    responseTimeMinutes: 30,
    availability: "7:00 AM - 11:00 PM Everyday",
    dhaLicensed: true,
    iconName: "FlaskConical",
    featuredImage: "/images/lab-test-at-home-dubai.webp",
    overview: "Skip clinic queues and fasting traffic. Our DHA-certified phlebotomists come to your home, office, or hotel in Dubai to collect blood, urine, or swab samples with maximum precision and gentle care. All samples are processed in state-of-the-art DHA-accredited laboratories, with verified digital test reports delivered directly to your WhatsApp and email within 12 to 24 hours.",
    whyChooseUs: [
      "Painless Blood Draw by Licensed Phlebotomists",
      "Over 500+ Diagnostic Tests & Comprehensive Health Packages",
      "DHA-Accredited Pathology Laboratory Processing",
      "Same-Day / Next-Day Digital Reports with Doctor Review",
      "Comfortable At-Home Fasting Blood Collection",
    ],
    symptomsTreated: [
      "Complete Blood Count (CBC) & ESR",
      "Comprehensive Lipid Profile & Heart Health",
      "Liver Function Tests (LFT) & Kidney Function Tests (KFT)",
      "Thyroid Profile (TSH, Free T3, Free T4)",
      "Vitamin D3, Vitamin B12 & Ferritin / Iron Levels",
      "HbA1c & Fasting Blood Sugar Monitoring",
      "Food Allergy & Intolerance Panels",
      "Hormone & Fertility Screenings",
    ],
    priceOptions: [
      {
        name: "Essential Health Check (18 Parameters)",
        priceAed: 249,
        description: "CBC, Fasting Blood Sugar, Lipid Profile, Liver & Kidney screening.",
        popular: true,
      },
      {
        name: "Comprehensive Executive Wellness (42 Parameters)",
        priceAed: 599,
        description: "Includes Vitamin D3, B12, Thyroid, Full Metabolic Panel, Iron, and GP Review.",
        badge: "Most Popular",
      },
      {
        name: "Food Allergy & Sensitivity (100+ Food Items)",
        priceAed: 899,
        description: "Detailed IgE/IgG antibodies screening for food intolerances.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Select Test Package & Time",
        description: "Choose your required lab package or upload your doctor's test requisition slip.",
        duration: "2 mins",
      },
      {
        stepNumber: 2,
        title: "At-Home Sample Collection",
        description: "Licensed phlebotomist collects blood/urine sample using vacutainer tubes and strict barcode tracking.",
        duration: "10-15 mins",
      },
      {
        stepNumber: 3,
        title: "DHA Lab Analysis & Digital Report",
        description: "Samples are transported in temperature-controlled coolboxes and analyzed. Digital PDF reports sent via WhatsApp/Email.",
        duration: "12-24 hours",
      },
    ],
    includedEquipment: [
      "Sterile Vacutainer Phlebotomy Tubes",
      "Temperature-Controlled Sample Transport Carrier",
      "Sterile Butterfly Needles for Painless Draws",
    ],
    faqs: [
      {
        question: "Do I need to fast before my at-home blood test?",
        answer: "For tests like Lipid Profile, Fasting Blood Glucose, and Comprehensive Wellness, 8 to 10 hours of overnight fasting is recommended. Water is permitted.",
      },
      {
        question: "How will I receive my laboratory test results?",
        answer: "Your verified lab reports are emailed and messaged on WhatsApp in secure PDF format as soon as testing is complete.",
      },
    ],
  },

  // 6. Physiotherapy at Home Dubai
  {
    id: "physiotherapy-at-home",
    slug: "physiotherapy-at-home-dubai",
    title: "Physiotherapy at Home Dubai | Licensed Physical Therapists",
    h1: "Expert Physiotherapy at Home Dubai - Personalized Rehabilitation",
    shortTitle: "Physiotherapy at Home Dubai",
    category: "therapy",
    metaTitle: "Physiotherapy at Home Dubai | DHA Licensed Physical Rehab",
    metaDescription: "Book DHA licensed physiotherapists in Dubai for home rehabilitation. Post-surgery rehab, back pain, sports injuries, neurological care & mobility restoration.",
    tagline: "Restore Mobility and Relieve Pain in the Comfort of Your Own Home",
    heroBadge: "DHA Licensed Physical Therapists with Portable Equipment",
    priceStartingAtAed: 349,
    responseTimeMinutes: 45,
    availability: "8:00 AM - 9:00 PM Daily",
    dhaLicensed: true,
    iconName: "Activity",
    featuredImage: "/images/physiotherapy-at-home-dubai.webp",
    overview: "Regain strength, mobility, and freedom from pain with personalized home physiotherapy in Dubai. Our DHA-licensed physiotherapists bring professional rehab equipment directly to your living space, designing tailored recovery programs for orthopedic surgery recovery, chronic back and neck pain, sports injuries, stroke rehabilitation, and elderly fall prevention.",
    whyChooseUs: [
      "DHA Licensed Senior Physical Therapists",
      "One-on-One Dedicated 60-Minute Clinical Sessions",
      "Portable Modalities (TENS, Ultrasound, Muscle Stimulators)",
      "Personalized Exercise Therapy & Posture Correction",
      "Eliminate stressful clinic travel and parking hassles",
    ],
    symptomsTreated: [
      "Lower Back Pain, Sciatica & Slip Disc Rehabilitation",
      "Neck Stiffness, Cervical Spondylosis & Poor Posture",
      "Post-Operative Orthopedic Rehab (Knee/Hip Replacement, ACL)",
      "Sports Injuries, Tendonitis & Muscle Tears",
      "Stroke Recovery & Neurological Rehabilitation",
      "Geriatric Mobility, Balance & Fall Prevention",
      "Frozen Shoulder & Joint Arthritis Management",
    ],
    priceOptions: [
      {
        name: "Initial Assessment & Treatment (60 Mins)",
        priceAed: 349,
        description: "Comprehensive musculoskeletal assessment, pain relief therapy, and personalized recovery plan.",
        popular: true,
      },
      {
        name: "5-Session Rehabilitation Package",
        priceAed: 1599,
        description: "Structured 5-visit recovery protocol for post-surgery or persistent chronic injury.",
        badge: "Save 15%",
      },
      {
        name: "10-Session Intensive Mobility Package",
        priceAed: 2999,
        description: "Complete rehabilitation program with weekly progress tracking and home exercise manual.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Clinical Mobility Assessment",
        description: "Evaluation of range of motion, muscle strength, joint flexibility, and pain triggers.",
        duration: "15 mins",
      },
      {
        stepNumber: 2,
        title: "Hands-on Therapy & Modalities",
        description: "Manual joint mobilization, myofascial release, therapeutic ultrasound, or electrotherapy.",
        duration: "30 mins",
      },
      {
        stepNumber: 3,
        title: "Guided Therapeutic Exercises",
        description: "Active guided rehabilitation exercises and education on ergonomic posture.",
        duration: "15 mins",
      },
    ],
    includedEquipment: [
      "Portable TENS & Electrical Muscle Stimulation (EMS) Units",
      "Therapeutic Ultrasound Machine",
      "Resistance Bands, Foam Rollers & Balance Pads",
      "Goniometers & Inclinometers for Precision Tracking",
    ],
    faqs: [
      {
        question: "Do I need a doctor's referral for physiotherapy at home?",
        answer: "A referral is helpful if you have recent surgical notes or X-rays, but our DHA physiotherapists can also perform direct assessments and treatments.",
      },
    ],
  },

  // 7. Home Nursing Dubai
  {
    id: "home-nursing",
    slug: "home-nursing-dubai",
    title: "Home Nursing Dubai | 24/7 DHA Licensed Private Nurses",
    h1: "Professional 24/7 DHA Home Nursing Services in Dubai",
    shortTitle: "Home Nursing Dubai",
    category: "nursing",
    metaTitle: "Home Nursing Dubai | 24/7 DHA Licensed Private Home Nurses",
    metaDescription: "Hire qualified DHA registered home nurses in Dubai. Post-operative wound dressing, elderly nursing, injection administration, catheter care & 12/24 hour bedside shifts.",
    tagline: "Compassionate, Hospital-Grade Nursing in Your Home Environment",
    heroBadge: "DHA Licensed Male & Female Nurses Available 24/7",
    priceStartingAtAed: 199,
    responseTimeMinutes: 30,
    availability: "Hourly, 12h Shift, 24h Full-Time & Urgent Visits",
    dhaLicensed: true,
    iconName: "HeartPulse",
    featuredImage: "/images/home-nursing-dubai.webp",
    overview: "Hello Doctor provides highly experienced, DHA-licensed male and female registered nurses for private home healthcare across Dubai. Whether you need an urgent on-demand nurse visit for intramuscular injections and surgical wound dressings, or dedicated 12-hour / 24-hour shifts for elderly support, chronic illness monitoring, or post-surgery recovery, our team guarantees exceptional clinical standards.",
    whyChooseUs: [
      "DHA Certified Registered Nurses with Intensive Care & Hospital Backgrounds",
      "Flexible Plans: Per-visit, 12-hour shifts, 24/7 live-in nursing",
      "Rigorous Infection Control & Sterile Medical Protocols",
      "Medication Management, Injections, IV Infusions & Vital Tracking",
      "Seamless communication with treating doctors and family members",
    ],
    symptomsTreated: [
      "Post-Surgical Wound Dressing & Suture/Staple Removal",
      "Urinary Catheter Insertion, Care & Removal",
      "IV / IM / Subcutaneous Medication Administration",
      "Tracheostomy & Stoma Care Management",
      "Diabetic Blood Sugar Control & Insulin Delivery",
      "Palliative Care & Chronic Pain Support",
      "Vital Signs & Bedside Patient Assistance",
    ],
    priceOptions: [
      {
        name: "Single Nursing Visit (Up to 1 Hour)",
        priceAed: 199,
        description: "Wound dressing, injections, vital check, or catheter management.",
        popular: true,
      },
      {
        name: "12-Hour Day / Night Shift",
        priceAed: 799,
        description: "Continuous 12-hour dedicated bedside clinical nursing care.",
      },
      {
        name: "24-Hour Continuous Care Shift",
        priceAed: 1450,
        description: "Full day-and-night professional nursing supervision with dedicated shifts.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Clinical Need Assessment",
        description: "We review the patient's medical history, doctor's discharge summary, and required nursing interventions.",
        duration: "5 mins",
      },
      {
        stepNumber: 2,
        title: "Nurse Matching & Dispatch",
        description: "A DHA registered nurse specializing in the specific condition is assigned and dispatched with sterile supplies.",
        duration: "30-45 mins",
      },
      {
        stepNumber: 3,
        title: "Professional Nursing Care",
        description: "Execution of prescribed medical procedures with sterile techniques, recording vitals and daily progress charts.",
        duration: "Per schedule",
      },
    ],
    includedEquipment: [
      "Sterile Surgical Dressing Kits",
      "Medical Injections & Syringes",
      "Foley Catheter Kits & Drainage Bags",
      "Digital Vital Signs Monitors",
    ],
    faqs: [
      {
        question: "Can I request a female or male nurse specifically?",
        answer: "Yes, we accommodate all gender preferences for your comfort and cultural requirements. Both female and male DHA-registered nurses are available around the clock.",
      },
      {
        question: "Do your nurses administer IV antibiotics or prescription injections at home?",
        answer: "Yes, our nurses can administer doctor-prescribed intramuscular (IM), subcutaneous, and intravenous (IV) medications with valid physician orders.",
      },
    ],
  },

  // 8. Baby care at home Dubai
  {
    id: "baby-care",
    slug: "baby-care-at-home-dubai",
    title: "Baby care at home Dubai | Newborn & Pediatric Nursing Support",
    h1: "24/7 DHA Certified Baby Care & Pediatric Nursing at Home in Dubai",
    shortTitle: "Baby care at home Dubai",
    category: "family-care",
    metaTitle: "Baby care at home Dubai | Newborn Care & Pediatric Nurse Visits",
    metaDescription: "Professional baby care at home in Dubai. DHA licensed neonatal & pediatric nurses for newborn support, night nursing, milestone checks, and infant wellness.",
    tagline: "Gentle, Certified, and Loving In-Home Care for Newborns and Infants",
    heroBadge: "DHA Licensed Pediatric & Neonatal Home Nurses",
    priceStartingAtAed: 249,
    responseTimeMinutes: 30,
    availability: "Day Shifts, Night Nursing & 24/7 Full Support",
    dhaLicensed: true,
    iconName: "HeartPulse",
    featuredImage: "/images/baby-care-at-home-dubai.webp",
    overview: "Welcoming a newborn is a joyous yet demanding journey. Hello Doctor provides compassionate, DHA-certified neonatal and pediatric nurses directly to your home in Dubai. From post-natal mother support and umbilical cord care to overnight baby soothing, infant feeding guidance, milestone tracking, and acute pediatric fever checks, our gentle nurses ensure your little one thrives in a safe, nurturing environment.",
    whyChooseUs: [
      "DHA Licensed Pediatric & Neonatal Registered Nurses",
      "Flexible Night-Nurse Shifts so parents can get restorative sleep",
      "Umbilical Cord Care, Jaundice Monitoring & Infant Bathing Support",
      "Lactation & Bottle Feeding Assistance with Weight Tracking",
      "Gentle temperature, respiratory, and pediatric vitals monitoring",
    ],
    symptomsTreated: [
      "Newborn Jaundice & Bilirubin Level Tracking",
      "Infant Colic, Reflux & Digestion Discomfort",
      "Pediatric Fevers, Cough, Congestion & Teething Troubles",
      "Post-Natal Care & New Mother Recovery Support",
      "Premature Infant Bedside Nursing & Vital Signs Oversight",
      "Sleep Schedule Conditioning & Gentle Bedtime Routine Support",
    ],
    priceOptions: [
      {
        name: "Single Baby Health & Nurse Visit (2 Hours)",
        priceAed: 299,
        description: "Infant vitals screening, weight check, umbilical cord care, and maternal guidance.",
        popular: true,
      },
      {
        name: "10-Hour Overnight Baby Nurse Shift",
        priceAed: 699,
        description: "Dedicated night nurse supervision (9 PM - 7 AM) for feeding, burping, soothing, and safe infant sleep.",
        badge: "Parent Favorite",
      },
      {
        name: "Weekly Newborn Nurture Package (7 Night Shifts)",
        priceAed: 4499,
        description: "Full week of dedicated overnight pediatric nursing care and daytime lactation support.",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Infant Care Consultation",
        description: "Discussing your baby's age, medical history, feeding schedule, and sleep routines.",
        duration: "5 mins",
      },
      {
        stepNumber: 2,
        title: "Pediatric Nurse Arrival",
        description: "DHA pediatric nurse arrives with sterile equipment and gentle baby-safe monitoring tools.",
        duration: "30-45 mins",
      },
      {
        stepNumber: 3,
        title: "Loving Clinical Baby Care",
        description: "Executing newborn routines, soothing, feeding support, and logging daily health milestones.",
        duration: "Per shift",
      },
    ],
    includedEquipment: [
      "Pediatric Pulse Oximeters & Digital Infant Thermometers",
      "Sterile Baby Feeding & Sanitization Supplies",
      "Infant Weight & Growth Tracking Tools",
    ],
    faqs: [
      {
        question: "Are your baby care nurses DHA-licensed and trained in newborn care?",
        answer: "Yes, all our infant care specialists are DHA-registered nurses with specialized hospital and neonatal/pediatric intensive care backgrounds.",
      },
      {
        question: "Can I book an overnight nurse for night feedings and baby soothing?",
        answer: "Yes! Our overnight baby nursing shifts (typically 10 hours, e.g. 9 PM to 7 AM) allow new parents to rest while their baby receives certified medical supervision.",
      },
    ],
  },

  // 9. Elderly Care at home Dubai
  {
    id: "elderly-care",
    slug: "elderly-care-at-home-dubai",
    title: "Elderly Care at home Dubai | Senior Medical & Bedside Nursing",
    h1: "Compassionate Elderly Care at Home in Dubai - DHA Licensed Clinicians",
    shortTitle: "Elderly Care at home Dubai",
    category: "family-care",
    metaTitle: "Elderly Care at home Dubai | 24/7 Senior Healthcare & Home Nurses",
    metaDescription: "Dedicated elderly home care in Dubai. DHA licensed medical doctors and geriatric nurses providing vital monitoring, medication administration, and chronic illness care.",
    tagline: "Dignified, Loving, and Hospital-Grade Support for Seniors in Their Own Home",
    heroBadge: "Specialized Geriatric Care by DHA Licensed Clinicians",
    priceStartingAtAed: 299,
    responseTimeMinutes: 35,
    availability: "24/7 Flexible Senior Care Plans",
    dhaLicensed: true,
    iconName: "ShieldCheck",
    featuredImage: "/images/elderly-care-at-home-dubai.webp",
    overview: "Ensure your aging loved ones receive first-class, dignified medical and nursing care in the comfort of their Dubai residence. Our multidisciplinary geriatric care team combines regular doctor visits, skilled home nursing, medication management, physical mobility assistance, and 24/7 urgent medical on-call coverage tailored for seniors.",
    whyChooseUs: [
      "Geriatric Trained Doctors & Compassionate Nurses",
      "Preventive Health Screenings & Chronic Disease Management",
      "Medication Adherence & Daily Vitals Tracking",
      "Fall Prevention & Assisted Mobility Support",
      "Regular Digital Updates & Peace of Mind for Family Members",
    ],
    symptomsTreated: [
      "Hypertension, Diabetes & Cardiovascular Monitoring",
      "Dementia & Alzheimer's Supportive Care",
      "Parkinson's Disease Mobility Management",
      "Bedbound Patient Care & Pressure Ulcer Prevention",
      "Post-Hospitalization Convalescence",
      "Nutritional Support & Hydration Management",
    ],
    priceOptions: [
      {
        name: "Doctor Geriatric Assessment Visit",
        priceAed: 349,
        description: "Full senior health check, prescription audit, and care plan creation.",
        popular: true,
      },
      {
        name: "Monthly Senior Care Package (Weekly Visits)",
        priceAed: 1899,
        description: "4 weekly doctor/nurse checkups, monthly blood tests, and 24/7 hotline access.",
        badge: "Best Value",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Comprehensive Senior Evaluation",
        description: "Evaluating physical health, cognitive baseline, medications, and home environment safety.",
        duration: "45 mins",
      },
      {
        stepNumber: 2,
        title: "Custom Care Plan Implementation",
        description: "Scheduling doctor visits, nurse shifts, blood work, and physical therapy sessions.",
        duration: "Ongoing",
      },
    ],
    includedEquipment: [
      "Advanced Geriatric Monitoring Equipment",
      "Anti-Decubitus Mattress Support Guidance",
      "Oxygen Saturation & Blood Glucose Trackers",
    ],
    faqs: [
      {
        question: "Can your team assist with Alzheimer's or dementia patients at home?",
        answer: "Yes, our nurses and doctors are trained in compassionate dementia management, maintaining calm routines and preventing agitation.",
      },
    ],
  },

  // 10. Earwax Removal at Home Dubai
  {
    id: "earwax-removal",
    slug: "earwax-removal-at-home-dubai",
    title: "Earwax Removal at Home Dubai | Safe Microsuction & Irrigation",
    h1: "Professional Earwax Removal at Home in Dubai - Safe, Painless & Fast",
    shortTitle: "Earwax Removal at Home Dubai",
    category: "urgent-care",
    metaTitle: "Earwax Removal at Home Dubai | Painless Microsuction & Syringing",
    metaDescription: "Safe earwax removal at home in Dubai. DHA licensed doctors and nurses providing painless ear microsuction, gentle irrigation, and instant hearing relief in 30-45 mins.",
    tagline: "Instant Hearing Clarity and Relief from Ear Blockages in Your Living Room",
    heroBadge: "DHA Licensed Doctors with Portable Video Otoscopy & Microsuction",
    priceStartingAtAed: 299,
    responseTimeMinutes: 30,
    availability: "24/7 Everyday Across All Dubai",
    dhaLicensed: true,
    iconName: "Stethoscope",
    featuredImage: "/images/earwax-removal-at-home-dubai.webp",
    overview: "Blocked ears, sudden muffled hearing, itching, tinnitus, or ear discomfort? Hello Doctor brings safe, hospital-grade earwax removal directly to your residence or hotel room in Dubai. Our DHA-licensed medical practitioners use advanced high-definition video otoscopy, gentle warm water irrigation, and precise portable microsuction to clear stubborn earwax impactions painlessly and immediately restore crisp hearing clarity.",
    whyChooseUs: [
      "100% DHA Licensed Medical Doctors & Registered Practitioners",
      "HD Video Otoscope Examination: See inside your ear canal before & after on screen",
      "Safe, Gold-Standard Microsuction & Gentle Temperature-Controlled Irrigation",
      "Painless, fast 20-30 minute procedure with immediate hearing restoration",
      "Suitable for adults, seniors with hearing aids, and children (6+ years)",
      "Available 24/7 with rapid 30-45 minute doorstep arrival anywhere in Dubai",
    ],
    symptomsTreated: [
      "Sudden Muffled or Diminished Hearing",
      "Sensation of Fullness, Pressure or Blockage in the Ear Canal",
      "Ringing, Buzzing, or Hissing Sounds in the Ear (Tinnitus from Wax Impaction)",
      "Persistent Ear Itching, Odor, or Dry Flaky Wax Accumulation",
      "Swimmer's Ear Discomfort & Water Trapped Behind Impacted Cerumen",
      "Feedback Whistling & Poor Performance in Hearing Aids",
      "Ear Pain & Dizziness Caused by Deep Impacted Wax Plugs",
    ],
    priceOptions: [
      {
        name: "Single Ear Microsuction & Wax Removal",
        priceAed: 299,
        description: "Full video otoscopy exam, gentle wax extraction, and tympanic membrane health check for one ear.",
      },
      {
        name: "Both Ears Complete Wax Removal (Bilateral)",
        priceAed: 449,
        description: "Comprehensive dual-ear video inspection, deep wax clearing, and ear canal soothing drops.",
        popular: true,
      },
      {
        name: "Earwax Removal + Full GP Medical Consultation",
        priceAed: 549,
        description: "Bilateral ear cleaning combined with full general health vital check, throat/sinus exam & digital prescription.",
        badge: "Complete Relief",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "HD Video Otoscopic Examination",
        description: "The clinician inspects your ear canal and eardrum with a digital video camera, displaying the wax build-up on screen.",
        duration: "5 mins",
      },
      {
        stepNumber: 2,
        title: "Wax Softening & Gentle Extraction",
        description: "Targeted softening drops applied, followed by gentle microsuction or warm-temperature controlled electronic irrigation.",
        duration: "15-20 mins",
      },
      {
        stepNumber: 3,
        title: "Post-Cleaning Inspection & Verification",
        description: "Final video inspection confirming clear ear canals and a healthy tympanic membrane, ensuring immediate hearing restoration.",
        duration: "5 mins",
      },
    ],
    includedEquipment: [
      "High-Definition Digital Video Otoscope with Live Screen Display",
      "Medical-Grade Portable Electronic Ear Irrigation System",
      "Precision Low-Pressure Ear Microsuction Cannulas",
      "Cerumenolytic Ear Drops & Sterile Sanitized Specula",
    ],
    faqs: [
      {
        question: "Is in-home earwax removal safe and painless?",
        answer: "Yes, absolutely. Our DHA-licensed doctors use precision gentle microsuction and temperature-calibrated warm water irrigation that gently removes wax without touching the sensitive eardrum.",
      },
      {
        question: "How long does the earwax cleaning session take?",
        answer: "The appointment typically takes 25 to 35 minutes, including pre-procedure video otoscopy examination, wax clearance, and post-treatment inspection.",
      },
      {
        question: "Can you perform earwax removal on children or hearing aid users?",
        answer: "Yes! We safely treat children aged 6 and above as well as adults and seniors wearing hearing aids to ensure optimal hearing device clarity.",
      },
    ],
  },

  // 11. Peptide Home Treatments Dubai
  {
    id: "peptide-home-treatments",
    slug: "peptide-home-treatments-dubai",
    title: "Peptide Home Treatments Dubai | 24/7 DHA Licensed Cellular Therapy",
    h1: "24/7 Peptide Home Treatments Dubai, DHA Licensed Cellular Therapy",
    shortTitle: "Peptide Home Treatments Dubai",
    category: "wellness",
    metaTitle: "Peptide Home Treatments Dubai | BPC-157, TB-500 & Cellular Therapy",
    metaDescription: "DHA licensed peptide home treatments in Dubai. BPC-157, TB-500, Epithalon, GHK-Cu, NAD+, MOTS-c & Sermorelin cellular therapy administered at your home or hotel 24/7.",
    tagline: "Next-Generation Bioactive Peptide Therapy & Cellular Regeneration at Your Doorstep",
    heroBadge: "DHA Licensed Cellular & Bioactive Peptide Therapy",
    priceStartingAtAed: 899,
    responseTimeMinutes: 30,
    availability: "24/7 Everyday Across Dubai",
    dhaLicensed: true,
    iconName: "Sparkles",
    featuredImage: "/images/peptide-home-treatments-dubai.webp",
    overview: "Peptides are precise biological signaling molecules made of amino acid sequences that instruct your cells to repair tissues, reduce inflammation, boost mitochondrial energy, and optimize longevity. Hello Doctor brings DHA-licensed physician consultations and registered nurse peptide administration directly to your residence, villa, or hotel in Dubai. From tissue repair (BPC-157, TB-500) and anti-aging telomere lengthening (Epithalon, GHK-Cu) to metabolic endurance (MOTS-c, SS-31) and immune modulation (Thymosin Alpha-1), our 99%+ pharmaceutical-grade peptides stimulate cellular rejuvenation with maximum clinical safety.",
    whyChooseUs: [
      "100% DHA Licensed Medical Doctors & Registered Nurses",
      "Certified 99%+ Pharmaceutical-Grade Peptides with Third-Party Lab Verification",
      "Personalized Cellular Protocol Design tailored to your blood biomarkers & health goals",
      "Strict Cold-Chain Medical Storage ensuring maximum molecular stability and bio-activity",
      "Gentle Subcutaneous & Intramuscular Administration with Full Hygiene Standards",
      "Comprehensive Pre-Treatment Vital Signs Screening & Ongoing Recovery Tracking",
    ],
    symptomsTreated: [
      "Chronic Joint Pain, Tendonitis & Ligament Tears (BPC-157 & TB-500)",
      "Post-Surgical Tissue Healing & Accelerated Sports Injury Recovery",
      "Cellular Aging, Telomere Shortening & Longevity Optimization (Epithalon)",
      "Skin Collagen Depletion, Fine Lines & Hair Thinning (GHK-Cu Copper Peptide)",
      "Mitochondrial Fatigue, Low Cellular ATP & Metabolic Slowdown (MOTS-c)",
      "Suboptimal Growth Hormone, Muscle Wasting & Stubborn Fat (Sermorelin / Ipamorelin)",
      "Compromised Immune Defense & Systemic Inflammation (Thymosin Alpha-1 & KPV)",
      "Brain Fog, Neuro-Fatigue & Cognitive Optimization (NAD+ Peptide Synergy)",
    ],
    priceOptions: [
      {
        name: "BPC-157 (Body Protection Compound)",
        priceAed: 1200,
        description: "Accelerates gut lining repair, tendon/ligament healing, joint mobility, and systemic anti-inflammatory response.",
        popular: true,
      },
      {
        name: "TB-500 (Thymosin Beta-4)",
        priceAed: 1250,
        description: "Promotes cellular migration, muscle tissue regeneration, new blood vessel formation, and wound recovery.",
        badge: "Fast Recovery",
      },
      {
        name: "GHK-Cu Copper Peptide Radiance & Hair Booster",
        priceAed: 1100,
        description: "Master skin anti-aging peptide that boosts collagen, elastin, skin firmness, and stimulates active hair follicles.",
      },
      {
        name: "Thymosin Alpha-1 Immune Optimization",
        priceAed: 1400,
        description: "Clinically proven peptide for immune modulation, natural killer (NK) cell activation, and respiratory defense.",
      },
      {
        name: "Epithalon Telomere & Longevity Bio-Regulator",
        priceAed: 1800,
        description: "Activates telomerase enzyme, extends cellular lifespan, regulates circadian rhythm, and restores deep restorative sleep.",
        badge: "Longevity",
      },
      {
        name: "MOTS-c Mitochondrial & Metabolic Peptide",
        priceAed: 1450,
        description: "Encodes mitochondrial signals to boost glucose metabolism, insulin sensitivity, fat loss, and athletic endurance.",
      },
      {
        name: "Sermorelin / Ipamorelin Growth Hormone Secretagogue",
        priceAed: 1500,
        description: "Stimulates natural pituitary growth hormone release for lean muscle tone, body fat reduction, and vitality.",
      },
      {
        name: "NAD+ & Bioactive Peptide Synergy Drip Combo",
        priceAed: 1850,
        description: "High-dose NAD+ cellular infusion paired with targeted peptide therapy for profound whole-body reset.",
        badge: "Ultimate Reset",
      },
    ],
    procedureSteps: [
      {
        stepNumber: 1,
        title: "Medical Consultation & Biomarker Review",
        description: "Our DHA-licensed physician evaluates your health history, goals, and vital signs to prescribe the ideal peptide formulation and dosage.",
        duration: "10-15 mins",
      },
      {
        stepNumber: 2,
        title: "Cold-Chain Preparation & Reconstitution",
        description: "Peptides are transported in validated medical temperature-controlled coolboxes and reconstituted with bacteriostatic water under sterile conditions.",
        duration: "5 mins",
      },
      {
        stepNumber: 3,
        title: "Gentle Administration & Training",
        description: "Administered painlessly using micro-fine needles by our registered nurse, with step-by-step guidance for ongoing cycles.",
        duration: "15 mins",
      },
      {
        stepNumber: 4,
        title: "Clinical Follow-Up & Optimization",
        description: "Our clinical team tracks your recovery trajectory, energy biomarkers, and tissue healing with continuous support.",
        duration: "Ongoing care",
      },
    ],
    includedEquipment: [
      "Pharmaceutical Grade 99%+ Pure Bioactive Peptides",
      "Medical Cold-Chain Transport Coolbox (2°C - 8°C)",
      "Sterile Bacteriostatic Reconstitution Solutions",
      "Ultra-Fine 31G Painless Micro-Needle Syringes",
      "Digital Vital Signs & Blood Pressure Monitors",
    ],
    faqs: [
      {
        question: "What are peptides and how do they differ from regular supplements?",
        answer: "Peptides are short chains of amino acids that function as precise biological messengers, signaling specific cells to perform critical tasks such as tissue repair, collagen production, immune activation, or fat metabolism. Unlike oral supplements that face heavy digestive breakdown, therapeutic peptides delivered at home provide direct cellular signaling with high bio-efficacy.",
      },
      {
        question: "Are peptide home treatments legal and DHA-licensed in Dubai?",
        answer: "Yes, 100% of our peptide treatments are medical-grade, supervised by licensed DHA physicians, and administered by DHA-certified registered nurses following strict Dubai Health Authority healthcare protocols.",
      },
    ],
  },
];

export function getServiceBySlug(slug: string): MedicalService | undefined {
  const cleanSlug = slug.replace(/^\/?(services\/)?/, "").replace(/\/$/, "");

  if (cleanSlug === "doctor-on-call-dubai" || cleanSlug === "doctor-on-call") {
    return SERVICES.find((s) => s.id === "doctor-on-call");
  }
  if (cleanSlug === "doctor-at-hotel-dubai" || cleanSlug === "hotel-doctor-dubai" || cleanSlug === "hotel-doctor") {
    return SERVICES.find((s) => s.id === "doctor-at-hotel");
  }
  if (cleanSlug === "iv-drip-at-home-dubai" || cleanSlug === "iv-drip-therapy-dubai" || cleanSlug === "iv-drip-dubai" || cleanSlug === "iv-drip-therapy-at-home-dubai") {
    return SERVICES.find((s) => s.id === "iv-drip-therapy");
  }
  if (cleanSlug === "lab-test-at-home-dubai" || cleanSlug === "blood-test-at-home" || cleanSlug === "blood-test-at-home-dubai" || cleanSlug === "lab-test-at-home") {
    return SERVICES.find((s) => s.id === "lab-test-at-home");
  }
  if (cleanSlug === "physiotherapy-at-home-dubai" || cleanSlug === "physiotherapy-at-home") {
    return SERVICES.find((s) => s.id === "physiotherapy-at-home");
  }
  if (cleanSlug === "home-nursing-dubai" || cleanSlug === "nursing-care-at-home" || cleanSlug === "nursing-care-dubai") {
    return SERVICES.find((s) => s.id === "home-nursing");
  }
  if (cleanSlug === "baby-care-at-home-dubai" || cleanSlug === "baby-care-dubai" || cleanSlug === "baby-care") {
    return SERVICES.find((s) => s.id === "baby-care");
  }
  if (cleanSlug === "elderly-care-at-home-dubai" || cleanSlug === "elderly-care-dubai" || cleanSlug === "elderly-care-at-home") {
    return SERVICES.find((s) => s.id === "elderly-care");
  }
  if (cleanSlug === "earwax-removal-at-home-dubai" || cleanSlug === "earwax-removal-dubai" || cleanSlug === "earwax-removal") {
    return SERVICES.find((s) => s.id === "earwax-removal");
  }
  if (cleanSlug === "peptide-home-treatments-dubai" || cleanSlug === "peptide-home-treatments") {
    return SERVICES.find((s) => s.id === "peptide-home-treatments");
  }
  if (cleanSlug === "doctor-at-home-dubai" || cleanSlug === "doctor-at-home") {
    return SERVICES.find((s) => s.id === "doctor-at-home");
  }

  return SERVICES.find((s) => s.slug === cleanSlug || s.slug === `services/${cleanSlug}` || s.id === cleanSlug);
}

export function getAllServiceSlugs(): string[] {
  const slugs: string[] = [];
  SERVICES.forEach((s) => {
    slugs.push(s.slug);
  });
  // Add common aliases for backwards compatibility
  slugs.push("iv-drip-at-home-dubai");
  slugs.push("blood-test-at-home");
  slugs.push("physiotherapy-at-home");
  slugs.push("nursing-care-at-home");
  slugs.push("elderly-care-dubai");
  slugs.push("hotel-doctor-dubai");
  return Array.from(new Set(slugs));
}
