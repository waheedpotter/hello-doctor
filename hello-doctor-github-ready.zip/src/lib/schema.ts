import { SITE_CONFIG } from "./utils";
import { MedicalService } from "@/types/service";
import { Doctor } from "@/types/doctor";
import { DubaiLocation } from "@/types/location";
import { BlogPost } from "@/types/blog";

export function generateMedicalBusinessSchema() {
  return {
    "@context": "https://schema.org",
    "@type": ["MedicalBusiness", "HomeHealthCareService", "EmergencyService"],
    "@id": `${SITE_CONFIG.url}/#organization`,
    name: SITE_CONFIG.name,
    legalName: SITE_CONFIG.legalName,
    url: SITE_CONFIG.url,
    logo: `${SITE_CONFIG.url}/images/logo.png`,
    image: `${SITE_CONFIG.url}/images/logo.png`,
    telephone: SITE_CONFIG.phone,
    email: SITE_CONFIG.email,
    priceRange: "AED 250 - AED 1200",
    paymentAccepted: ["Cash", "Credit Card", "Debit Card", "Apple Pay", "Insurance Reimbursement"],
    currenciesAccepted: "AED",
    address: {
      "@type": "PostalAddress",
      streetAddress: SITE_CONFIG.address.streetAddress,
      addressLocality: SITE_CONFIG.address.addressLocality,
      addressRegion: SITE_CONFIG.address.addressRegion,
      postalCode: SITE_CONFIG.address.postalCode,
      addressCountry: SITE_CONFIG.address.addressCountry,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: SITE_CONFIG.geo.latitude,
      longitude: SITE_CONFIG.geo.longitude,
    },
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "00:00",
        closes: "23:59",
      },
    ],
    areaServed: [
      { "@type": "City", name: "Dubai" },
      { "@type": "AdministrativeArea", name: "Downtown Dubai" },
      { "@type": "AdministrativeArea", name: "Dubai Marina" },
      { "@type": "AdministrativeArea", name: "Palm Jumeirah" },
      { "@type": "AdministrativeArea", name: "Business Bay" },
      { "@type": "AdministrativeArea", name: "JBR" },
      { "@type": "AdministrativeArea", name: "Dubai Hills Estate" },
      { "@type": "AdministrativeArea", name: "Arabian Ranches" },
      { "@type": "AdministrativeArea", name: "JVC" },
      { "@type": "AdministrativeArea", name: "Al Barsha" },
      { "@type": "AdministrativeArea", name: "DIFC" },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "5.0",
      bestRating: "5",
      worstRating: "1",
      ratingCount: "155",
    },
    availableService: [
      {
        "@type": "MedicalProcedure",
        name: "Doctor on Call / Doctor at Home Dubai",
        description: "24/7 DHA Licensed GP Doctor home visits across Dubai in 30-45 minutes.",
      },
      {
        "@type": "MedicalProcedure",
        name: "IV Drip Therapy at Home Dubai",
        description: "Administered by registered nurses for immunity, hangover, energy, detox, and hydration.",
      },
      {
        "@type": "MedicalProcedure",
        name: "Home Nursing Care Dubai",
        description: "Post-operative, elderly, wound care, and injection administration at home.",
      },
      {
        "@type": "MedicalProcedure",
        name: "Blood Test & Lab Sample Collection at Home",
        description: "Full body checks and urgent diagnostic profiles with fast digital reports.",
      },
      {
        "@type": "MedicalProcedure",
        name: "Physiotherapy at Home Dubai",
        description: "Orthopedic, neuro, sports injury, and mobility rehabilitation sessions.",
      },
    ],
  };
}

export function generatePhysicianSchema(doctor: Doctor) {
  return {
    "@context": "https://schema.org",
    "@type": "Physician",
    "@id": `${SITE_CONFIG.url}/doctors/${doctor.slug}/#physician`,
    name: doctor.name,
    jobTitle: doctor.designation,
    medicalSpecialty: doctor.specialty,
    licenseNumber: doctor.dhaLicenseNumber,
    description: doctor.bio,
    image: doctor.image.startsWith("http") ? doctor.image : `${SITE_CONFIG.url}${doctor.image}`,
    url: `${SITE_CONFIG.url}/doctors/${doctor.slug}/`,
    worksFor: {
      "@type": "MedicalBusiness",
      name: SITE_CONFIG.name,
      url: SITE_CONFIG.url,
    },
    knowsLanguage: doctor.languages,
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: doctor.rating.toString(),
      ratingCount: doctor.reviewCount.toString(),
    },
  };
}

export function generateMedicalProcedureSchema(service: MedicalService) {
  return {
    "@context": "https://schema.org",
    "@type": "MedicalProcedure",
    "@id": `${SITE_CONFIG.url}/${service.slug}/#procedure`,
    name: service.title,
    description: service.overview,
    provider: {
      "@type": "MedicalBusiness",
      name: SITE_CONFIG.name,
      url: SITE_CONFIG.url,
      telephone: SITE_CONFIG.phone,
    },
    offers: {
      "@type": "Offer",
      priceCurrency: "AED",
      price: service.priceStartingAtAed.toString(),
      availability: "https://schema.org/InStock",
      validFrom: "2024-01-01",
    },
    howPerformed: service.procedureSteps.map((step) => ({
      "@type": "HowToStep",
      position: step.stepNumber,
      name: step.title,
      text: step.description,
    })),
  };
}

export function generateFAQSchema(faqs: { question: string; answer: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };
}

export function generateBreadcrumbSchema(items: { name: string; item: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((crumb, idx) => ({
      "@type": "ListItem",
      position: idx + 1,
      name: crumb.name,
      item: crumb.item.startsWith("http") ? crumb.item : `${SITE_CONFIG.url}${crumb.item}`,
    })),
  };
}

export function generateArticleSchema(post: BlogPost, authorDoctor?: Doctor) {
  return {
    "@context": "https://schema.org",
    "@type": "MedicalWebPage",
    "@id": `${SITE_CONFIG.url}/blog/${post.slug}/#article`,
    headline: post.title,
    description: post.metaDescription,
    image: post.featuredImage.startsWith("http") ? post.featuredImage : `${SITE_CONFIG.url}${post.featuredImage}`,
    datePublished: post.publishedDate,
    dateModified: post.updatedDate,
    author: {
      "@type": "Physician",
      name: authorDoctor ? authorDoctor.name : "Hello Doctor Medical Team",
      url: authorDoctor ? `${SITE_CONFIG.url}/doctors/${authorDoctor.slug}/` : SITE_CONFIG.url,
    },
    publisher: {
      "@type": "Organization",
      name: SITE_CONFIG.name,
      logo: {
        "@type": "ImageObject",
        url: `${SITE_CONFIG.url}/images/logo.png`,
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `${SITE_CONFIG.url}/blog/${post.slug}/`,
    },
  };
}
