import { Metadata } from "next";
import { SITE_CONFIG } from "./utils";

interface SEOProps {
  title: string;
  description: string;
  canonicalPath?: string;
  image?: string;
  noIndex?: boolean;
}

export function constructMetadata({
  title,
  description,
  canonicalPath = "",
  image = "/images/logo.png",
  noIndex = false,
}: SEOProps): Metadata {
  const fullUrl = `${SITE_CONFIG.url}${canonicalPath.startsWith("/") ? canonicalPath : `/${canonicalPath}`}`;

  return {
    title: `${title} | Hello Doctor Dubai`,
    description,
    alternates: {
      canonical: fullUrl,
    },
    openGraph: {
      title: `${title} | Hello Doctor Dubai`,
      description,
      url: fullUrl,
      siteName: SITE_CONFIG.name,
      images: [
        {
          url: image.startsWith("http") ? image : `${SITE_CONFIG.url}${image}`,
          width: 1200,
          height: 630,
          alt: `${title} - Hello Doctor Dubai`,
        },
      ],
      locale: "en_AE",
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title: `${title} | Hello Doctor Dubai`,
      description,
      images: [image.startsWith("http") ? image : `${SITE_CONFIG.url}${image}`],
    },
    robots: {
      index: !noIndex,
      follow: !noIndex,
      googleBot: {
        index: !noIndex,
        follow: !noIndex,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
    icons: {
      icon: "/favicon.ico",
      apple: "/images/logo.png",
    },
  };
}
