import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const SITE_CONFIG = {
  name: "Hello Doctor Dubai",
  legalName: "Hello Doctor Home Health Care LLC",
  domain: "hellodoctor.ae",
  url: "https://hellodoctor.ae",
  phone: "+971552537940",
  phoneDisplay: "+971 55 253 7940",
  emergencyPhone: "+971552537940",
  whatsappNumber: "971552537940",
  email: "office@hellodoctor.ae",
  address: {
    streetAddress: "Espada Office, Rasis Business Centre, ZNAB-90, 6th Floor, Al Barsha 1",
    addressLocality: "Dubai",
    addressRegion: "Dubai",
    postalCode: "00000",
    addressCountry: "AE",
  },
  geo: {
    latitude: 25.1189,
    longitude: 55.2017,
  },
  dhaLicense: "6978946",
  workingHours: "24/7 (Mon-Sun: 00:00 - 24:00)",
  averageArrivalMinutes: "30 - 45 Mins",
};

export function getWhatsAppBookingUrl(message?: string): string {
  const defaultText = encodeURIComponent(
    message ||
      "Hello! I need a DHA-licensed Doctor / Healthcare service at my home/hotel in Dubai. Please assist me."
  );
  return `https://wa.me/${SITE_CONFIG.whatsappNumber}?text=${defaultText}`;
}

export function getDirectCallUrl(): string {
  return `tel:${SITE_CONFIG.phone}`;
}
