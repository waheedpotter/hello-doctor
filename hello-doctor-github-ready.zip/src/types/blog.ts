export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  metaDescription: string;
  excerpt: string;
  content: string;
  authorDoctorId: string;
  publishedDate: string;
  updatedDate: string;
  readingTimeMinutes: number;
  categorySlug: string;
  categoryName: string;
  tags: string[];
  featuredImage: string;
}

export interface BlogCategory {
  id: string;
  slug: string;
  name: string;
  description: string;
}
