export interface BookingFormData {
  serviceSlug: string;
  serviceName: string;
  subOption?: string;
  patientName: string;
  phoneNumber: string;
  areaSlug: string;
  areaName: string;
  buildingOrVilla: string;
  preferredTime: 'immediate' | 'schedule';
  scheduledDate?: string;
  scheduledTimeSlot?: string;
  notes?: string;
}

export interface Review {
  id: string;
  authorName: string;
  authorLocation: string;
  serviceUsed: string;
  rating: number;
  date: string;
  comment: string;
  verifiedPatient: boolean;
  avatarUrl?: string;
}
