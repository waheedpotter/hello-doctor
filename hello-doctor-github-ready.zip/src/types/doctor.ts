export interface Doctor {
  id: string;
  slug: string;
  name: string;
  roleTitle?: string; // e.g. "Medical Director", "General Practitioner", "DHA Registered Nurse"
  designation: string;
  specialty: string;
  dhaLicenseNumber: string;
  experienceYears: number;
  education: string[];
  languages: string[];
  bio: string;
  image: string;
  rating: number;
  reviewCount: number;
  availableAreas: string[];
  servicesOffered: string[];
  consultationFeeAed: number;
  isAvailableToday: boolean;
}
