export interface DubaiLocation {
  id: string;
  slug: string;
  name: string;
  zone: 'Central Dubai' | 'Coastal & Marina' | 'New Dubai / South' | 'Deira & Bur Dubai' | 'East Dubai';
  averageEtaMinutes: number;
  description: string;
  popularCommunities: string[];
  serviceAvailability: string;
  landmarks: string[];
  seoMetaTitle: string;
  seoMetaDescription: string;
  localHeroText: string;
  nearbyHotels: string[];
}
