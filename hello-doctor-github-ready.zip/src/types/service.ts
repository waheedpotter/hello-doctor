export interface ServiceFAQ {
  question: string;
  answer: string;
}

export interface ProcedureStep {
  stepNumber: number;
  title: string;
  description: string;
  duration?: string;
}

export interface ServicePriceOption {
  name: string;
  priceAed: number;
  description: string;
  badge?: string;
  popular?: boolean;
}

export interface MedicalService {
  id: string;
  slug: string;
  title: string;
  h1: string;
  shortTitle: string;
  category: 'urgent-care' | 'wellness' | 'nursing' | 'diagnostics' | 'therapy' | 'specialized' | 'family-care';
  metaTitle: string;
  metaDescription: string;
  tagline: string;
  heroBadge: string;
  priceStartingAtAed: number;
  priceOptions?: ServicePriceOption[];
  iconName: string;
  featuredImage: string;
  responseTimeMinutes: number;
  availability: string; // e.g. "24/7 Everyday"
  dhaLicensed: boolean;
  overview: string;
  whyChooseUs: string[];
  symptomsTreated: string[];
  procedureSteps: ProcedureStep[];
  includedEquipment: string[];
  faqs: ServiceFAQ[];
  parentSlug?: string;
  subServices?: string[];
}
