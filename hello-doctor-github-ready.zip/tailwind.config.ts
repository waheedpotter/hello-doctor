import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: "1rem",
        sm: "1.5rem",
        lg: "2rem",
        xl: "2.5rem",
      },
      screens: {
        "2xl": "1280px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        brand: {
          50: "#FFF5EC",
          100: "#FFE8D5",
          200: "#FFCFAF",
          300: "#FFAF7D",
          400: "#FF8E47",
          500: "#FF6A00", // Vibrant Primary Brand Orange
          600: "#E65500", // Rich Warm Orange
          700: "#C44300", // Deep Amber Orange
          800: "#9E3400", // Dark Amber
          900: "#7E2B00",
          gradient: {
            start: "#FF7A00",
            middle: "#FF5500",
            end: "#E64A00",
          }
        },
        primary: {
          DEFAULT: "#FF6A00",
          foreground: "#FFFFFF",
          hover: "#E65500",
          soft: "#FFF5EC",
        },
        secondary: {
          DEFAULT: "#0F172A",
          foreground: "#FFFFFF",
          hover: "#1E293B",
        },
        accent: {
          DEFAULT: "#FF8E47",
          foreground: "#FFFFFF",
          warm: "#FFA94D",
        },
        medical: {
          blue: "#0284C7",
          green: "#16A34A",
          red: "#DC2626",
          amber: "#D97706",
        },
        surface: {
          DEFAULT: "#FFFFFF",
          subtle: "#F8FAFC",
          muted: "#F1F5F9",
          warm: "#FFFBF7",
        }
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "pulse-slow": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.85", transform: "scale(1.05)" },
        },
        "glow-orange": {
          "0%, 100%": { boxShadow: "0 0 15px rgba(255, 106, 0, 0.4)" },
          "50%": { boxShadow: "0 0 28px rgba(255, 106, 0, 0.75)" },
        },
        "shimmer": {
          "100%": {
            transform: "translateX(100%)",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-slow": "pulse-slow 3s ease-in-out infinite",
        "glow-orange": "glow-orange 2.5s infinite",
        "shimmer": "shimmer 2s infinite",
      },
      backgroundImage: {
        "hero-gradient": "linear-gradient(135deg, #FFF8F3 0%, #FFFFFF 50%, #FFF3EB 100%)",
        "brand-gradient": "linear-gradient(135deg, #FF7A00 0%, #FF5A00 50%, #E64A00 100%)",
        "brand-glow": "radial-gradient(circle, rgba(255,106,0,0.15) 0%, rgba(255,255,255,0) 70%)",
        "dark-gradient": "linear-gradient(135deg, #0F172A 0%, #1E293B 100%)",
      },
    },
  },
  plugins: [],
};

export default config;
