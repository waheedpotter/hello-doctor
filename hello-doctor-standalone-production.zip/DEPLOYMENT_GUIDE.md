# Hello Doctor Dubai - Node.js Server Deployment Guide

This standalone package contains the complete production-ready build of **Hello Doctor Home Health Care LLC** (`https://hellodoctor.ae`).

---

## 🚀 Option A: Run directly with Node.js

1. Upload all files from this directory to your server (e.g. `/var/www/hello-doctor` or your cPanel app root).
2. Set the port (optional, defaults to 3000) and start the server:
   ```bash
   PORT=3000 node server.js
   ```

---

## ⚡ Option B: Run with PM2 (Recommended for Production / VPS)

1. Ensure PM2 is installed:
   ```bash
   npm install -g pm2
   ```
2. Start the application with cluster mode:
   ```bash
   pm2 start ecosystem.config.js
   ```
3. Save the PM2 list and enable startup script:
   ```bash
   pm2 save
   pm2 startup
   ```

---

## 🌐 Option C: cPanel / Plesk "Setup Node.js App"

1. In cPanel, navigate to **Setup Node.js App**.
2. Create Application:
   - **Node.js version:** 18.x or 20.x+
   - **Application mode:** Production
   - **Application root:** directory where you uploaded these files
   - **Application startup file:** `server.js`
3. Click **Save** and **Start Application**.

---

## 🔒 Nginx Reverse Proxy (Sample snippet for VPS)

```nginx
server {
    listen 80;
    server_name hellodoctor.ae www.hellodoctor.ae;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
